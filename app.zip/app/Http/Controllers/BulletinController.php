<?php


namespace App\Http\Controllers;

use App\Models\Affectation;
use App\Models\BulletinTheme;
use App\Models\Classe;
use App\Models\Decoupage;
use App\Models\Inscription;
use App\Models\Evaluation;
use App\Models\Matiere;
use App\Models\MoyenneGenerale;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;
use App\Models\Moyenne;
use App\Models\Ecole;
use Illuminate\Support\Str;


class BulletinController extends Controller
{

    public function activerTheme(Request $request)
    {
        $id = $request->theme_id; // ID du thème sélectionné

        // Désactiver tous les thèmes
        BulletinTheme::where('active', true)
            ->update(['active' => false]);

        // Activer le thème choisi
        BulletinTheme::where('id', $id)->update(['active' => true]);

        return back()->with('success', '🎨 Thème activé avec succès');
    }



    public function checkMissingNotes($classeId, $anneeId, $decoupageId)
    {
        // 1️⃣ Vérifie d'abord si l'utilisateur est connecté
        if (!auth()->check()) {
            return redirect()->route('login')->with('error', 'Veuillez vous connecter pour accéder à cette page.');
        }
        // Récupérer les inscriptions de la classe
        $inscriptions = Inscription::with('eleve')
            ->where('classe_id', $classeId)
            ->where('annee_id', $anneeId)
            ->get();

        // Récupérer les matières
        $matieres = Affectation::where('classe_id', $classeId)
            ->where('annee_id', $anneeId)
            ->with('matiere')
            ->get()
            ->pluck('matiere');

        // Récupérer toutes les évaluations du découpage
        $evaluations = Evaluation::with('typeEvaluation')
            ->where('decoupage_id', $decoupageId)
            ->get()
            ->groupBy('inscription_id');

        $result = [];

        foreach ($inscriptions as $inscription) {

            $manquantes = [];

            foreach ($matieres as $matiere) {

                $evalsEleve = $evaluations[$inscription->id] ?? collect();
                $evalMatiere = $evalsEleve->where('matiere_id', $matiere->id);

                $hasDevoir      = $evalMatiere->firstWhere('typeEvaluation.nom', 'Devoir') !== null;
                $hasComposition = $evalMatiere->firstWhere('typeEvaluation.nom', 'Composition') !== null;

                if (!$hasDevoir || !$hasComposition) {
                    $manquantes[] = [
                        'matiere' => $matiere->nom,
                        'devoir' => $hasDevoir,
                        'composition' => $hasComposition
                    ];
                }
            }

            if (!empty($manquantes)) {
                $result[] = [
                    'eleve' => $inscription->eleve->nom . ' ' . $inscription->eleve->prenom,
                    'inscription_id' => $inscription->id,
                    'matieres_manquantes' => $manquantes
                ];
            }
        }

        return $result;
    }

    private function calculerEtSauvegarderMoyennes($classeId,$decoupageId)
    {
        // 1️⃣ Vérifie d'abord si l'utilisateur est connecté
        if (!auth()->check()) {
            return redirect()->route('login')->with('error', 'Veuillez vous connecter pour accéder à cette page.');
        }

        $decoupage = \App\Models\Decoupage::findOrFail($decoupageId);
        $anneeId   = $decoupage->annee_id;

        $inscriptions = \App\Models\Inscription::where('classe_id',$classeId)
            ->where('annee_id',$anneeId)
            ->get();

        // 1️⃣ Calcul collectif des moyennes classe
        $moyennesClasse = [];
        foreach ($inscriptions as $inscription){

            $evaluations = \App\Models\Evaluation::with(['typeEvaluation', 'matiere'])
                ->where('decoupage_id', $decoupageId)
                ->where('inscription_id',$inscription->id)
                ->get();

            $matieres = \App\Models\Matiere::whereHas('affectations', function ($q) use ($classeId) {
                $q->where('classe_id',$classeId);
            })->get();

            $totalCoef = 0;
            $totalPoints = 0;

            foreach ($matieres as $matiere){
                $coef = $matiere->coefficient ?? 1;

                $notes = $evaluations->where('matiere_id',$matiere->id);

                $devoir = $notes->firstWhere('typeEvaluation.nom','Devoir')?->note ?? 0;
                $compo  = $notes->firstWhere('typeEvaluation.nom','Composition')?->note ?? 0;

                $moy = ($devoir + $compo) / 2;

                $totalCoef += $coef;
                $totalPoints += ($moy * $coef);
            }

            $moyennesClasse[$inscription->id] = $totalCoef > 0 ? round($totalPoints / $totalCoef,2) : 0;
        }

        // 2️⃣ CLASSEMENT
        arsort($moyennesClasse);
        $rangs = [];

        $rang = 1;
        $dernierScore = null;

        foreach ($moyennesClasse as $id => $val) {

            if ($dernierScore !== null && $val < $dernierScore){
                $rang++;
            }

            $rangs[$id] = $rang;
            $dernierScore = $val;
        }

        // 3️⃣ SAVE ELEVES
        foreach ($moyennesClasse as $idInscription => $moy) {

            $app = match (true) {
                $moy >= 18 => 'Excellent',
                $moy >= 16 => 'T.Bien',
                $moy >= 14 => 'Bien',
                $moy >= 12 => 'Assez Bien',
                $moy >= 10 => 'Passable',
                $moy >= 8  => 'Insuffisant',
                $moy >= 6  => 'T.Insuffisant',
                default    => 'Médiocre',
            };


            \App\Models\Moyenne::updateOrCreate(
                [
                    'inscription_id' => $idInscription,
                    'decoupage_id'   => $decoupageId,
                ],
                [
                    'moyenne'      => $moy,
                    'rang'         => $rangs[$idInscription],
                    'appreciation' => $app,
                ]
            );
        }

        // 4️⃣ SAVE MOY CLASS
        \App\Models\MoyenneGenerale::updateOrCreate(
            [
                'classe_id' => $classeId,
                'annee_id' => $anneeId,
                'decoupage_id' => $decoupageId,
            ],
            [
                'moyenne_classe' => round(array_sum($moyennesClasse)/count($moyennesClasse),2),
                'moyenne_forte' => max($moyennesClasse),
                'moyenne_faible' => min($moyennesClasse),
            ]
        );
    }



    public function bulletin($classe_id)
    {
        // 1️⃣ Vérifie d'abord si l'utilisateur est connecté
        if (!auth()->check()) {
            return redirect()->route('login')->with('error', 'Veuillez vous connecter pour accéder à cette page.');
        }
        // 2️⃣ Vérifie si l'utilisateur connecté est admin ou directeur
        if (!in_array(auth()->user()->role, ['admin', 'directeur','secretaire'])) {
            return redirect()->back()->with('error', 'Accès refusé. Vous n\'avez pas les autorisations nécessaires.');
        }

        $themes = BulletinTheme::all();
        $classe = Classe::findOrFail($classe_id);

        // ✅ Récupérer toutes les évaluations des élèves inscrits dans cette classe
        $evaluations = Evaluation::whereHas('inscription', function($q) use ($classe_id) {
            $q->where('classe_id', $classe_id);
        })
            ->with(['inscription.eleve', 'matiere', 'decoupage', 'typeEvaluation'])
            ->get();

        // ✅ Extraire uniquement les découpages présents dans ces évaluations
        $decoupages = Decoupage::whereIn(
            'id',
            $evaluations->pluck('decoupage_id')->unique()
        )->get();


        logAction('Consultation bulletin', "Consultation des bulletin de la classe {$classe->nom} ");

        return view('bulletins.index', compact('classe', 'evaluations', 'decoupages','themes'));
    }
    public function apercubulletin($inscriptionId, $decoupageId)
    {


        // 1️⃣ Vérifie d'abord si l'utilisateur est connecté
        if (!auth()->check()) {
            return redirect()->route('login')->with('error', 'Veuillez vous connecter pour accéder à cette page.');
        }
        // 2️⃣ Vérifie si l'utilisateur connecté est admin ou directeur
        if (!in_array(auth()->user()->role, ['admin', 'directeur','secretaire'])) {
            return redirect()->back()->with('error', 'Accès refusé. Vous n\'avez pas les autorisations nécessaires.');
        }
        $theme = bulletinThemeActif();


        $view = $theme
            ? $theme->blade
            : 'bulletins.apercu'; // fallback sécurité

//        dd($view);
        $decoupage = Decoupage::findOrFail($decoupageId);
        $class = Classe::all();
        $ecole = Ecole::first();
        $inscription = Inscription::with('eleve', 'classe')->findOrFail($inscriptionId);
        $anneeId = $inscription->annee_id;
        $idClasse = $inscription->classe->id;
        $recap_annuelle = [];
        // Effectif de la classe
        $inscriptionsClasse = Inscription::where('classe_id', $idClasse)
            ->where('annee_id', $anneeId)
            ->pluck('id');
        $effectif = $inscriptionsClasse->count();

        // voir sil y a des notes manquantes
        // ➤ Si skipCheck = 1, on saute la vérification
        if (request()->has('skipCheck')) {
            goto skip_missing_notes_check;
        }

        $manques = $this->checkMissingNotes($idClasse, $anneeId, $decoupageId);

        if (!empty($manques)) {
            return view('bulletins.missing_modal', [
                'manques' => $manques,
                'inscriptionId' => $inscriptionId,
                'decoupageId' => $decoupageId,
                'idClasse' => $idClasse,
            ]);
        }
        // ➤ Étiquette pour sauter

        skip_missing_notes_check:


        // Toutes les matières affectées à la classe
        $matieresClasse = Affectation::where('classe_id', $idClasse)
            ->where('annee_id', $anneeId)
            ->with('matiere')
            ->get()
            ->pluck('matiere');

        // Toutes les évaluations de la classe pour ce découpage
        $evaluationsClasse = Evaluation::with(['typeEvaluation', 'inscription', 'matiere'])
            ->whereIn('inscription_id', $inscriptionsClasse)
            ->where('decoupage_id', $decoupageId)
            ->get()
            ->groupBy('matiere_id');

        $statsMatieres = [];
        $rangsMatieres = [];

        // Calcul des stats par matière
        foreach ($matieresClasse as $matiere) {
            $matiereId = $matiere->id;

            // Toutes les évaluations pour cette matière
            $evals = $evaluationsClasse[$matiereId] ?? collect();
            $parEleve = $evals->groupBy('inscription_id');

            // Moyenne par élève, 0 si pas de note
            $moyennesEleves = [];
            foreach ($inscriptionsClasse as $eleveId) {
                $notes = $parEleve[$eleveId] ?? collect();
                $devoir = $notes->firstWhere('typeEvaluation.nom', 'Devoir')?->note ?? 0;
                $compo  = $notes->firstWhere('typeEvaluation.nom', 'Composition')?->note ?? 0;
                $moyennesEleves[$eleveId] = ($devoir + $compo) / 2;
            }

            // Rang de l'élève pour cette matière
            $sorted = collect($moyennesEleves)->sortDesc()->values();
            $moyEleve = $moyennesEleves[$inscriptionId] ?? 0;
            $rang = $sorted->search($moyEleve) !== false ? $sorted->search($moyEleve) + 1 : null;
            $rangsMatieres[$matiereId] = $rang;

            // Stats de la matière pour la classe
            $statsMatieres[$matiereId] = [
                'fort'    => max($moyennesEleves),
                'faible'  => min($moyennesEleves),
                'moyenne' => $effectif > 0 ? array_sum($moyennesEleves) / $effectif : 0,
            ];
        }

        // S'assurer que $evaluationsAll est défini
        $evaluationsAll = Evaluation::with(['typeEvaluation', 'matiere'])
            ->whereIn('inscription_id', $inscriptionsClasse)
            ->where('decoupage_id', $decoupageId)
            ->get()
            ->groupBy('inscription_id');

// Moyennes générales pondérées par coefficient
        $moyennesClasse = collect();

        foreach ($inscriptionsClasse as $eleveId) {
            $totalPoints = 0;
            $totalCoef = 0;

            foreach ($matieresClasse as $matiere) {
                $coef = $matiere->coefficient ?? 1;

                // Récupérer les évaluations de l'élève pour cette matière, sinon collection vide
                $evals = $evaluationsAll[$eleveId] ?? collect();
                $evalsMatiere = $evals->where('matiere_id', $matiere->id);

                $devoir = $evalsMatiere->firstWhere('typeEvaluation.nom', 'Devoir')?->note ?? 0;
                $compo  = $evalsMatiere->firstWhere('typeEvaluation.nom', 'Composition')?->note ?? 0;

                // Moyenne de la matière (0 si pas de note)
                $noteMatiere = ($devoir + $compo) / 2;

                // Ajouter au total pondéré
                $totalPoints += $noteMatiere * $coef;

                // Ajouter le coefficient même si la note est 0
                $totalCoef += $coef;
            }

            // Calcul de la moyenne générale de l'élève
            $moyennesClasse[$eleveId] = $totalCoef > 0 ? $totalPoints / $totalCoef : 0;

        }

// Vérification : si l'élève courant n'est pas dans $moyennesClasse, on l'ajoute à 0
        if (!isset($moyennesClasse[$inscriptionId])) {
            $moyennesClasse[$inscriptionId] = 0;
        }

// Calcul du rang général et statistiques
        $sortedClasse = $moyennesClasse->sortDesc()->values();
        $rangGeneral = $sortedClasse->search($moyennesClasse[$inscriptionId]) + 1;
        $plusForte = $moyennesClasse->max();
        $plusFaible = $moyennesClasse->min();
        $moyenneGeneraleClasse = $moyennesClasse->avg();


        // Évaluations de l'élève pour le découpage
        $evaluations = Evaluation::with(['matiere.affectations.enseignant', 'decoupage', 'typeEvaluation'])
            ->where('inscription_id', $inscriptionId)
            ->where('decoupage_id', $decoupageId)
            ->get();
        $groupedEvaluations = $evaluations->groupBy('decoupage.id');


       // dd($groupedEvaluations);
        // Sauvegarde des moyennes par découpage
        $resultatsdecoupageId = [];

        foreach ($matieresClasse as $matiere) {
            $matiereIds[] = $matiere->id;
        }

// On ne boucle plus seulement sur $evaluations, mais sur le découpage
        foreach ($evaluations->groupBy('decoupage.id') as $decId => $evalsDec) {
            $totalCoefNotes = 0;
            $coefficientTotal = 0;

            foreach ($matieresClasse as $matiere) {
                $coef = $matiere->coefficient ?? 1;

                // Récupérer les évaluations de l'élève pour cette matière
                $evalsMatiere = $evalsDec->where('matiere_id', $matiere->id);

                $devoir = $evalsMatiere->firstWhere('typeEvaluation.nom', 'Devoir')?->note ?? 0;
                $compo  = $evalsMatiere->firstWhere('typeEvaluation.nom', 'Composition')?->note ?? 0;

                // Moyenne matière = 0 si pas de note
                $noteMatiere = ($devoir + $compo) / 2;

                // Ajouter au total pondéré
                $totalCoefNotes += $noteMatiere * $coef;

                // Ajouter le coefficient même si note = 0
                $coefficientTotal += $coef;
            }

            $moyenneDecoupage = $coefficientTotal > 0 ? $totalCoefNotes / $coefficientTotal : 0;

            // -- Appréciation complète --
            $app = $moyenneDecoupage >= 18 ? "Excellent" :
                ($moyenneDecoupage >= 16 ? "T.Bien" :
                    ($moyenneDecoupage >= 14 ? "Bien" :
                        ($moyenneDecoupage >= 12 ? "Assez Bien" :
                            ($moyenneDecoupage >= 10 ? "Passable" :
                                ($moyenneDecoupage >= 8 ? "Insuffisant" :
                                    ($moyenneDecoupage >= 6 ? "T.Insuffisant" : "Médiocre")
                                )
                            )
                        )
                    )
                );



            // 🔹 Déterminer si on est au dernier trimestre ou dernier semestre
            $nomDecoupage = strtolower(trim($decoupage->nom));
            $dernierDecoupage = false;

            if(str_contains($nomDecoupage, 'trimestre')) {
                $dernierDecoupage = str_contains($nomDecoupage, '3'); // 3ème trimestre = dernier
            } elseif(str_contains($nomDecoupage, 'semestre')) {
                $dernierDecoupage = str_contains($nomDecoupage, '2'); // 2ème semestre = dernier
            }
            $recap_annuelle = null;
// 🔹 Calcul moyenne annuelle si dernier découpage
            $moyenneAnnuelle = null;

            if ($dernierDecoupage) {
                // 1️⃣ Moyenne annuelle de l'élève
                $moyennesAnnuelles = Moyenne::where('inscription_id', $inscription->id)->pluck('moyenne');

                if ($moyennesAnnuelles->count() > 0) {
                    $moyenneAnnuelle = round($moyennesAnnuelles->avg(), 2);

                    $appAnnuelle = match (true) {
                        $moyenneAnnuelle >= 18 => "Excellent",
                        $moyenneAnnuelle >= 16 => "T.Bien",
                        $moyenneAnnuelle >= 14 => "Bien",
                        $moyenneAnnuelle >= 12 => "A.Bien",
                        $moyenneAnnuelle >= 10 => "Passable",
                        $moyenneAnnuelle >= 8  => "Insuffisant",
                        $moyenneAnnuelle >= 6  => "T.Insuffisant",
                        default              => "Médiocre",
                    };

                    // 🔹 Calcul du rang annuel parmi tous les élèves de la même classe et année
                    $elevesClasseIds = \App\Models\Inscription::where('classe_id', $inscription->classe_id)
                        ->where('annee_id', $inscription->annee_id)
                        ->pluck('id');

                    $moyennesAnnClasse = Moyenne::whereIn('inscription_id', $elevesClasseIds)
                        ->whereIn('decoupage_id', \App\Models\Decoupage::where('annee_id', $decoupage->annee_id)->pluck('id'))
                        ->selectRaw('inscription_id, AVG(moyenne) as moyenne_annuelle')
                        ->groupBy('inscription_id')
                        ->get()
                        ->sortByDesc('moyenne_annuelle')
                        ->values();

                    $rangAnnuel = null;
                    foreach ($moyennesAnnClasse as $index => $m) {
                        if ($m->inscription_id == $inscription->id) {
                            $rangAnnuel = $index + 1;
                            break;
                        }
                    }

                    $recap_annuelle = [
                        'moyenne' => $moyenneAnnuelle,
                        'appreciation' => $appAnnuelle,
                        'rang' => $rangAnnuel,
                    ];
                }
            }



            Moyenne::updateOrCreate(
                ['inscription_id' => $inscriptionId, 'decoupage_id' => $decId],
                ['moyenne' => $moyenneDecoupage, 'rang' => $rangGeneral, 'appreciation' => $app,

                    'moyenne_annuelle'      => $dernierDecoupage ? $moyenneAnnuelle : null,
                    'rang_annuel'           => $dernierDecoupage ? $rangAnnuel : null,
                    'appreciation_annuelle' => $dernierDecoupage ? $appAnnuelle : null,

                ]
            );

            MoyenneGenerale::updateOrCreate(
                ['classe_id' => $idClasse, 'annee_id' => $anneeId, 'decoupage_id'=> $decId],
                ['moyenne_classe' => $moyenneGeneraleClasse,
                    'moyenne_forte' => $plusForte,
                    'moyenne_faible' => $plusFaible,
                    ]
            );

            $resultatsdecoupageId[$decId] = [
                'moyenne'      => $moyenneDecoupage,
                'rang'         => $rangGeneral,
                'appreciation' => $app,
                'max'          => $plusForte,
                'min'          => $plusFaible,
                'moyClasse'    => $moyenneGeneraleClasse,
                'recap_annuelle' => $recap_annuelle,
            ];
        }


        // Récapitulatif
        $recap = Moyenne::where('inscription_id', $inscriptionId)
            ->join('inscriptions','inscriptions.id','=','moyennes.inscription_id')
            ->join('moyennes_generales', function($join) use ($anneeId){
                $join->on('moyennes.decoupage_id','=','moyennes_generales.decoupage_id')
                    ->on('inscriptions.classe_id','=','moyennes_generales.classe_id')
                    ->where('moyennes_generales.annee_id', $anneeId);
            })
            ->join('decoupages','decoupages.id','=','moyennes.decoupage_id')
            ->select(
                'decoupages.nom as periode',
                'moyennes.moyenne as moyenne_eleve',
                'moyennes.rang',
                'moyennes.appreciation',
                'moyennes_generales.moyenne_classe',
                'moyennes_generales.moyenne_forte',
                'moyennes_generales.moyenne_faible',
            )
            ->orderBy('moyennes.decoupage_id')
            ->get();

        // Log
        $eleveNom = $inscription->eleve->nom . ' ' . $inscription->eleve->prenom;
        $classeNom = $inscription->classe->nom ?? 'Classe inconnue';
        logAction('Consultation bulletin élève', "Affichage du bulletin de {$eleveNom} ({$classeNom}) pour le {$decoupage->nom}");

        return view($view, compact(
            'inscription',
            'groupedEvaluations',
            'class',
            'ecole',
            'effectif',
            'statsMatieres',
            'rangsMatieres',
            'rangGeneral',
            'plusForte',
            'plusFaible',
            'moyenneGeneraleClasse',
            'recap',
            'resultatsdecoupageId',
            'recap_annuelle'
        ));
    }

    public function bulletinParDecoupage($classe,$decoupageId)
    {
        set_time_limit(0);

        // 1️⃣ Vérifie d'abord si l'utilisateur est connecté
        if (!auth()->check()) {
            return redirect()->route('login')->with('error', 'Veuillez vous connecter pour accéder à cette page.');
        }

        // 2️⃣ Vérifie si l'utilisateur connecté est admin ou directeur
        if (!in_array(auth()->user()->role, ['admin', 'directeur','secretaire'])) {
            return redirect()->back()->with('error', 'Accès refusé. Vous n\'avez pas les autorisations nécessaires.');
        }

        $theme = bulletinThemeActif();

        if ($theme && $theme->blade) {
            $bladeName = Str::afterLast($theme->blade, '.');
            $view = "bulletins.themes.pardecoupage.$bladeName";
        }
        else {
            $view = 'bulletins.par_decoupage';
        }

//         if ($theme->nom === 'Standard') {
//            $view = 'bulletins.par_decoupage';
//        }
//dd($view);
        $ecole = Ecole::first();
        $decoupage = Decoupage::findOrFail($decoupageId);
        $classe_id = Classe::findOrFail($classe);

        // 🔹 Récupération de toutes les inscriptions avec relations utiles
        $inscriptions = Inscription::with(['eleve', 'classe', 'annee'])
            ->where('classe_id',$classe_id->id)
            ->whereHas('classe')
            ->get();

        $anneeId = $decoupage->annee->id;
        $allBulletins = [];


        // voir sil y a des notes manquantes
        // ➤ Si skipCheck = 1, on saute la vérification
        if (request()->has('skipCheck')) {
            goto skip_missing_notes_check;
        }

        $manques = $this->checkMissingNotes($classe, $anneeId, $decoupageId);

        if (!empty($manques)) {
            return view('bulletins.missing_modal', [
                'manques' => $manques,
                'decoupageId' => $decoupageId,
                'idClasse' => $classe,

            ]);
        }
        // ➤ Étiquette pour sauter

        skip_missing_notes_check:

        $moyennesToUpsert = [];


        foreach ($inscriptions as $inscription) {

            $idclasse = $inscription->classe->id;
            $effectif = Inscription::where('classe_id', $idclasse)
                ->where('annee_id', $inscription->annee_id)
                ->count();

            // 🔹 Évaluations de l’élève pour ce découpage
            $evaluations = Evaluation::with(['matiere.affectations.enseignant', 'typeEvaluation'])
                ->where('inscription_id', $inscription->id)
                ->where('decoupage_id', $decoupageId)
                ->get();

            if ($evaluations->isEmpty()) continue;

            // 🔹 Évaluations de toute la classe (pour stats et rangs)
            $evaluationsClasse = Evaluation::with(['typeEvaluation', 'matiere'])
                ->whereIn('inscription_id',
                    Inscription::where('classe_id', $idclasse)
                        ->where('annee_id', $inscription->annee_id)
                        ->pluck('id')
                )
                ->where('decoupage_id', $decoupageId)
                ->get()
                ->groupBy('matiere_id');

            $rangsMatieres = collect();
            $statsMatieres = collect();

            foreach ($evaluationsClasse as $matiereId => $evals) {
                $parEleve = $evals->groupBy('inscription_id');

                // Calcul des moyennes
                $moyennesEleves = $parEleve->map(fn($notes) => (
                        ($notes->firstWhere('typeEvaluation.nom', 'Devoir')?->note ?? 0) +
                        ($notes->firstWhere('typeEvaluation.nom', 'Composition')?->note ?? 0)
                    ) / 2);

                if ($moyennesEleves->isNotEmpty()) {
                    $moyEleve = $moyennesEleves->get($inscription->id, 0);

                    // Rang = 1 + nombre d'élèves avec une moyenne supérieure
                    $rang = $moyennesEleves->filter(fn($m) => $m > $moyEleve)->count() + 1;
                    $rangsMatieres[$matiereId] = $rang;

                    // Statistiques en une seule passe
                    $statsMatieres[$matiereId] = [
                        'fort'    => $moyennesEleves->max(),
                        'faible'  => $moyennesEleves->min(),
                        'moyenne' => $moyennesEleves->avg(),
                    ];
                }
            }

            $notesParMatiere = [];
            $totalCoefNotes = 0;
            $totalCoef = 0;

// 🔹 Récupération de TOUTES les matières de la classe
            $matieresClasse = Matiere::whereHas('affectations', fn($q) => $q->where('classe_id', $idclasse))->get();

// 🔹 Indexer les évaluations par matière et type pour un accès direct
            $evalsIndex = $evaluations->groupBy('matiere_id')->map(fn($evals) => $evals->keyBy(fn($e) => $e->typeEvaluation->nom));

            foreach ($matieresClasse as $matiere) {
                $evalsMatiere = $evalsIndex->get($matiere->id, collect());

                $devoir = $evalsMatiere->get('Devoir')->note ?? 0;
                $compo  = $evalsMatiere->get('Composition')->note ?? 0;

                $moy = ($devoir + $compo) / 2;
                $coef = $matiere->coefficient ?? 1;

                $totalCoefNotes += $moy * $coef;
                $totalCoef += $coef;

                $notesParMatiere[$matiere->id] = [
                    'matiere' => $matiere,
                    'devoir'  => $devoir,
                    'compo'   => $compo,
                    'moyenne' => $moy,
                    'coef'    => $coef,
                    'moycoef' => $moy * $coef,
                ];
            }

            // ✅ Moyenne réelle AVEC toutes matières
            $moyenneEleve = $totalCoef > 0 ? round($totalCoefNotes / $totalCoef, 2) : 0;
// 1️⃣ Récupérer les inscriptions des élèves de la classe pour l'année
            $inscriptions = Inscription::where('classe_id', $idclasse)
                ->where('annee_id', $inscription->annee_id)
                ->pluck('id');

// 2️⃣ Récupérer toutes les évaluations pour ces inscriptions et ce découpage
            $evaluationsAll = Evaluation::with(['typeEvaluation', 'matiere'])
                ->whereIn('inscription_id', $inscriptions)
                ->where('decoupage_id', $decoupageId)
                ->get()
                ->groupBy('inscription_id'); // regroupe par élève

// 3️⃣ Récupérer toutes les matières affectées à la classe
            $matieresClasse = Affectation::with('matiere')
                ->where('classe_id', $idclasse)
                ->get()
                ->pluck('matiere');

// 🔹 Optimisation : indexer les évaluations par matière et type pour chaque élève
            $evaluationsIndex = $evaluationsAll->map(function ($notes) {
                return $notes->groupBy('matiere_id')->map(fn($matiereNotes) =>
                $matiereNotes->keyBy(fn($e) => $e->typeEvaluation->nom)
                );
            });

// 🔹 Calcul des moyennes de la classe
            $moyennesClasse = $evaluationsIndex->map(function ($evalsParMatiere) use ($matieresClasse) {
                $totalPoints = 0;
                $totalCoef = 0;

                foreach ($matieresClasse as $matiere) {
                    $coef = $matiere->coefficient ?? 1;

                    $matiereNotes = $evalsParMatiere->get($matiere->id, collect());
                    $devoir = $matiereNotes->get('Devoir')->note ?? 0;
                    $compo  = $matiereNotes->get('Composition')->note ?? 0;

                    $moy = ($devoir + $compo) / 2;

                    $totalPoints += $moy * $coef;
                    $totalCoef += $coef;
                }

                return $totalCoef > 0 ? $totalPoints / $totalCoef : 0;
            });


// --- CLASSEMENT DES MOYENNES ---
// On récupère directement les moyennes uniques triées décroissantes
            $uniqueMoyennesDesc = $moyennesClasse->unique()->sortDesc()->values();

// Calcul du rang général de l'élève
            $rangGeneral = $uniqueMoyennesDesc->search(fn($m) => round($m,2) === round($moyenneEleve,2)) + 1 ?? $moyennesClasse->count();

// Stats de la classe
            $plusForte = $moyennesClasse->max();
            $plusFaible = $moyennesClasse->min();
            $moyenneGeneraleClasse = $moyennesClasse->avg();

// Appréciation
            $app = match (true) {
                $moyenneEleve >= 17 => "Excellent",
                $moyenneEleve >= 16 => "T.Bien",
                $moyenneEleve >= 14 => "Bien",
                $moyenneEleve >= 12 => "A.Bien",
                $moyenneEleve >= 10 => "Passable",
                $moyenneEleve >= 8  => "Insuffisant",
                $moyenneEleve >= 6  => "T.Insuffisant",
                default              => "Médiocre",
            };

// 🔹 Vérifier si c’est le dernier découpage
            $nomDecoupage = strtolower(trim($decoupage->nom));
            $dernierDecoupage = str_contains($nomDecoupage, 'trimestre')
                ? str_contains($nomDecoupage, '3')  // 3ème trimestre = dernier
                : (str_contains($nomDecoupage, 'semestre') ? str_contains($nomDecoupage, '2') : false);

// 🔹 Initialisation moyenne annuelle
            $moyenneAnnuelle = null;
            $recap_annuelle = null;


            if ($dernierDecoupage) {
                // 🔹 Récupérer toutes les moyennes annuelles de la classe en une seule requête
                $elevesClasseIds = Inscription::where('classe_id', $inscription->classe_id)
                    ->where('annee_id', $inscription->annee_id)
                    ->pluck('id');

                $decoupagesIds = Decoupage::where('annee_id', $decoupage->annee_id)->pluck('id');

                // Moyennes annuelles par élève
                $moyennesAnnClasse = Moyenne::whereIn('inscription_id', $elevesClasseIds)
                    ->whereIn('decoupage_id', $decoupagesIds)
                    ->selectRaw('inscription_id, AVG(moyenne) as moyenne_annuelle')
                    ->groupBy('inscription_id')
                    ->get();

                // 🔹 Calcul de la moyenne annuelle de l'élève courant
                $moyenneAnnuelle = round(
                    $moyennesAnnClasse->where('inscription_id', $inscription->id)->avg('moyenne_annuelle'),
                    2
                );

                // 🔹 Appréciation annuelle
                $appAnnuelle = match (true) {
                    $moyenneAnnuelle >= 17 => "Excellent",
                    $moyenneAnnuelle >= 16 => "T.Bien",
                    $moyenneAnnuelle >= 14 => "Bien",
                    $moyenneAnnuelle >= 12 => "A.Bien",
                    $moyenneAnnuelle >= 10 => "Passable",
                    $moyenneAnnuelle >= 8  => "Insuffisant",
                    $moyenneAnnuelle >= 6  => "T.Insuffisant",
                    default                => "Médiocre",
                };

                // 🔹 Classement annuel
                $moyennesAnnClasse = $moyennesAnnClasse->sortByDesc('moyenne_annuelle')->values();
                $rangAnnuel = $moyennesAnnClasse->search(fn($m) => $m->inscription_id == $inscription->id) + 1;

                // 🔹 Récap annuel
                $recap_annuelle = [
                    'moyenne' => $moyenneAnnuelle,
                    'appreciation' => $appAnnuelle,
                    'rang' => $rangAnnuel,
                ];
            }


            $moyennesToUpsert[] = [
                'inscription_id' => $inscription->id,
                'decoupage_id'   => $decoupageId,
                'moyenne'        => round($moyenneEleve, 2),
                'rang'           => $rangGeneral,
                'appreciation'   => $app,
                'moyenne_annuelle'      => $dernierDecoupage ? $moyenneAnnuelle : null,
                'rang_annuel'           => $dernierDecoupage ? $rangAnnuel : null,
                'appreciation_annuelle' => $dernierDecoupage ? $appAnnuelle : null,
            ];


// ✅ SAUVEGARDE MOYENNE ÉLÈVE
            Moyenne::updateOrCreate(
                [
                    'inscription_id' => $inscription->id,
                    'decoupage_id'   => $decoupageId,
                ],
                [
                    'moyenne'      => round($moyenneEleve, 2),
                    'rang'         => $rangGeneral,
                    'appreciation' => $app,

                    'moyenne_annuelle'      => $dernierDecoupage ? $moyenneAnnuelle : null,
                    'rang_annuel'           => $dernierDecoupage ? $rangAnnuel : null,
                    'appreciation_annuelle' => $dernierDecoupage ? $appAnnuelle : null,
                ]
            );

// ✅ SAUVEGARDE MOYENNE CLASSE
            MoyenneGenerale::updateOrCreate(
                [
                    'classe_id'    => $idclasse,
                    'annee_id'     => $inscription->annee_id,
                    'decoupage_id' => $decoupageId,
                ],
                [
                    'moyenne_classe'   => round($moyenneGeneraleClasse, 2),
                    'moyenne_forte'    => round($plusForte, 2),
                    'moyenne_faible'   => round($plusFaible, 2),
                ]
            );

            // 2️⃣ Jointure entre moyennes (élève) et moyennes_generales (classe)
            $recapEleve = Moyenne::query()
                ->where('moyennes.inscription_id', $inscription->id)

                // Jointure pour récupérer la classe de l'élève
                ->join('inscriptions', 'inscriptions.id', '=', 'moyennes.inscription_id')

                // Jointure filtrée par période + année + classe
                ->join('moyennes_generales', function ($join) use ($anneeId) {
                    $join->on('moyennes.decoupage_id', '=', 'moyennes_generales.decoupage_id')
                        ->on('inscriptions.classe_id', '=', 'moyennes_generales.classe_id')
                        ->where('moyennes_generales.annee_id', '=', $anneeId);
                })

                ->join('decoupages', 'decoupages.id', '=', 'moyennes.decoupage_id')

                ->select(
                    'decoupages.nom as periode',
                    'moyennes.moyenne as moyenne_eleve',
                    'moyennes.rang',
                    'moyennes.appreciation',
                    'moyennes_generales.moyenne_classe',
                    'moyennes_generales.moyenne_forte',
                    'moyennes_generales.moyenne_faible',
                )

                ->orderBy('moyennes.decoupage_id')
                ->get();

//var_dump($recap);
            // 🔹 Stockage de tout dans le tableau global
            $allBulletins[] = [
                'inscription'       => $inscription,
                'evaluations'       => $evaluations,
                'rangsMatieres'     => $rangsMatieres,
                'statsMatieres'     => $statsMatieres,
                'moyenneEleve'      => $moyenneEleve,
                'rangGeneral'       => $rangGeneral,
                'appreciation'      => $app,
                'effectif'          => $effectif,
                'plusForte'         => $plusForte,
                'plusFaible'        => $plusFaible,
                'moyenneGeneraleClasse' => $moyenneGeneraleClasse,
                'recap' => $recapEleve,
                'notesParMatiere' => $notesParMatiere,
                'recap_annuelle' => $recap_annuelle,

            ];
        }

       // exit(0);
        logAction(
            'Consultation bulletins par découpage',
            "Consultation du bulletin collectif pour le découpage  {$decoupage->nom} de l'annee {$decoupage->annee->nom}");
        return view($view, compact('decoupage', 'ecole', 'allBulletins'));
    }


    public function proclamation($classeId, $decoupageId)
    {
        // 1️⃣ Vérifie d'abord si l'utilisateur est connecté
        if (!auth()->check()) {
            return redirect()->route('login')->with('error', 'Veuillez vous connecter pour accéder à cette page.');
        }

        // 2️⃣ Vérifie si l'utilisateur connecté est admin ou directeur
        if (!in_array(auth()->user()->role, ['admin', 'directeur','secretaire'])) {
            return redirect()->back()->with('error', 'Accès refusé. Vous n\'avez pas les autorisations nécessaires.');
        }

        // ✅ recalcul auto AVANT affichage
        $this->calculerEtSauvegarderMoyennes($classeId, $decoupageId);

        $classe    = \App\Models\Classe::with('inscriptions.eleve')->findOrFail($classeId);
        $decoupage = \App\Models\Decoupage::findOrFail($decoupageId);

        // 🔹 Vérifier si on est au dernier découpage (3ème trimestre ou 2ème semestre)
        $nomDecoupage = strtolower(trim($decoupage->nom));
        $estDernierDecoupage = false;

        if(str_contains($nomDecoupage, 'trimestre')) {
            $estDernierDecoupage = str_contains($nomDecoupage, '3'); // 3ème trimestre
        } elseif(str_contains($nomDecoupage, 'semestre')) {
            $estDernierDecoupage = str_contains($nomDecoupage, '2'); // 2ème semestre
        }

        // ✅ récupérer les moyennes
        $moyennes = \App\Models\Moyenne::with('inscription.eleve')
            ->whereHas('inscription', function($q) use ($classeId){
                $q->where('classe_id', $classeId);
            })
            ->where('decoupage_id', $decoupageId)
            ->orderBy('rang')
            ->get();

        return view('bulletins.proclamation', compact(
            'classe',
            'decoupage',
            'moyennes',
            'estDernierDecoupage'
        ));
    }



    public function bulletinParEleve($inscriptionId)
    {
        $ecole = \App\Models\Ecole::first();

        $inscription = \App\Models\Inscription::with(['eleve','classe','annee'])
            ->findOrFail($inscriptionId);

        $anneeId  = $inscription->annee_id;
        $idclasse = $inscription->classe_id;

        // ===========================
        // EFFECTIF CLASSE
        // ===========================
        $inscriptionsClasse = \App\Models\Inscription::where('classe_id', $idclasse)
            ->where('annee_id',$anneeId)
            ->pluck('id');

        $effectif = $inscriptionsClasse->count();

        // ===========================
        // MATIÈRES AFFECTÉES À LA CLASSE
        // ===========================
        $matieresClasse = \App\Models\Affectation::with('matiere')
            ->where('classe_id',$idclasse)
            ->where('annee_id',$anneeId)
            ->get()
            ->pluck('matiere');

        $decoupages = \App\Models\Decoupage::all();

        $groupedEvaluations = [];
        $rangsMatieres = [];
        $statsMatieres = [];

        foreach ($decoupages as $decoupage) {

            // ===========================
            // NOTES DE L'ÉLÈVE
            // ===========================
            $evaluationsEleve = \App\Models\Evaluation::with(['matiere','typeEvaluation'])
                ->where('inscription_id',$inscriptionId)
                ->where('decoupage_id',$decoupage->id)
                ->get();

            // On crée un tableau avec **toutes les matières** et note = 0 si absent
            $evaluationsComplete = $matieresClasse->map(function ($matiere) use ($evaluationsEleve) {
                $evalMatiere = $evaluationsEleve->where('matiere_id', $matiere->id);

                $devoir = $evalMatiere->firstWhere('typeEvaluation.nom','Devoir')?->note ?? 0;
                $compo  = $evalMatiere->firstWhere('typeEvaluation.nom','Composition')?->note ?? 0;

                return [
                    'matiere' => $matiere,
                    'devoir'  => $devoir,
                    'compo'   => $compo,
                    'moyenne'=> ($devoir + $compo)/2,
                    'coef'   => $matiere->coefficient ?? 1
                ];
            });

            $groupedEvaluations[$decoupage->id] = $evaluationsComplete;

            // ===========================
            // TOUTES NOTES DE LA CLASSE
            // ===========================
            $evaluationsClasse = \App\Models\Evaluation::with(['matiere','typeEvaluation'])
                ->whereIn('inscription_id',$inscriptionsClasse)
                ->where('decoupage_id',$decoupage->id)
                ->get()
                ->groupBy('inscription_id');

            // ===========================
            // MOYENNES CLASSE
            // ===========================
            $moyennesClasse = collect();

            foreach ($inscriptionsClasse as $inscId) {

                $totalPoints = 0;
                $totalCoef   = 0;

                foreach ($matieresClasse as $matiere) {

                    $coef = $matiere->coefficient ?? 1;

                    // ✅ CORRECTION: éviter Undefined array key
                    $evalsEleve = $evaluationsClasse->get($inscId, collect())
                        ->where('matiere_id', $matiere->id);

                    $devoir = $evalsEleve->firstWhere('typeEvaluation.nom','Devoir')?->note ?? 0;
                    $compo  = $evalsEleve->firstWhere('typeEvaluation.nom','Composition')?->note ?? 0;

                    $moy = ($devoir + $compo)/2;

                    $totalPoints += $moy * $coef;
                    $totalCoef   += $coef;
                }


                $moyennesClasse[$inscId] = $totalCoef > 0 ? round($totalPoints/$totalCoef,2) : 0;
            }

            if ($moyennesClasse->isEmpty()) continue;

            // ===========================
            // MOYENNE ET RANG DE L'ÉLÈVE
            // ===========================
            $moyenneEleve = $moyennesClasse[$inscriptionId] ?? 0;

            $sortedClasse = $moyennesClasse->sortDesc()->values();

            $rangGeneral = $sortedClasse->search($moyenneEleve);
            $rangGeneral = $rangGeneral !== false ? $rangGeneral + 1 : null;

            // ===========================
            // STATS CLASSE
            // ===========================
            $moyenneGeneraleClasse = round($moyennesClasse->avg(),2);
            $plusForte  = round($moyennesClasse->max(),2);
            $plusFaible = round($moyennesClasse->min(),2);

            // ===========================
            // APPRÉCIATION
            // ===========================
            $app = match(true) {
                $moyenneEleve >= 16 => 'Très Bien',
                $moyenneEleve >= 14 => 'Bien',
                $moyenneEleve >= 12 => 'Assez Bien',
                $moyenneEleve >= 10 => 'Passable',
                default => 'Insuffisant',
            };

            // ===========================
            // SAUVEGARDES ROW ÉLÈVE
            // ===========================
            Moyenne::updateOrCreate(
                [
                    'inscription_id' => $inscriptionId,
                    'decoupage_id'   => $decoupage->id,
                ],
                [
                    'moyenne'      => $moyenneEleve,
                    'rang'         => $rangGeneral,
                    'appreciation' => $app,
                ]
            );

            // ===========================
            // SAUVEGARDES CLASSE
            // ===========================
            MoyenneGenerale::updateOrCreate(
                [
                    'classe_id'    => $idclasse,
                    'annee_id'     => $anneeId,
                    'decoupage_id' => $decoupage->id,
                ],
                [
                    'moyenne_classe'   => $moyenneGeneraleClasse,
                    'moyenne_forte'    => $plusForte,
                    'moyenne_faible'   => $plusFaible,
                    'moyenne_annuelle' => null,
                ]
            );
        }

        // ===========================
        // RECAP BULLETIN
        // ===========================
        $recap = Moyenne::query()
            ->where('moyennes.inscription_id', $inscriptionId)
            ->join('inscriptions', 'inscriptions.id','=','moyennes.inscription_id')
            ->join('moyennes_generales', function ($join) use ($anneeId) {
                $join->on('moyennes.decoupage_id','=','moyennes_generales.decoupage_id')
                    ->on('inscriptions.classe_id','=','moyennes_generales.classe_id')
                    ->where('moyennes_generales.annee_id',$anneeId);
            })
            ->join('decoupages','decoupages.id','=','moyennes.decoupage_id')
            ->select(
                'decoupages.nom as periode',
                'moyennes.moyenne as moyenne_eleve',
                'moyennes.rang',
                'moyennes.appreciation',
                'moyennes_generales.moyenne_classe',
                'moyennes_generales.moyenne_forte',
                'moyennes_generales.moyenne_faible',
                'moyennes_generales.moyenne_annuelle'
            )
            ->orderBy('moyennes.decoupage_id')
            ->get();

        // ===========================
        // LOG
        // ===========================
        logAction(
            'Consultation bulletin élève',
            "Bulletin consulté pour {$inscription->eleve->nom} {$inscription->eleve->prenom} |
         Classe: {$inscription->classe->nom} |
         Année: {$inscription->annee->nom}"
        );

        // ===========================
        // VIEW
        // ===========================
        return view('bulletins.par_eleve', compact(
            'inscription',
            'ecole',
            'effectif',
            'groupedEvaluations',
            'rangsMatieres',
            'statsMatieres',
            'recap'
        ));
    }
}




