<?php $__env->startSection('title', 'Gestion des absences'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <div class="pro-breadcrumb">
            <div class="breadcrumb-title">
                Gestion des absences
            </div>
            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Ajouter des absences
                    </li>
                </ol>
            </div>
        </div>
        
        <form method="GET" class="row g-2 mb-4">
            <div class="col-md-3">
                <select name="classe_id" class="form-control">
                    <option value="">— Classe —</option>
                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($classe->id); ?>" <?php if(request('classe_id')==$classe->id): echo 'selected'; endif; ?>>
                            <?php echo e($classe->nom); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-3">
                <select name="decoupage_id" class="form-control">
                    <option value="">— Découpage —</option>
                    <?php $__currentLoopData = $decoupages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($d->id); ?>" <?php if(request('decoupage_id')==$d->id): echo 'selected'; endif; ?>>
                            <?php echo e($d->nom); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-2">
                <button class="btn btn-primary w-100">Filtrer</button>
            </div>
        </form>

        
        <div class="mb-3 text-end">
            <button class="btn btn-primary" data-toggle="modal" data-target="#addAbsenceModal">
                ➕ Ajouter une absence
            </button>
        </div>

        
        <div class="modal fade" id="addAbsenceModal" tabindex="-1">
            <div class="modal-dialog modal-xl">
                <form method="POST" action="<?php echo e(route('absences.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Ajouter une absence</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>

                        <div class="modal-body">
                            
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <label>Classe</label>
                                    <select name="classe_id" id="classeSelect" class="form-control" required>
                                        <option value="">— Sélectionner une classe —</option>
                                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($classe->id); ?>"><?php echo e($classe->nom); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-md-4">
                                    <label>Élève</label>
                                    <select name="inscription_id" id="eleveSelect" class="form-control" required>
                                        <option value="">— Sélectionner un élève —</option>
                                        
                                    </select>
                                </div>


                                <div class="col-md-4">
                                    <label>Découpage</label>
                                    <select name="decoupage_id" class="form-control" required>
                                        <?php $__currentLoopData = $decoupages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($d->id); ?>"><?php echo e($d->nom); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            
                            <table class="table table-bordered absenceTable">
                                <thead class="table-light">
                                <tr>
                                    <th>Matière</th>
                                    <th>Heures</th>
                                    <th>Justifié</th>
                                    <th width="50"></th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>
                                        <select name="absences[0][matiere_id]" class="form-control" required>
                                            <?php $__currentLoopData = $matieres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($m->id); ?>"><?php echo e($m->nom); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>
                                    <td>
                                        <input type="number" name="absences[0][heures]" class="form-control" min="0.5" step="0.5" required>
                                    </td>
                                    <td class="text-center">
                                        <input type="checkbox" name="absences[0][is_justified]" value="1">
                                    </td>
                                    <td class="text-center">
                                        <button type="button" class="btn btn-danger btn-sm removeRow">✕</button>
                                    </td>
                                </tr>
                                </tbody>
                            </table>

                            <button type="button" class="btn btn-outline-primary addRow">➕ Ajouter une ligne</button>
                        </div>

                        <div class="modal-footer">
                            <button class="btn btn-success">Enregistrer</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        

        <?php if($absences->isEmpty()): ?>
            <div class="alert alert-info text-center">
                Aucune absence enregistrée pour l'année scolaire <strong><?php echo e($anneeActive->nom); ?></strong>.
            </div>
        <?php else: ?>
            <div class="card shadow-sm">
                <div class="card-body p-0">
                    <table class="table table-hover table-bordered mb-0">
                        <thead class="table-light">
                        <tr>
                            <th>Élève</th>
                            <th>Classe</th>
                            <th>Total Heures</th>
                            <th width="150">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $absences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eleveId => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $inscription = $data['inscription']; ?>
                            <tr>
                                <td><?php echo e($inscription->eleve->nom); ?> <?php echo e($inscription->eleve->prenom); ?></td>
                                <td><?php echo e($inscription->classe->nom); ?></td>
                                <td class="text-center"><?php echo e($data['total_heures']); ?> h</td>
                                <td class="text-center">
                                    
                                    <a href="<?php echo e(route('absences.show', $inscription->id)); ?>" class="btn btn-sm btn-info">
                                        Voir
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>

            <div class="mt-3">
                
            </div>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('click', function (e) {
            // ➕ Ajouter ligne dans modal ajout
            if (e.target.classList.contains('addRow')) {
                let table = e.target.closest('.modal-body').querySelector('.absenceTable tbody');
                let index = table.children.length;

                table.insertAdjacentHTML('beforeend', `
        <tr>
            <td>
                <select name="absences[${index}][matiere_id]" class="form-control" required>
                    <?php $__currentLoopData = $matieres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($m->id); ?>"><?php echo e($m->nom); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
            <td>
                <input type="number" name="absences[${index}][heures]" class="form-control" min="0.5" step="0.5" required>
            </td>
            <td class="text-center">
                <input type="checkbox" name="absences[${index}][is_justified]" value="1">
            </td>
            <td class="text-center">
                <button type="button" class="btn btn-danger btn-sm removeRow">✕</button>
            </td>
        </tr>
        `);
            }

            // ❌ Supprimer ligne
            if (e.target.classList.contains('removeRow')) {
                e.target.closest('tr').remove();
            }
        });

            document.addEventListener('DOMContentLoaded', function () {
            const classeSelect = document.getElementById('classeSelect');
            const eleveSelect = document.getElementById('eleveSelect');

            classeSelect.addEventListener('change', function () {
            const classeId = this.value;
            eleveSelect.innerHTML = '<option value="">Chargement...</option>';

            if (!classeId) {
            eleveSelect.innerHTML = '<option value="">— Sélectionner un élève —</option>';
            return;
        }

            fetch(`/api/eleves?classe_id=${classeId}`)
            .then(res => res.json())
            .then(data => {
            eleveSelect.innerHTML = '<option value="">— Sélectionner un élève —</option>';
            data.forEach(eleve => {
            const option = document.createElement('option');
            option.value = eleve.id;
            option.text = `${eleve.nom} ${eleve.prenom}`;
            eleveSelect.appendChild(option);
        });
        })
            .catch(() => {
            eleveSelect.innerHTML = '<option value="">Erreur de chargement</option>';
        });
        });
        });


    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/absence/index.blade.php ENDPATH**/ ?>