<?php $__env->startSection('content'); ?>
    <div class="container py-4">

        
        <div class="pro-breadcrumb">
            <div class="breadcrumb-title">
                Gestion des Dépenses
            </div>
            <button class="btn btn-outline-info mb-3" data-toggle="modal" data-target="#addModal" style="margin-bottom: 10px">Ajouter une dépense</button>
            
            <form method="GET" action="<?php echo e(route('depenses.print')); ?>" target="_blank" class="row g-1 mb-2">
                <div class="col-md-2">
                    <input type="date" name="date_start" class="form-control" required value="<?php echo e(request('date_start')); ?>">
                </div>
                <div class="col-md-2">
                    <input type="date" name="date_end" class="form-control" required value="<?php echo e(request('date_end')); ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-success w-100">🖨️ Imprimer</button>
                </div>
            </form>



            
            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/">Dashboard</a></li>
                    <li class="breadcrumb-item active">Les dépenses</li>
                </ol>
            </div>
        </div>

            

        <div class="card mb-4 shadow-sm">
            <div class="card-header bg-info text-white">Dépenses</div>
            <div class="card-body table-responsive">
          <table class="table table-bordered table-hover table-striped">
                    <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>Titre</th>
                <th>Description</th>
                <th>Montant (FCFA)</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $depenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($d->id); ?></td>
                    <td><?php echo e($d->titre); ?></td>
                    <td><?php echo e($d->description); ?></td>
                    <td><?php echo e(number_format($d->montant, 0, ',', ' ')); ?></td>
                    <td><?php echo e($d->date_depense->format('d/m/Y')); ?></td>
                    <td>
                        <button class="btn btn-sm btn-warning" data-toggle="modal" data-target="#editModal<?php echo e($d->id); ?>">Éditer</button>
                        <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#deleteDepense<?php echo e($d->id); ?>">
                            Supprimer
                        </button>

                    </td>
                </tr>
                <!-- Modal Suppression Dépense -->
                <div class="modal fade" id="deleteDepense<?php echo e($d->id); ?>" tabindex="-1" aria-labelledby="deleteDepenseLabel<?php echo e($d->id); ?>" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header bg-danger text-white">
                                <h5 class="modal-title" id="deleteDepenseLabel<?php echo e($d->id); ?>">🗑️ Confirmer la suppression</h5>
                                <button type="button" class="btn-close btn-close-white" data-dismiss="modal" aria-label="Fermer"></button>
                            </div>
                            <div class="modal-body">
                                Voulez-vous vraiment supprimer la dépense : <strong><?php echo e($d->titre); ?></strong> ?
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                <form action="<?php echo e(route('depenses.destroy', $d)); ?>" method="POST" style="display:inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Oui, Supprimer</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="modal fade" id="editModal<?php echo e($d->id); ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <form method="POST" action="<?php echo e(route('depenses.update', $d)); ?>">
                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Modifier dépense</h5>
                                    <button type="button" class="btn-close" data-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="mb-2">
                                        <label>Titre</label>
                                        <input type="text" name="titre" class="form-control" value="<?php echo e($d->titre); ?>" required>
                                    </div>
                                    <div class="mb-2">
                                        <label>Description</label>
                                        <textarea name="description" class="form-control"><?php echo e($d->description); ?></textarea>
                                    </div>
                                    <div class="mb-2">
                                        <label>Montant</label>
                                        <input type="number" name="montant" class="form-control" value="<?php echo e($d->montant); ?>" required>
                                    </div>
                                    <div class="mb-2">
                                        <label>Date</label>
                                        <input type="date" name="date_depense" class="form-control" value="<?php echo e($d->date_depense->format('Y-m-d')); ?>" required>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                    <button class="btn btn-success">Enregistrer</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
            </div>
            </div>
            </div>
        
        <div class="modal fade" id="addModal" tabindex="-1">
            <div class="modal-dialog">
                <form method="POST" action="<?php echo e(route('depenses.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Ajouter une dépense</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-2">
                                <label>Titre</label>
                                <input type="text" name="titre" class="form-control" required>
                            </div>
                            <div class="mb-2">
                                <label>Description</label>
                                <textarea name="description" class="form-control"></textarea>
                            </div>
                            <div class="mb-2">
                                <label>Montant</label>
                                <input type="number" name="montant" class="form-control" required>
                            </div>
                            <div class="mb-2">
                                <label>Date</label>
                                <input type="date" name="date_depense" class="form-control" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                            <button class="btn btn-success">Ajouter</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            function printFiltered() {
                let printContents = document.querySelector('.card-body table').outerHTML;
                let originalContents = document.body.innerHTML;

                document.body.innerHTML = `
            <h3 class="text-center">Dépenses imprimées</h3>
            ${printContents}
        `;
                window.print();
                document.body.innerHTML = originalContents;
                window.location.reload(); // recharge pour réinitialiser les modals et scripts
            }
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/depenses/index.blade.php ENDPATH**/ ?>