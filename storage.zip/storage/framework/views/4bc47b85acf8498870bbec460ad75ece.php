<?php $__env->startSection('content'); ?>
    <div class="container py-4">

        
        <div class="pro-breadcrumb">
            <div class="breadcrumb-title">
                💰 Salaires & Rémunérations
            </div>

            
            <form action="<?php echo e(route('salaires.pdf')); ?>" method="POST" target="_blank">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="date_debut" value="<?php echo e($dateDebut ?? ''); ?>" required>
                <input type="hidden" name="date_fin" value="<?php echo e($dateFin ?? ''); ?>" required>
                <button type="submit" class="btn btn-dark mb-3">
                    <i class="fas fa-file-pdf"></i> Imprimer PDF Global
                </button>
            </form>



            
            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/">Dashboard</a></li>
                    <li class="breadcrumb-item active">Salaires & Rémunérations</li>
                </ol>
            </div>
        </div>

        
        <div class="card mb-4 shadow-sm">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">Calcul des salaires</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('salaires.calculer')); ?>" method="POST" class="row g-3">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-4">
                        <label>Date début</label>
                        <input type="date" name="date_debut" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label>Date fin</label>
                        <input type="date" name="date_fin" class="form-control" required>
                    </div>
                    <div class="col-md-4 align-self-end">
                        <button class="btn btn-success w-100">Calculer</button>
                    </div>
                </form>
            </div>
        </div>

        
        <?php if(isset($enseignantsPrimaire)): ?>
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-primary text-white">Enseignants - Primaire</div>
                <div class="card-body table-responsive">
                    <table class="table table-bordered table-hover table-striped">
                        <thead class="table-light">
                        <tr>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Niveau</th>
                            <th>Salaire</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $enseignantsPrimaire; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($e['nom']); ?></td>
                                <td><?php echo e($e['prenom']); ?></td>
                                <td><?php echo e($e['niveau']); ?></td>
                                <td><?php echo e(number_format($e['salaire'], 2, ',', ' ')); ?> FCFA</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        
        <?php if(isset($enseignantsCollegeLycee)): ?>
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-warning text-white">Enseignants - Collège & Lycée</div>
                <div class="card-body table-responsive">
                    <table class="table table-bordered table-hover table-striped">
                        <thead class="table-light">
                        <tr>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Niveau</th>
                            <th>Nombre d'heures</th>
                            <th>Heures manquee(s)</th>
                            <th>Taux horaire</th>
                            <th>Salaire</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $enseignantsCollegeLycee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($e['nom']); ?></td>
                                <td><?php echo e($e['prenom']); ?></td>
                                <td><?php echo e($e['niveau']); ?></td>
                                <td><?php echo e($e['heures']); ?></td>
                                <td><?php echo e($e['heures_manquees']); ?></td>
                                <td><?php echo e(number_format($e['taux'], 2, ',', ' ')); ?> FCFA</td>
                                <td><?php echo e(number_format($e['salaire'], 2, ',', ' ')); ?> FCFA</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        
        <?php if(isset($personnel)): ?>
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-success text-white">Personnel administratif</div>
                <div class="card-body table-responsive">
                    <table class="table table-bordered table-hover table-striped">
                        <thead class="table-light">
                        <tr>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Poste</th>
                            <th>Salaire</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $personnel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($p['nom']); ?></td>
                                <td><?php echo e($p['prenom']); ?></td>
                                <td><?php echo e($p['poste']); ?></td>
                                <td><?php echo e(number_format($p['salaire'], 2, ',', ' ')); ?> FCFA</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
        <?php if(isset($grandTotalGlobal) && $grandTotalGlobal !== null): ?>
            <div class="alert alert-success fw-bold fs-5 text-end mt-4">
                GRAND TOTAL SALAIRES :
                <?php echo e(number_format($grandTotalGlobal, 0, ',', ' ')); ?> FCFA
            </div>
        <?php endif; ?>
    </div>

    
    <script>
        const basePersonnel = "<?php echo e(route('salaires.pdf', ['type'=>'personnel', 'mois'=>'__MOIS__'])); ?>";
        const baseEnseignant = "<?php echo e(route('salaires.pdf', ['type'=>'enseignant', 'mois'=>'__MOIS__'])); ?>";

        document.getElementById('pdfPersonnelBtn').addEventListener('click', function(e) {
            const mois = document.getElementById('moisPDF').value;
            if(!mois) return alert('Sélectionnez un mois');
            window.open(basePersonnel.replace('__MOIS__', mois), '_blank');
        });

        document.getElementById('pdfEnseignantBtn').addEventListener('click', function(e) {
            const mois = document.getElementById('moisPDF').value;
            if(!mois) return alert('Sélectionnez un mois');
            window.open(baseEnseignant.replace('__MOIS__', mois), '_blank');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/salaires/index.blade.php ENDPATH**/ ?>