<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="pro-breadcrumb">
            <div class="breadcrumb-title">
                Gestion des eleves
            </div>
            
            <div class="mb-3">
                <a href="<?php echo e(route('listeclasses.index')); ?>" class="btn btn-secondary">
                    📚 Liste des classes
                </a>
                <!-- Bouton qui ouvre le modal Ajout Élève -->
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addEleveModal">
                    ➕ Ajouter un élève
                </button>
            </div>
            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Eleves
                    </li>
                </ol>
            </div>
        </div>




            
            <div class="modal fade" id="addEleveModal" tabindex="-1" aria-labelledby="addEleveModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content shadow-lg border-0 rounded-3">
                        <div class="modal-header bg-primary text-white">
                            <h5 class="modal-title" id="addEleveModalLabel">➕ Ajouter un élève</h5>
                            <button type="button" class="btn-close btn-close-white" data-dismiss="modal"
                                    aria-label="Fermer"></button>
                        </div>
                        <div class="modal-body">
                            <form method="POST" action="<?php echo e(route('eleves.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label for="nom" class="form-label">Nom *</label>
                                        <input type="text" name="nom" class="form-control" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="prenom" class="form-label">Prénom *</label>
                                        <input type="text" name="prenom" class="form-control" required>
                                    </div>

                                    <?php
                                        $today = date('Y-m-d');
                                        $twoYearsAgo = date('Y-m-d', strtotime('-2 year'));
                                    ?>

                                    <div class="col-md-4">
                                        <label for="date_naissance" class="form-label">Date Naissance</label>
                                        <input type="date" name="date_naissance" class="form-control"
                                               max="<?php echo e($twoYearsAgo); ?>" min="1950-01-01">
                                    </div>

                                    <div class="col-md-4">
                                        <label for="lieudenaissance" class="form-label">Lieu de Naissance</label>
                                        <input type="text" name="lieudenaissance" class="form-control"
                                               value="">
                                    </div>

                                    <div class="col-md-4">
                                        <label for="sexe" class="form-label">Sexe</label>
                                        <select name="sexe" class="form-select">
                                            <option value="">-- Choisir --</option>
                                            <option value="M">Masculin</option>
                                            <option value="F">Féminin</option>
                                        </select>
                                    </div>

                                    <div class="col-md-4">
                                        <label for="classe_id" class="form-label">Classe</label>
                                        <select name="classe_id" class="form-select">
                                            <option value="" selected disabled>-- Sélectionner --</option>
                                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($classe->id); ?>"><?php echo e($classe->nom); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-4">
                                        <label for="adresse" class="form-label">Adresse</label>
                                        <input type="text" name="adresse" class="form-control">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="nationalite" class="form-label"> Nationalité</label>
                                        <input type="text"
                                               name="nationalite"
                                               id="nationalite"
                                               class="form-control"
                                               placeholder="Ex : Togolaise">
                                    </div>
                                    <div class="col-md-12">
                                        <label for="observation" class="form-label"> Observation</label>
                                        <textarea name="observation"
                                                  id="observation"
                                                  class="form-control"
                                                  rows="3"
                                                  placeholder="Remarques particulières concernant l'élève..."></textarea>
                                    </div>
                                    <div class="col-md-8">
                                        <label for="tuteur_nom" class="form-label">Nom & Prénom du Tuteur</label>
                                        <input type="text" name="tuteur_nom" class="form-control">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="tuteur_tel" class="form-label"> Téléphone du Tuteur</label>
                                        <div class="input-group">
                                            <span class="input-group-text">+228</span>
                                            <input type="tel" name="tuteur_tel" id="tuteur_tel" class="form-control"
                                                   placeholder="90 12 34 56"
                                                   pattern="[0-9]{8}" maxlength="8">
                                        </div>
                                        <small class="text-muted">Format : 8 chiffres (ex: 90123456)</small>
                                    </div>
                                    



                                </div>
                                <div class="mt-3 text-end">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                    <button type="submit" class="btn btn-success">✅ Enregistrer</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('eleves.index')); ?>">
                    <div class="row g-2 align-items-center">
                        <div class="col-md-10">
                            <div class="input-group">
                                <span class="input-group-text bg-light">🔍</span>
                                <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                                       class="form-control" placeholder="Rechercher un élève (nom, prénom, matricule)...">
                            </div>
                        </div>
                        <div class="col-md-2 text-end">
                            <button class="btn btn-primary w-100" type="submit">Rechercher</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        
        <div class="card shadow-sm">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0">Liste des élèves (<?php echo e($eleves->total()); ?>)</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover table-striped align-middle mb-0">
                        <thead class="table-primary">
                        <tr>
                            <th>
                                <a href="<?php echo e(route('eleves.index', ['sort' => 'matricule', 'direction' => request('direction') === 'asc' && request('sort') === 'matricule' ? 'desc' : 'asc'])); ?>">
                                    Matricule
                                    <i class="fas fa-sort<?php echo e(request('sort') === 'matricule' ? '-' . (request('direction') === 'asc' ? 'up' : 'down') : ''); ?>"></i>
                                </a>
                            </th>
                            <th>
                                <a href="<?php echo e(route('eleves.index', ['sort' => 'nom', 'direction' => request('direction') === 'asc' && request('sort') === 'nom' ? 'desc' : 'asc'])); ?>">
                                    Nom
                                    <i class="fas fa-sort<?php echo e(request('sort') === 'nom' ? '-' . (request('direction') === 'asc' ? 'up' : 'down') : ''); ?>"></i>
                                </a>
                            </th>
                            <th>
                                <a href="<?php echo e(route('eleves.index', ['sort' => 'prenom', 'direction' => request('direction') === 'asc' && request('sort') === 'prenom' ? 'desc' : 'asc'])); ?>">
                                    Prénom
                                    <i class="fas fa-sort<?php echo e(request('sort') === 'prenom' ? '-' . (request('direction') === 'asc' ? 'up' : 'down') : ''); ?>"></i>
                                </a>
                            </th>
                            <th>
                                <a href="<?php echo e(route('eleves.index', ['sort' => 'date_naissance', 'direction' => request('direction') === 'asc' && request('sort') === 'date_naissance' ? 'desc' : 'asc'])); ?>">
                                    Date Naissance
                                    <i class="fas fa-sort<?php echo e(request('sort') === 'date_naissance' ? '-' . (request('direction') === 'asc' ? 'up' : 'down') : ''); ?>"></i>
                                </a>
                            </th>
                            <th>
                                <a href="<?php echo e(route('eleves.index', ['sort' => 'sexe', 'direction' => request('direction') === 'asc' && request('sort') === 'sexe' ? 'desc' : 'asc'])); ?>">
                                    Sexe
                                    <i class="fas fa-sort<?php echo e(request('sort') === 'sexe' ? '-' . (request('direction') === 'asc' ? 'up' : 'down') : ''); ?>"></i>
                                </a>
                            </th>
                            <th>Téléphone</th>
                            <th>Actions</th>
                        </tr>
                        </thead>


                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $eleves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eleve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($eleve->id); ?></td>
                                <td class="fw-bold"><?php echo e(strtoupper($eleve->nom)); ?></td>
                                <td><?php echo e(ucfirst($eleve->prenom)); ?></td>
                                <td><?php echo e($eleve->date_naissance ? $eleve->date_naissance->format('d/m/Y') : '-'); ?></td>
                                <td>
                            <span class="badge <?php echo e($eleve->sexe == 'M' ? 'bg-primary' : 'bg-pink'); ?>">
                                <?php echo e($eleve->sexe == 'M' ? 'Masculin' : 'Féminin'); ?>

                            </span>
                                </td>
                                <td><?php echo e($eleve->tuteur_tel); ?></td>
                                <td>
                                    <!-- Bouton Modifier -->
                                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal"
                                            data-target="#editEleve<?php echo e($eleve->id); ?>">
                                        ✏️
                                    </button>

                                    
                                    <!-- Bouton qui ouvre le modal -->
                                    <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#confirmDeleteEleve<?php echo e($eleve->id); ?>">
                                        🗑️
                                    </button>

                                    
                                    <!-- Bouton Activer/Désactiver -->
                                    <?php if($eleve->statut): ?>
                                        <button type="button" class="btn btn-warning btn-sm"
                                                data-toggle="modal" data-target="#toggleEleve<?php echo e($eleve->id); ?>">
                                            🚫
                                        </button>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-success btn-sm"
                                                data-toggle="modal" data-target="#toggleEleve<?php echo e($eleve->id); ?>">
                                            ✅
                                        </button>
                                    <?php endif; ?>

                                </td>
                            </tr>
                            <!-- Modal Confirmation Suppression Élève -->
                            <div class="modal fade" id="confirmDeleteEleve<?php echo e($eleve->id); ?>" tabindex="-1" aria-labelledby="confirmDeleteEleveLabel<?php echo e($eleve->id); ?>" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content shadow border-0 rounded-3">
                                        <div class="modal-header bg-danger text-white">
                                            <h5 class="modal-title" id="confirmDeleteEleveLabel<?php echo e($eleve->id); ?>">
                                                <i class="bi bi-exclamation-triangle-fill"></i> Confirmation
                                            </h5>
                                            <button type="button" class="btn-close btn-close-white" data-dismiss="modal" aria-label="Fermer"></button>
                                        </div>
                                        <div class="modal-body">
                                            Voulez-vous vraiment supprimer l'élève <strong><?php echo e($eleve->nom); ?> <?php echo e($eleve->prenom); ?></strong> ?
                                            <br>
                                            <small class="text-muted">Cette action est irréversible.</small>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>

                                            <form action="<?php echo e(route('eleves.destroy', $eleve->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">
                                                    Oui, Supprimer
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Modal Activer/Désactiver -->
                            <div class="modal fade" id="toggleEleve<?php echo e($eleve->id); ?>" tabindex="-1" aria-labelledby="toggleEleveLabel<?php echo e($eleve->id); ?>" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content shadow-lg border-0 rounded-3">

                                        <!-- Header -->
                                        <div class="modal-header <?php echo e($eleve->statut ? 'bg-warning' : 'bg-success'); ?> text-white">
                                            <h5 class="modal-title" id="toggleEleveLabel<?php echo e($eleve->id); ?>">
                                                <i class="bi <?php echo e($eleve->statut ? 'bi-person-dash-fill' : 'bi-person-check-fill'); ?>"></i>
                                                <?php echo e($eleve->statut ? 'Désactiver un élève' : 'Activer un élève'); ?>

                                            </h5>
                                            <button type="button" class="btn-close btn-close-white" data-dismiss="modal" aria-label="Fermer"></button>
                                        </div>

                                        <!-- Body -->
                                        <div class="modal-body">
                                            Voulez-vous vraiment
                                            <strong class="<?php echo e($eleve->statut ? 'text-warning' : 'text-success'); ?>">
                                                <?php echo e($eleve->statut ? 'désactiver' : 'activer'); ?>

                                            </strong>
                                            l’élève <strong><?php echo e($eleve->nom); ?> <?php echo e($eleve->prenom); ?></strong> ?
                                        </div>

                                        <!-- Footer -->
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>

                                            <form action="<?php echo e(route('eleves.toggle', $eleve->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn <?php echo e($eleve->statut ? 'btn-warning' : 'btn-success'); ?>">
                                                    Oui, <?php echo e($eleve->statut ? 'Désactiver' : 'Activer'); ?>

                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Modal Modifier Élève -->
                            <div class="modal fade" id="editEleve<?php echo e($eleve->id); ?>" tabindex="-1"
                                 aria-labelledby="editEleveLabel<?php echo e($eleve->id); ?>" aria-hidden="true">
                                <div class="modal-dialog modal-lg modal-dialog-centered">
                                    <div class="modal-content shadow-lg border-0 rounded-3">
                                        <div class="modal-header bg-info text-white">
                                            <h5 class="modal-title" id="editEleveLabel<?php echo e($eleve->id); ?>">
                                                ✏️ Modifier l’élève
                                            </h5>
                                            <button type="button" class="btn-close btn-close-white"
                                                    data-dismiss="modal" aria-label="Fermer"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form method="POST" action="<?php echo e(route('eleves.update', $eleve->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <div class="row g-3">
                                                    <div class="col-md-6">
                                                        <label for="nom" class="form-label">Nom *</label>
                                                        <input type="text" name="nom" class="form-control"
                                                               value="<?php echo e($eleve->nom); ?>" required>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label for="prenom" class="form-label">Prénom *</label>
                                                        <input type="text" name="prenom" class="form-control"
                                                               value="<?php echo e($eleve->prenom); ?>" required>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label for="date_naissance" class="form-label">Date Naissance</label>
                                                        <input type="date" name="date_naissance" class="form-control"
                                                               value="<?php echo e($eleve->date_naissance?->format('Y-m-d')); ?>">
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label for="lieudenaissance" class="form-label">Lieu de Naissance</label>
                                                        <input type="text" name="lieudenaissance" class="form-control"
                                                               value="<?php echo e($eleve->lieudenaissance); ?>">
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label for="sexe" class="form-label">Sexe</label>
                                                        <select name="sexe" class="form-select">
                                                            <option value="M" <?php echo e($eleve->sexe == 'M' ? 'selected' : ''); ?>>Masculin</option>
                                                            <option value="F" <?php echo e($eleve->sexe == 'F' ? 'selected' : ''); ?>>Féminin</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label for="classe_id" class="form-label">Classe</label>
                                                        <select name="classe_id" class="form-select">
                                                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="" selected disabled>-- Sélectionner --</option>
                                                                <option value="<?php echo e($classe->id); ?>"
                                                                    <?php echo e($eleve->classeActuelle?->classe?->id == $classe->id ? 'selected' : ''); ?>>
                                                                    <?php echo e($classe->nom); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label for="adresse" class="form-label">Adresse</label>
                                                        <input type="text" name="adresse" class="form-control"
                                                               value="<?php echo e($eleve->adresse); ?>">
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label for="nationalite" class="form-label"> Nationalité</label>
                                                        <input type="text"
                                                               name="nationalite"
                                                               id="nationalite"
                                                               class="form-control"
                                                               value="<?php echo e($eleve->nationalite); ?>">
                                                    </div>
                                                    <div class="col-md-12">
                                                        <label for="observation" class="form-label"> Observation</label>
                                                        <textarea name="observation"
                                                                  id="observation"
                                                                  class="form-control"
                                                                  rows="3"
                                                                  placeholder="Remarques particulières concernant l'élève..."><?php echo e($eleve->observation); ?></textarea>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label for="tuteur_nom" class="form-label">Nom du Tuteur</label>
                                                        <input type="text" name="tuteur_nom" class="form-control"
                                                               value="<?php echo e($eleve->tuteur_nom); ?>">
                                                    </div>
                                                    <div class="col-md-8">
                                                        <label for="tuteur_tel" class="form-label">Téléphone du Tuteur</label>
                                                        <div class="input-group">
                                                            <span class="input-group-text">+228</span>
                                                            <input type="tel" name="tuteur_tel" class="form-control"
                                                                   value="<?php echo e($eleve->tuteur_tel); ?>"
                                                                   pattern="[0-9]{8}" maxlength="8">
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                <div class="mt-3 text-end">
                                                    <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Annuler</button>
                                                    <button type="submit" class="btn btn-info">💾 Mettre à jour</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center text-muted">Aucun élève trouvé</td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>

                </div>
            </div>
            <div class="card-footer">
                <div class="d-flex justify-content-center">
                    <?php echo e($eleves->links('pagination::bootstrap-5')); ?>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/eleves/index.blade.php ENDPATH**/ ?>