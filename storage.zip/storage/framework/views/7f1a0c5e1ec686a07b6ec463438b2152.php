<?php $__env->startSection('content'); ?>
    <div class="container py-4">

        <div class="pro-breadcrumb">
            <div class="breadcrumb-title">
                💰 Salaires & Rémunérations
            </div>
            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/">Dashboard</a></li>
                    <li class="breadcrumb-item active">Salaires & Rémunérations</li>
                </ol>
            </div>
        </div>

        <div class="card mb-4 shadow-sm">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">Calcul des salaires</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('salaires.calculer')); ?>" method="POST" class="row g-3">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-4">
                        <label>Date début</label>
                        <input type="date" name="date_debut" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label>Date fin</label>
                        <input type="date" name="date_fin" class="form-control" required>
                    </div>
                    <div class="col-md-4 align-self-end">
                        <button class="btn btn-success w-100">Calculer</button>
                    </div>
                </form>
            </div>
        </div>

        <?php if(isset($enseignants)): ?>
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-primary text-white">Enseignants</div>
                <div class="card-body table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="table-light">
                        <tr>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Niveau</th>
                            <th>Salaire</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $enseignants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($e['nom']); ?></td>
                                <td><?php echo e($e['prenom']); ?></td>
                                <td><?php echo e($e['niveau']); ?></td>
                                <td><?php echo e(number_format($e['salaire'], 2, ',', ' ')); ?> FCFA</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <?php if(isset($personnel)): ?>
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-success text-white">Personnel administratif</div>
                <div class="card-body table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="table-light">
                        <tr>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Poste</th>
                            <th>Salaire</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $personnel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($p['nom']); ?></td>
                                <td><?php echo e($p['prenom']); ?></td>
                                <td><?php echo e($p['poste']); ?></td>
                                <td><?php echo e(number_format($p['salaire'], 2, ',', ' ')); ?> FCFA</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/salaires/index.blade.php ENDPATH**/ ?>
