<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="pro-breadcrumb">
            <div class="breadcrumb-title">
                Nouveau paiement
            </div>
            

            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('paiements.index')); ?>">Retour</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Les paiements
                    </li>
                </ol>
            </div>
        </div>

        <div class="card shadow-sm mt-3">

            <div class="card-body">
                <form action="<?php echo e(route('paiements.store')); ?>" method="POST">
                    <?php echo $__env->make('paiements.form', ['paiement' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <div class="mt-3">
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/paiements/create.blade.php ENDPATH**/ ?>