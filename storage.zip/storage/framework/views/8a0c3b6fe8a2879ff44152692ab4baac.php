<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Salaires - <?php echo e($dateDebut->format('d/m/Y')); ?> au <?php echo e($dateFin->format('d/m/Y')); ?></title>
    <style>
        body {
            font-family: "Segoe UI", Roboto, Arial, sans-serif;
            font-size: 12px;
            color: #1f2937;
            margin: 0;
            padding: 0;
        }
        .container {
            padding: 20px;
        }
        .header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #4a5568;
            padding-bottom: 10px;
        }
        .header img {
            height: 70px;
            margin-right: 15px;
        }
        .header .infos {
            line-height: 1.2;
        }
        .header .infos h1 {
            margin: 0;
            font-size: 20px;
            color: #1a202c;
        }
        .header .infos p {
            margin: 0;
            font-size: 12px;
            color: #4a5568;
        }
        h2 {
            margin-top: 30px;
            color: #1a202c;
            border-bottom: 1px solid #4a5568;
            padding-bottom: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            margin-bottom: 30px;
        }
        th, td {
            border: 1px solid #cbd5e0;
            padding: 6px 8px;
            text-align: left;
            font-size: 12px;
        }
        th {
            background-color: #edf2f7;
            color: #2d3748;
        }
        .text-right {
            text-align: right;
        }
        .footer {
            text-align: center;
            font-size: 10px;
            color: #718096;
            margin-top: 50px;
            border-top: 1px solid #cbd5e0;
            padding-top: 5px;
        }
    </style>
</head>
<body>
<div class="container">

    
    <?php
        $ecole = \App\Models\Ecole::first(); // tu peux filtrer par annee si besoin
    ?>
    <div class="header">

        <div class="infos">
            <h1><?php echo e($ecole->nom ?? 'Nom de l\'École'); ?></h1>
            <p><?php echo e($ecole->adresse ?? ''); ?></p>
            <p>Tél: <?php echo e($ecole->telephone ?? ''); ?> | Email: <?php echo e($ecole->email ?? ''); ?></p>
            <?php if($ecole->site_web): ?>
                <p>Site web: <?php echo e($ecole->site_web); ?></p>
            <?php endif; ?>
        </div>
    </div>

    
    <h2>Période: <?php echo e($dateDebut->format('d/m/Y')); ?> au <?php echo e($dateFin->format('d/m/Y')); ?></h2>

    
    <?php if(!empty($enseignantsPrimaire)): ?>
        <h2>Enseignants - Primaire</h2>
        <table>
            <thead>
            <tr>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Niveau</th>
                <th>Salaire</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $enseignantsPrimaire; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($e['nom']); ?></td>
                    <td><?php echo e($e['prenom']); ?></td>
                    <td><?php echo e($e['niveau']); ?></td>
                    <td class="text-right"><?php echo e(number_format($e['salaire'], 2, ',', ' ')); ?> FCFA</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>

    
    <?php if(!empty($enseignantsCollegeLycee)): ?>
        <h2>Enseignants - Collège & Lycée</h2>
        <table>
            <thead>
            <tr>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Niveau</th>
                <th>Nombre d'heures</th>
                <th>Heures manquee(s)</th>
                <th>Taux horaire</th>
                <th>Salaire</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $enseignantsCollegeLycee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($e['nom']); ?></td>
                    <td><?php echo e($e['prenom']); ?></td>
                    <td><?php echo e($e['niveau']); ?></td>
                    <td class="text-right"><?php echo e($e['heures']); ?></td>
                    <td><?php echo e($e['heures_manquees']); ?></td>
                    <td class="text-right"><?php echo e(number_format($e['taux'], 2, ',', ' ')); ?> FCFA</td>
                    <td class="text-right"><?php echo e(number_format($e['salaire'], 2, ',', ' ')); ?> FCFA</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>

    
    <?php if(!empty($personnel)): ?>
        <h2>Personnel administratif</h2>
        <table>
            <thead>
            <tr>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Poste</th>
                <th>Salaire</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $personnel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($p['nom']); ?></td>
                    <td><?php echo e($p['prenom']); ?></td>
                    <td><?php echo e($p['poste']); ?></td>
                    <td class="text-right"><?php echo e(number_format($p['salaire'], 2, ',', ' ')); ?> FCFA</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
    <div class="alert alert-success fw-bold fs-5 text-end mt-4">
        GRAND TOTAL SALAIRES :
        <?php echo e(number_format($grandTotalGlobal, 0, ',', ' ')); ?> FCFA
    </div>
    
    <div class="footer">
        Généré le <?php echo e(\Carbon\Carbon::now()->format('d/m/Y H:i')); ?> - SchoolPlus v1.12
    </div>
</div>
</body>
</html>
<?php /**PATH C:\wamp64\www\schoolplus\resources\views/salaires/pdf_global.blade.php ENDPATH**/ ?>