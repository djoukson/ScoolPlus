<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="pro-breadcrumb">
            <div class="breadcrumb-title">
                Présences des enseignants
            </div>
            <button class="btn btn-primary" style="margin-bottom: 10px" data-toggle="modal" data-target="#addModal">
                + Nouvelle présence
            </button>
            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Ajouter des présences
                    </li>
                </ol>
            </div>
        </div>

        
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
            <tr>
                <th>Date</th>
                <th>Enseignant</th>
                <th>Nombre d'Heures</th>
                <th>Motif</th>
                <th width="140">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $presences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($p->date); ?></td>
                    <td><?php echo e($p->enseignant->nom); ?> <?php echo e($p->enseignant->prenom); ?></td>
                    <td class="text-center"><?php echo e($p->nombre_heures); ?></td>
                    <td><?php echo e($p->motif); ?></td>
                    <td>
                        <button class="btn btn-sm btn-warning"
                                data-toggle="modal"
                                data-target="#editModal<?php echo e($p->id); ?>">
                            ✏
                        </button>

                        <form action="<?php echo e(route('presences-enseignants.destroy',$p)); ?>"
                              method="POST" class="d-inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger"
                                    onclick="return confirm('Supprimer cette présence ?')">
                                🗑
                            </button>
                        </form>
                    </td>
                </tr>

                
                <div class="modal fade" id="editModal<?php echo e($p->id); ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <form method="POST" action="<?php echo e(route('presences-enseignants.update',$p)); ?>">
                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Modifier présence</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>

                                <div class="modal-body">
                                    <div class="mb-2">
                                        <label>Enseignant</label>
                                        <select name="enseignant_id" class="form-control" required>
                                            <?php $__currentLoopData = $enseignants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($e->id); ?>"
                                                    <?php if($e->id == $p->enseignant_id): echo 'selected'; endif; ?>>
                                                    <?php echo e($e->nom); ?> <?php echo e($e->prenom); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="mb-2">
                                        <label>Date</label>
                                        <input type="date" name="date" class="form-control"
                                               value="<?php echo e($p->date); ?>" required>
                                    </div>

                                    <div class="row">
                                        <div class="col">
                                            <label>Heures prévues</label>
                                            <input type="number" name="nombre_heures"
                                                   class="form-control"
                                                   value="<?php echo e($p->nombre_heures); ?>">
                                        </div>
                                    </div>

                                    <div class="mt-2">
                                        <label>Motif</label>
                                        <input type="text" name="motif"
                                               class="form-control"
                                               value="<?php echo e($p->motif); ?>">
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <button class="btn btn-secondary" data-bs-dismiss="modal">
                                        Annuler
                                    </button>
                                    <button class="btn btn-success">
                                        Enregistrer
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    
    <div class="modal fade" id="addModal" tabindex="-1">
        <div class="modal-dialog">
            <form method="POST" action="<?php echo e(route('presences-enseignants.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Nouvelle présence</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <div class="modal-body">
                        <div class="mb-2">
                            <label>Enseignant</label>
                            <select name="enseignant_id" class="form-control" required>
                                <option value="" selected disabled>
                                    ---- Sélectionner le Prof ----
                                </option>

                                <?php $__currentLoopData = $enseignants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($e->id); ?>">
                                        <?php echo e($e->nom); ?> <?php echo e($e->prenom); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>

                        <div class="mb-2">
                            <label>Date</label>
                            <input type="date" name="date" class="form-control" required>
                        </div>

                        <div class="row">
                            <div class="col">
                                <label>Nombre d'Heures</label>
                                <input type="number" name="nombre_heures"
                                       class="form-control" min="1" value="1">
                            </div>
                        </div>

                        <div class="mt-2">
                            <label>Motif</label>
                            <input type="text" name="motif" class="form-control">
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button class="btn btn-secondary" data-bs-dismiss="modal">
                            Annuler
                        </button>
                        <button class="btn btn-primary">
                            Enregistrer
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/presences/index.blade.php ENDPATH**/ ?>