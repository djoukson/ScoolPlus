<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>État des paiements - <?php echo e($eleve->nom.' '.$eleve->prenom); ?></title>
    <style>
        body {
            font-family: "Poppins", Arial, sans-serif;
            background-color: #f7f9fc;
            margin: 0;
            padding: 20px;
            color: #333;
        }

        .receipt-container {
            background: #fff;
            max-width: 900px;
            margin: 0 auto;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            padding: 40px 50px;
        }

        /* ---------- HEADER ---------- */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 3px solid #4e73df;
            padding-bottom: 15px;
            margin-bottom: 25px;
        }

        .header .left {
            display: flex;
            align-items: center;
        }

        .header img {
            width: 70px;
            height: 70px;
            border-radius: 10px;
            margin-right: 15px;
        }

        .header h1 {
            font-size: 1.5rem;
            margin: 0;
            color: #4e73df;
            font-weight: 700;
        }

        .header p {
            margin: 0;
            font-size: 0.9rem;
            color: #666;
        }

        .header .right {
            text-align: right;
            font-size: 0.9rem;
        }

        /* ---------- TABLE ---------- */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 25px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px 12px;
            text-align: left;
        }

        th {
            background: #f4f6fb;
            color: #555;
            font-weight: 600;
        }

        tbody tr:nth-child(even) { background-color: #f9f9f9; }

        /* ---------- SUMMARY ---------- */
        .summary {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 20px;
            margin-top: 20px;
        }

        .summary-box {
            flex: 1;
            background: #f4f6fb;
            padding: 15px;
        }

        .summary-box h4 {
            margin: 0 0 10px 0;
            color: #4e73df;
        }

        .summary-box p {
            margin: 3px 0;
        }

        /* ---------- FOOTER ---------- */
        .footer {
            border-top: 1px dashed #ccc;
            text-align: center;
            margin-top: 30px;
            padding-top: 10px;
            font-size: 0.85rem;
            color: #777;
        }

        @media print {
            body {
                background: #fff;
                margin: 0;
            }
            .receipt-container {
                box-shadow: none;
                border: none;
            }
        }
    </style>
</head>
<body>

<div class="receipt-container">

    <!-- 🔹 En-tête -->
    <div class="header">
        <div class="left">
            <?php if(!empty($ecole->logo)): ?>
                <img src="<?php echo e(asset('storage/' . $ecole->logo)); ?>" alt="Logo de l'école">
            <?php endif; ?>
            <div>
                <h1><?php echo e(strtoupper($ecole->nom ?? 'École CASE')); ?></h1>
                <p><?php echo e($ecole->adresse ?? 'Adresse non spécifiée'); ?></p>
                <p>Tél : <?php echo e($ecole->telephone ?? '-'); ?> | Email : <?php echo e($ecole->email ?? '-'); ?></p>
            </div>
        </div>
        <div class="right">
            <p><strong>Date d'impression :</strong> <?php echo e(now()->format('d/m/Y H:i')); ?></p>
            <p><strong>Année scolaire :</strong> <?php echo e($anneenom); ?></p>
        </div>
    </div>

    <!-- 🔹 Élève -->
    <table>
        <tr><th>Élève</th><td><?php echo e($eleve->nom.' '.$eleve->prenom); ?></td></tr>
        <tr><th>Classe</th><td><?php echo e($eleve->classe->nom ?? ($eleve->inscriptions->last()->classe->nom ?? '—')); ?></td></tr>
        <tr><th>Matricule</th><td><?php echo e($eleve->matricule ?? '—'); ?></td></tr>
    </table>

    <!-- 🔹 Résumé -->
    <div class="summary">
        <div class="summary-box">
            <h4>Frais d'inscription</h4>
            <?php
                $reducInscription = $bourse?->frais->firstWhere('libelle', "Frais d'Inscription")->pivot->pourcentage ?? 0;
            ?>

            <?php if($reducInscription > 0): ?>
                <p class="mb-1">
                    <strong class="text-warning">Réduction Bourse :</strong>
                    <span class="badge bg-warning text-dark"><?php echo e(number_format($reducInscription, 0)); ?> %</span>
                </p>
            <?php else: ?>
                <p class="mb-1"><strong>Réduction Bourse :</strong> <?php echo e(number_format($reducInscription, 0)); ?> %</p>
            <?php endif; ?>
            <p><strong>Total :</strong> <?php echo e(number_format($totalFrais, 0, ',', ' ')); ?> FCFA</p>
            <p><strong>Déjà payé :</strong> <?php echo e(number_format($totalPayé, 0, ',', ' ')); ?> FCFA</p>
            <p><strong>Restant :</strong> <?php echo e(number_format($restant, 0, ',', ' ')); ?> FCFA</p>
        </div>
        <div class="summary-box">
            <h4>Scolarité</h4>
            <?php
                $reducScolarite = $bourse?->frais->firstWhere('libelle', "Scolarité")->pivot->pourcentage ?? 0;
            ?>

            <?php if($reducScolarite > 0): ?>
                <p class="mb-1">
                    <strong class="text-warning">Réduction Bourse :</strong>
                    <span class="badge bg-warning text-dark"><?php echo e(number_format($reducScolarite, 0)); ?> %</span>
                </p>
            <?php else: ?>
                <p class="mb-1"><strong>Réduction Bourse :</strong> <?php echo e(number_format($reducScolarite, 0)); ?> %</p>
            <?php endif; ?>
            <p><strong>Total :</strong> <?php echo e(number_format($totalScolarite, 0, ',', ' ')); ?> FCFA</p>
            <p><strong>Déjà payé :</strong> <?php echo e(number_format($totalPayeScolarite, 0, ',', ' ')); ?> FCFA</p>
            <p><strong>Restant :</strong> <?php echo e(number_format($restantScolarite, 0, ',', ' ')); ?> FCFA</p>
        </div>
    </div>

    <!-- 🔹 Tableau -->
    <h3 style="margin-top: 30px; color: #4e73df;">Détails des paiements</h3>
    <table>
        <thead>
        <tr>
            <th>#</th>
            <th>Frais</th>
            <th>Classe</th>
            <th>Montant Payé</th>
            <th>Date</th>
            <th>Mode</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $eleve->paiements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paiement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($paiement->frais->libelle ?? '—'); ?></td>
                <td><?php echo e($paiement->classe->nom ?? '—'); ?></td>
                <td><?php echo e(number_format($paiement->montant_paye, 0, ',', ' ')); ?> FCFA</td>
                <td><?php echo e(\Carbon\Carbon::parse($paiement->date_paiement)->format('d/m/Y')); ?></td>
                <td><?php echo e(ucfirst($paiement->mode_paiement)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- 🔹 Pied -->
    <div class="footer">
        Imprimé par : <strong><?php echo e(auth()->user()->nom ?? auth()->user()->name); ?></strong><br>
        Ce document a été généré automatiquement par le système de gestion de l’école.
    </div>
</div>

<script>
    window.onload = function() { window.print(); }
</script>

</body>
</html>
<?php /**PATH C:\wamp64\www\schoolplus\resources\views/paiements/print_all.blade.php ENDPATH**/ ?>