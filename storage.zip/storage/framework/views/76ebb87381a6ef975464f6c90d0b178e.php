<?php $__env->startSection('title', 'Page introuvable'); ?>

<?php $__env->startSection('content'); ?>
    <div class="error-code">404</div>
    <div class="error-icon mb-3">
        <i class="fas fa-search"></i>
    </div>
    <h4>Page introuvable</h4>
    <p class="text-muted">
        La page que vous cherchez n’existe pas ou a été déplacée.
    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/errors/404.blade.php ENDPATH**/ ?>