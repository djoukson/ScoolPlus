
    <!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>PDF Personnel</title>
</head>
<body>
<h1>Salaires Personnel - <?php echo e($mois); ?></h1>
<table border="1" cellpadding="5" cellspacing="0">
    <thead>
    <tr>
        <th>Nom</th>
        <th>Prénom</th>
        <th>Poste</th>
        <th>Salaire</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($p->nom); ?></td>
            <td><?php echo e($p->prenom); ?></td>
            <td><?php echo e($p->poste); ?></td>
            <td><?php echo e(number_format($p->salaire, 2, ',', ' ')); ?> FCFA</td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</body>
</html>
<?php /**PATH C:\wamp64\www\schoolplus\resources\views/salaires/pdf_personnel.blade.php ENDPATH**/ ?>