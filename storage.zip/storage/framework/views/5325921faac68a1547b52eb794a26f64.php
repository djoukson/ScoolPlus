<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="pro-breadcrumb">
            <div class="breadcrumb-title">
                Gestion des Emplois du temps : <?php echo e($annee_courante?->nom ?? 'Non définie'); ?>

            </div>

            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Emplois du temps
                    </li>
                </ol>
            </div>
        </div>


        
        <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-gradient-primary text-white">
                        <tr>
                            <th scope="col" class="text-center">#</th>
                            <th>Nom de la classe</th>
                            <th>Niveau</th>
                            <th>Nombre d’élèves</th>
                            <th>Enseignant(s)</th>
                            <th class="text-center">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="text-center fw-bold"><?php echo e($index + 1); ?></td>
                                <td class="fw-semibold text-dark">
                                    <i class="far fa-building text-secondary me-1"></i>
                                    <?php echo e($classe->nom); ?>

                                </td>
                                <td>
                                    <?php
                                        $badgeClass = match($classe->niveau->nom) {
                                            'Primaire' => 'bg-success',
                                            'College'  => 'bg-info',
                                            'Lycee'    => 'bg-warning',
                                            default    => 'bg-secondary',
                                        };
                                    ?>

                                    <span class="badge px-3 py-2 <?php echo e($badgeClass); ?>">
                                        <?php echo e(ucfirst($classe->niveau->nom)); ?>

                                    </span>
                                </td>
                                <td>
                                    <i class="fas fa-users text-primary me-1"></i>
                                    <strong><?php echo e($classe->inscriptions_count); ?></strong>
                                </td>
                                <td>
                                    <?php if($classe->niveau->nom === 'Primaire'): ?>
                                        <?php if($classe->enseignant): ?>
                                            <i class="fas fa-user text-success me-1"></i>
                                            <?php echo e($classe->enseignant->nom); ?> <?php echo e($classe->enseignant->prenom); ?>

                                        <?php else: ?>
                                            <span class="text-danger">Non affecté</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if($classe->affectations->count() > 0): ?>
                                            <i class="fas fa-chalkboard text-info me-1"></i>
                                            <strong class="text-success"><?php echo e($classe->affectations->count()); ?> prof(s)</strong>
                                        <?php else: ?>
                                            <span class="text-danger">Aucun professeur</span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('emplois.create', $classe->id)); ?>"
                                       class="btn btn-sm btn-outline-primary rounded-pill shadow-sm">
                                        <i class="fas fa-clock me-1"></i> Emploi du temps
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted py-4">
                                    <i class="fas fa-info-circle me-2"></i> Aucune classe enregistrée.
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        /* === TABLEAU PROFESSIONNEL === */
        .table {
            border-collapse: separate;
            border-spacing: 0;
        }
        thead {
            background: linear-gradient(90deg, #007bff, #00aaff);
        }
        thead th {
            color: white !important;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: .5px;
        }
        tbody tr {
            transition: all .2s ease-in-out;
        }
        tbody tr:hover {
            background-color: #f1f7ff;
            transform: scale(1.01);
        }

        /* === BADGES ET BOUTONS === */
        .bg-gradient-primary {
            background: linear-gradient(45deg, #36b9cc, #4e73df);
        }
        .btn-outline-primary {
            border: 1px solid #007bff;
        }
        .btn-outline-primary:hover {
            background: #007bff;
            color: #fff;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/emplois/index.blade.php ENDPATH**/ ?>