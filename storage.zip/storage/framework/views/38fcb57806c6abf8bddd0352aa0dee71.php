<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="pro-breadcrumb">
            <div class="breadcrumb-title">
               Affectation : <?php echo e($classe->nom); ?> /  <i class="fas fa-users text-success"></i>
                <strong><?php echo e($classe->inscriptions->count()); ?></strong> élève(s)
            </div>
            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('enseignantclasse.index')); ?>">Enseignants</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Année scolaire : <strong><?php echo e($classe->annee?->nom ?? '-'); ?>

                    </li>
                </ol>
            </div>
        </div>

        
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="fw-bold text-dark mb-0">
                <i class="fas fa-chalkboard-teacher text-primary"></i> Enseignants affectés
            </h4>

            
            <?php if($classe->niveau->nom === 'Primaire'): ?>
                <?php if($classe->enseignant): ?>
                    <button class="btn btn-warning shadow-sm" data-toggle="modal" data-target="#affectationModal">
                        <i class="fas fa-sync-alt"></i> Remplacer
                    </button>
                <?php else: ?>
                    <button class="btn btn-primary shadow-sm" data-toggle="modal" data-target="#affectationModal">
                        <i class="fas fa-user-plus"></i> Nouvelle affectation
                    </button>
                <?php endif; ?>
            <?php else: ?>
                <button class="btn btn-success shadow-sm" data-toggle="modal" data-target="#affectationModal">
                    <i class="fas fa-user-plus"></i> Ajouter des professeurs à la classe
                </button>
            <?php endif; ?>
        </div>

        
        <div class="modal fade" id="affectationModal" tabindex="-1" aria-labelledby="affectationModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content shadow-lg border-0 rounded-3">
                    <div class="modal-header bg-gradient text-white" style="background: linear-gradient(90deg,#4facfe,#00f2fe);">
                        <h5 class="modal-title fw-bold" id="affectationModalLabel">
                            <i class="fas fa-user-plus"></i> Gérer l’affectation
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-dismiss="modal" aria-label="Fermer"></button>
                    </div>

                    <div class="modal-body">
                        <form id="affectationForm" method="POST" action="<?php echo e(route('affectationsdepuisenseignant.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="classe_id" value="<?php echo e($classe->id); ?>">

                            
                            <?php if($classe->niveau->nom == 'Primaire'): ?>
                                <div class="mb-3">
                                    <label for="enseignant_id" class="form-label fw-bold">Enseignant</label>
                                    <select class="form-select shadow-sm" name="enseignant_id" id="enseignant_id" required>
                                        <option value="">-- Sélectionner --</option>
                                        <?php $__currentLoopData = $enseignants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enseignant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($enseignant->id); ?>">
                                                <?php echo e($enseignant->nom); ?> <?php echo e($enseignant->prenom); ?> (<?php echo e($enseignant->type); ?>)
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <?php else: ?>
                                <div class="mb-3">
                                    <label for="enseignant_id" class="form-label fw-bold">Professeur</label>
                                    <select class="form-select shadow-sm" name="enseignant_id" id="enseignant_id" required>
                                        <option value="">-- Sélectionner --</option>
                                        <?php $__currentLoopData = $professeurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $professeur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($professeur->id); ?>">
                                                <?php echo e($professeur->nom); ?> <?php echo e($professeur->prenom); ?> (<?php echo e($professeur->type); ?>)
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                            <?php endif; ?>


                            
                            <?php if($classe->niveau->nom !== 'Primaire'): ?>
                                <div class="mb-3">
                                    <label for="matiere" class="form-label fw-bold">Matière</label>
                                    <select name="matiere_id" class="form-control" required>
                                        <option value="">-- Sélectionnez une matière --</option>
                                        <?php $__currentLoopData = $matieres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matiere): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($matiere->id); ?>"><?php echo e($matiere->nom); ?> - Coeff : <?php echo e($matiere->coefficient); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="heures_attribuees" class="form-label fw-bold">Heures attribuées</label>
                                    <input type="number" class="form-control shadow-sm" name="heures_attribuees" id="heures_attribuees" placeholder="Ex: 12" required>
                                </div>
                            <?php endif; ?>

                            
                            <div class="mb-3">
                                <label for="note" class="form-label fw-bold">Note (facultatif)</label>
                                <textarea class="form-control shadow-sm" name="note" id="note" rows="2"></textarea>
                            </div>

                            <div class="text-end">
                                <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">
                                    <i class="fas fa-times"></i> Annuler
                                </button>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Enregistrer
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>




        
        <?php if($classe->affectations->count() > 0 || $classe->enseignant): ?>
            <div class="table-responsive shadow-sm rounded">
                <table class="table table-hover align-middle">
                    <thead class="table-primary">
                    <tr>
                        <?php if($classe->niveau->nom !== 'Primaire' ): ?>
                        <th>#</th>
                        <th>Enseignant</th>
                        <th>Matière</th>
                        <th>Heures attribuées</th>
                        <?php else: ?>
                            <th>Enseignant</th>
                        <?php endif; ?>
                        <th>Note</th>
                        <th>Action</th>

                    </tr>
                    </thead>
                    <tbody>
                    
                    <?php if($classe->niveau->nom === 'Primaire' && $classe->enseignant): ?>
                        <tr>

                            <td>
                                <i class="fas fa-user"></i>
                                <?php echo e($classe->enseignant->nom); ?> <?php echo e($classe->enseignant->prenom); ?>

                                <br>
                                <small class="text-muted">(<?php echo e($classe->enseignant->type); ?>)</small>
                            </td>

                            <td>—</td>
                            <td>
                                
                                <button type="button"
                                        class="btn btn-sm btn-outline-danger"
                                        data-toggle="modal"
                                        data-target="#confirmRemoveModal"
                                        data-action="<?php echo e(route('primaryaffectations.remove', ['classe_id' => $classe->id])); ?>"
                                        data-nom="<?php echo e($classe->enseignant->nom); ?>"
                                        data-prenom="<?php echo e($classe->enseignant->prenom); ?>">
                                    <i class="fas fa-user-minus"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endif; ?>

                    
                    <?php $__currentLoopData = $classe->affectations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $affectation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="fade-in">
                            <td><?php echo e($index + 1); ?></td>
                            <td>
                                <i class="fas fa-user"></i>
                                <?php echo e($affectation->enseignant->nom); ?> <?php echo e($affectation->enseignant->prenom); ?>

                                <br>
                                <small class="text-muted">(<?php echo e($affectation->enseignant->type); ?>)</small>
                            </td>
                            <td><span class="badge bg-secondary"><?php echo e($affectation->matiere->nom); ?></span></td>
                            <td><?php echo e($affectation->heures_attribuees); ?> h</td>
                            <td>
                                <?php if($affectation->note): ?>
                                    <span class="badge bg-success"><?php echo e($affectation->note); ?></span>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                
                                <button type="button"
                                        class="btn btn-sm btn-outline-danger"
                                        data-toggle="modal"
                                        data-target="#confirmRemoveModal"
                                        data-action="<?php echo e(route('destroyaffectations.destroy', $affectation->id)); ?>"
                                        data-nom="<?php echo e($affectation->enseignant->nom); ?>"
                                        data-prenom="<?php echo e($affectation->enseignant->prenom); ?>">
                                    <i class="fas fa-user-minus"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-warning shadow-sm">
                <i class="fas fa-exclamation-circle"></i> Aucun enseignant affecté à cette classe.
            </div>
        <?php endif; ?>

    </div>
    <!-- Modal confirmation -->
    <div class="modal fade" id="confirmRemoveModal" tabindex="-1" aria-labelledby="confirmRemoveModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow-lg rounded-3">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title fw-bold" id="confirmRemoveModalLabel">
                        <i class="fas fa-exclamation-triangle"></i> Confirmation
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-dismiss="modal" aria-label="Fermer"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-0">
                        Êtes-vous sûr de vouloir <strong>retirer l’enseignant
                            <span id="enseignantName"></span></strong> de la classe ?
                    </p>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">
                        <i class="fas fa-times"></i> Annuler
                    </button>
                    <form id="confirmRemoveForm" method="POST" action="">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-user-minus"></i> Confirmer
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            $('#confirmRemoveModal').on('show.bs.modal', function(event) {
                let button = $(event.relatedTarget);
                let action = button.data('action');
                let nom = button.data('nom');
                let prenom = button.data('prenom');

                let form = $(this).find('#confirmRemoveForm');
                form.attr('action', action);

                // Injecter le nom et prénom dans le span
                $(this).find('#enseignantName').text(nom + ' ' + prenom);
            });
        });
    </script>


    
    <style>
        .fade-in {
            animation: fadeIn 0.8s ease-in-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(5px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/enseignants/enseignantclasseaffectation.blade.php ENDPATH**/ ?>