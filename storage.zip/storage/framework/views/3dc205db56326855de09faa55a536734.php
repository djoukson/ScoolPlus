<?php $__env->startSection('content'); ?>
    <div class="container py-5">
        <div class="card shadow border-0 rounded-4 overflow-hidden" id="emploi-card">
            <!-- Header visible uniquement à l’écran -->
            <div class="card-header bg-gradient-primary text-white py-3 d-flex justify-content-between align-items-center no-print">
                <div class="d-flex align-items-center gap-2">
                    <i class="bi bi-calendar-week fs-4"></i>
                    <h5 class="mb-0 fw-bold">Mon emploi du temps</h5>
                </div>
                <div class="d-flex align-items-center gap-3">
                <span class="fw-semibold">
                    👨‍🏫 <?php echo e($enseignant->nom ?? ''); ?> <?php echo e($enseignant->prenom ?? ''); ?>

                </span>
                    <button onclick="window.print()" class="btn btn-light btn-sm fw-semibold shadow-sm">
                        <i class="bi bi-printer-fill text-primary"></i> Imprimer
                    </button>
                </div>
            </div>

            <!-- Body -->
            <div class="card-body bg-light p-4" id="print-area">
                <?php if($emplois->isEmpty()): ?>
                    <div class="text-center py-5">
                        <i class="bi bi-info-circle text-primary fs-1 mb-3"></i>
                        <h6 class="fw-semibold text-secondary">Aucun emploi du temps disponible pour le moment.</h6>
                    </div>
                <?php else: ?>
                    <?php
                        $jours = ['lundi','mardi','mercredi','jeudi','vendredi','samedi'];
                        $heures = \App\Models\HeureCours::orderBy('id')->get();
                        $ecole = \App\Models\Ecole::first();
                    ?>

                        <!-- Entête pour impression -->
                    <div class="text-center mb-4 print-header">
                        <img src="<?php echo e(asset('dist/img/logo.png')); ?>" alt="Logo école" style="height:60px;" class="mb-2">
                        <h4 class="fw-bold mb-0"><?php echo e($ecole->nom ?? 'Nom de l’école'); ?></h4>
                        <p class="mb-0 fst-italic"><?php echo e($ecole->devise ?? 'Travail - Liberté - Patrie'); ?></p>
                        <small>Année scolaire : <?php echo e($ecole->annee_scolaire ?? '2025-2026'); ?></small>
                        <h3 class="fw-bold mt-2">Emploi du temps du professeur </h3>
                        <p class="fw-semibold">Mr/Mme <?php echo e($enseignant->nom ?? ''); ?> <?php echo e($enseignant->prenom ?? ''); ?></p>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered text-center align-middle bg-white shadow-sm">
                            <thead class="bg-primary text-white">
                            <tr>
                                <th>Jour / Heure</th>
                                <?php $__currentLoopData = $heures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th><?php echo e($heure->libelle); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $jours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th class="bg-light text-capitalize"><?php echo e($jour); ?></th>
                                    <?php $__currentLoopData = $heures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $emploi = $emplois->first(function($e) use ($jour, $heure) {
                                                return strtolower(trim($e->jour)) === strtolower($jour)
                                                    && $e->heure_cours_id === $heure->id;
                                            });
                                        ?>
                                        <?php if($emploi): ?>
                                            <td class="bg-info-subtle">
                                                <b><?php echo e($emploi->affectation->matiere->nom ?? ''); ?></b><br>
                                                <b><?php echo e($emploi->classe->nom ?? ''); ?></b><br>
                                                <small class="text-muted"><?php echo e($emploi->heure->heure_debut); ?> - <?php echo e($emploi->heure->heure_fin); ?></small>
                                            </td>
                                        <?php else: ?>
                                            <td></td>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <style>
        .bg-gradient-primary { background: linear-gradient(135deg, #007bff, #0056d2); }
        .table td, .table th { vertical-align: middle; text-align: center; }
        .table-bordered th, .table-bordered td { border: 1px solid #dee2e6; }
        .bg-info-subtle { background-color: #dbeafe !important; }
        .bg-secondary-subtle { background-color: #e9ecef !important; border-radius: 10px; }

        /* Impression */
        @media print {
            body { background: white !important; }
            .no-print { display: none !important; }
            #emploi-card { box-shadow: none !important; border: none !important; }
            th, td { border: 1px solid #000 !important; color: black !important; }
            table { width: 100%; border-collapse: collapse !important; }
            .print-header { display: block; margin-bottom: 15px; text-align: center; }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/emplois/mon_emploi.blade.php ENDPATH**/ ?>