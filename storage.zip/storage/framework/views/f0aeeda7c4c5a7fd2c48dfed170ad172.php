

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dossier Élève - <?php echo e($eleve->nom); ?> <?php echo e($eleve->prenom); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        html, body { height: 100%; margin: 0; padding: 0; }
        body { background-color: #f8f9fa; }
        .full-width { width: 100% !important; margin: 0 !important; padding: 0 !important; }
        .card { border-radius: 1rem; margin-bottom: 1rem; }
        .shadow-lg { box-shadow: 0 1rem 3rem rgba(0,0,0,.175)!important; }
        .badge { font-size: 0.85rem; }
        .bg-gradient-primary { background: linear-gradient(135deg,#0d6efd,#0a58ca); }
        .bg-gradient-success { background: linear-gradient(135deg,#198754,#157347); }
        .bg-gradient-info { background: linear-gradient(135deg,#0dcaf0,#0bb4cc); }
        @media print {
            button { display: none !important; }
            body { background: #fff !important; }
        }
        .table td, .table th { vertical-align: middle; }
    </style>
</head>
<body class="full-width">

<div class="container-fluid py-3 full-width">

    <!-- Bouton Imprimer -->
    <div class="d-flex justify-content-end mb-3">
        <button class="btn btn-primary shadow-sm" onclick="window.print()">
            <i class="fas fa-print me-1"></i> Imprimer le dossier complet
        </button>
    </div>

    <!-- Profil élève -->
    <div class="card shadow-lg full-width" style="background: linear-gradient(135deg,#0c2325,#0661da);margin-bottom: 10px !important;">
        <div class="row g-0 align-items-center p-4">
            <div class="col-md-3 text-center">
                <?php
                    $imagePath = $eleve->sexe == 'M' ? asset('dist/img/man.png') : asset('dist/img/woman.png');
                ?>
                <img src="<?php echo e($eleve->imglink ? asset($eleve->imglink) : $imagePath); ?>"
                     alt="Photo de <?php echo e($eleve->nom); ?>"
                     class="img-fluid rounded-circle border border-3 border-light shadow-sm mb-3"
                     width="130" height="130" style="object-fit: cover;">
                <h5 class="fw-bold text-white text-uppercase"><?php echo e($eleve->nom); ?> <?php echo e(ucfirst($eleve->prenom)); ?></h5>
                <small class="text-white d-block mb-2"><i class="fas fa-id-card me-1"></i> Matricule : <?php echo e($eleve->id); ?></small>
                <span class="badge <?php echo e($eleve->sexe == 'M' ? 'bg-primary' : 'bg-danger'); ?>">
                    <?php echo e($eleve->sexe == 'M' ? 'Masculin' : 'Féminin'); ?>

                </span>
            </div>
            <div class="col-md-9">
                <div class="row g-3">
                    <!-- Classe -->
                    <div class="col-md-6">
                        <div class="p-3 rounded-3 bg-white shadow-sm d-flex align-items-center gap-3">
                            <i class="fas fa-school fs-3 text-primary"></i>
                            <div>
                                <small class="text-muted">Classe</small>
                                <div class="fw-semibold fs-6"><?php echo e($eleve->classeActuelle?->classe?->nom ?? '—'); ?></div>
                            </div>
                        </div>
                    </div>
                    <!-- Date de naissance -->
                    <div class="col-md-6">
                        <div class="p-3 rounded-3 bg-white shadow-sm d-flex align-items-center gap-3">
                            <i class="fas fa-birthday-cake fs-3 text-primary"></i>
                            <div>
                                <small class="text-muted">Date de naissance</small>
                                <div class="fw-semibold fs-6"><?php echo e($eleve->date_naissance ? $eleve->date_naissance->format('d/m/Y') : '—'); ?></div>
                            </div>
                        </div>
                    </div>
                    <!-- Adresse -->
                    <div class="col-md-6">
                        <div class="p-3 rounded-3 bg-white shadow-sm d-flex align-items-center gap-3">
                            <i class="fas fa-map-marker-alt fs-3 text-primary"></i>
                            <div>
                                <small class="text-muted">Adresse</small>
                                <div class="fw-semibold fs-6"><?php echo e($eleve->adresse ?? '—'); ?></div>
                            </div>
                        </div>
                    </div>
                    <!-- Nationalité -->
                    <div class="col-md-6">
                        <div class="p-3 rounded-3 bg-white shadow-sm d-flex align-items-center gap-3">
                            <i class="fas fa-flag fs-3 text-primary"></i>
                            <div>
                                <small class="text-muted">Nationalité</small>
                                <div class="fw-semibold fs-6"><?php echo e($eleve->nationalite ?? '—'); ?></div>
                            </div>
                        </div>
                    </div>
                    <!-- Observation -->
                    <div class="col-md-12">
                        <div class="p-3 bg-light rounded-3 shadow-sm">
                            <i class="fas fa-sticky-note text-primary me-2"></i>
                            <span class="fw-semibold">Observation</span>
                            <p class="mb-0 text-muted fst-italic">
                                <?php echo e($eleve->observation ?: 'Aucune observation enregistrée.'); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Parents -->
    <div class="card shadow-lg full-width" style="margin-bottom: 10px !important;">
        <div class="card-header bg-primary text-white">
            <i class="fas fa-users me-2"></i> Informations des Parents
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <div class="p-3 border rounded shadow-sm bg-white">
                        <h6 class="text-primary"><i class="fas fa-male me-2"></i>Père</h6>
                        <table class="table table-borderless mb-0 small">
                            <tr><th>Nom complet :</th><td><?php echo e($parent?->pere_nom ?? '—'); ?></td></tr>
                            <tr><th>Téléphone :</th><td><?php echo e($parent?->pere_tel ?? '—'); ?></td></tr>
                            <tr><th>Profession :</th><td><?php echo e($parent?->pere_profession ?? '—'); ?></td></tr>
                            <tr><th>Email :</th><td><?php echo e($parent?->pere_email ?? '—'); ?></td></tr>
                            <tr><th>Adresse :</th><td><?php echo e($parent?->pere_adresse ?? '—'); ?></td></tr>
                        </table>
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="p-3 border rounded shadow-sm bg-white">
                        <h6 class="text-danger"><i class="fas fa-female me-2"></i>Mère</h6>
                        <table class="table table-borderless mb-0 small">
                            <tr><th>Nom complet :</th><td><?php echo e($parent?->mere_nom ?? '—'); ?></td></tr>
                            <tr><th>Téléphone :</th><td><?php echo e($parent?->mere_tel ?? '—'); ?></td></tr>
                            <tr><th>Profession :</th><td><?php echo e($parent?->mere_profession ?? '—'); ?></td></tr>
                            <tr><th>Email :</th><td><?php echo e($parent?->mere_email ?? '—'); ?></td></tr>
                            <tr><th>Adresse :</th><td><?php echo e($parent?->mere_adresse ?? '—'); ?></td></tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bourses -->
    <div class="card mb-4 shadow-lg">
        <div class="card-header bg-success text-white">
            <i class="fas fa-hand-holding-usd me-2"></i> Bourses
        </div>
        <div class="card-body">
            <?php if($eleve->attributions->count()): ?>
                <?php $__currentLoopData = $eleve->attributions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attrib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mb-2 p-3 rounded bg-light shadow-sm">
                        <strong><?php echo e($attrib->bourse->nom ?? '—'); ?></strong>
                        - État: <span class="badge <?php echo e($attrib->isActive() ? 'bg-success' : 'bg-secondary'); ?>">
                            <?php echo e($attrib->isActive() ? 'Active' : 'Inactive'); ?>

                        </span>
                        - Date: <?php echo e($attrib->date_attribution ? \Carbon\Carbon::parse($attrib->date_attribution)->format('d/m/Y') : '—'); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p class="text-muted">Aucune bourse attribuée</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Paiements -->
    <div class="card mb-4 shadow-lg ">
        <div class="card-header bg-info text-white">
            <i class="fas fa-money-bill-wave me-2"></i> Paiements
        </div>
        <div class="card-body">
            <h5 class="text-primary fw-bold mt-4">Paiements pour la classe actuelle</h5>
            <?php if($paiementsActuels->count()): ?>
                <table class="table table-bordered table-striped">
                    <thead class="table-light">
                    <tr>
                        <th>Frais</th>
                        <th>Montant payé</th>
                        <th>Date</th>
                        <th>Mode de paiement</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $paiementsActuels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paiement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($paiement->frais?->libelle ?? '—'); ?></td>
                            <td><?php echo e(number_format($paiement->montant_paye, 2)); ?> FCFA</td>
                            <td><?php echo e(\Carbon\Carbon::parse($paiement->date_paiement)?->format('d/m/Y') ?? '—'); ?></td>
                            <td><?php echo e($paiement->mode_paiement ?? '—'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-muted">Aucun paiement enregistré pour cette classe.</p>
            <?php endif; ?>

        </div>
    </div>

    <!-- Absences / Retards -->
    <div class="card shadow-sm " style="margin-bottom: 10px">
        <div class="card-header bg-gradient-primary text-white fw-bold">
            <i class="fas fa-calendar-times me-2"></i> Absences / Retards
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light text-uppercase small">
                    <tr>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Nombre d'heures</th>
                        <th>Justifié</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $eleve->absences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $absence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="<?php echo e($absence->is_justified ? '' : 'table-warning'); ?>">
                            <td><?php echo e(\Carbon\Carbon::parse($absence->date_absence)->format('d/m/Y')); ?></td>
                            <td><?php echo e($absence->type ?? 'Absence'); ?></td>
                            <td><?php echo e($absence->heures ?? '0'); ?></td>
                            <td>
                                <?php if($absence->is_justified): ?>
                                    <span class="badge bg-success"><i class="fas fa-check"></i> Oui</span>
                                <?php else: ?>
                                    <span class="badge bg-danger"><i class="fas fa-times"></i> Non</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center text-muted fst-italic">
                                Aucune absence enregistrée
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


    <!-- Notes / Moyennes -->
    <div class="card mb-4 shadow-lg rounded-4 border-0">
        <div class="card-header bg-gradient-primary text-white fw-bold">
            <i class="fas fa-chart-line me-2"></i> Notes et Moyennes par Découpage
        </div>
        <div class="card-body p-3">
            <?php if($eleve->notes->count()): ?>
                <?php $__currentLoopData = $eleve->notes->groupBy('decoupage_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $decoupageId => $notesDecoupage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $decoupage = $notesDecoupage->first()->decoupage;
                        $typesEvaluation = $notesDecoupage->pluck('typeEvaluation.nom')->unique();
                    ?>

                    <h6 class="fw-bold mt-4 text-primary">
                        <?php echo e($decoupage->nom ?? "Découpage #$decoupageId"); ?>

                    </h6>

                    <table class="table table-hover table-sm align-middle">
                        <thead class="table-light small text-uppercase">
                        <tr>
                            <th>Matière</th>
                            <?php $__currentLoopData = $typesEvaluation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($type); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $notesDecoupage->groupBy('matiere_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matiereId => $notesMatiere): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($notesMatiere->first()->matiere->nom ?? '—'); ?></td>
                                <?php $__currentLoopData = $typesEvaluation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $note = $notesMatiere->firstWhere('typeEvaluation.nom', $type);
                                    ?>
                                    <td><?php echo e($note->note ?? '—'); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p class="text-muted fst-italic">Aucune note enregistrée.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\wamp64\www\schoolplus\resources\views/eleves/print.blade.php ENDPATH**/ ?>