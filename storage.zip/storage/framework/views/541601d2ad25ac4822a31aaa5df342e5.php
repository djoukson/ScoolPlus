<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="pro-breadcrumb">
            <form action="<?php echo e(route('emplois.generate', $classe->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-outline-warning" style="margin-bottom: 15px">
                    Générer automatiquement l'emploi du temps
                </button>
            </form>

            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('emplois.index')); ?>">🔙 Retour</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Creation
                    </li>
                </ol>
            </div>
        </div>

        <div class="card shadow-lg border-0 rounded-4 overflow-hidden">
            <div class="card-header bg-gradient-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="fas fa-calendar-alt me-2"></i> Emploi du temps - <?php echo e($classe->nom); ?></h5>
            </div>

            <form id="emploiForm" action="<?php echo e(route('emplois.storeMultiple', $classe->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="classe_id" value="<?php echo e($classe->id); ?>">

                <div class="card-body bg-light">
                    
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <button type="button" class="btn btn-outline-danger" id="resetAll">
                                <i class="fas fa-undo-alt me-1"></i> Réinitialiser tout
                            </button>
                            <a href="<?php echo e(route('emplois.print', $classe->id)); ?>" target="_blank" class="btn btn-outline-primary">
                                <i class="fas fa-print"></i> Imprimer
                            </a>

                        </div>
                    </div>

                    
                    <div class="table-responsive">
                        <table class="table table-bordered text-center align-middle shadow-sm rounded-3 bg-white">
                            <thead class="table-primary">
                            <tr>
                                <th class="bg-light">Jours</th>
                                <?php $__currentLoopData = $heures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th>
                                        <?php echo e($heure->libelle); ?>

                                        <br>
                                        <small class="text-muted">
                                            <?php echo e(substr($heure->heure_debut,0,5)); ?> - <?php echo e(substr($heure->heure_fin,0,5)); ?>

                                        </small>
                                    </th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = ['Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="fw-bold text-start bg-light ps-3"><?php echo e($jour); ?></td>

                                    <?php $__currentLoopData = $heures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $emploiKey = $jour . '_' . $heure->id;
                                            $emploi = $emploisExistants[$emploiKey][0] ?? null;
                                            $isAffecte = !empty($emploi);
                                        ?>

                                        <td class="<?php echo e($isAffecte ? 'bg-success-subtle' : 'bg-danger-subtle'); ?>">
                                            <?php if($heure->libelle === 'Pause'): ?>
                                                <span class="text-secondary fw-semibold">Pause</span>
                                            <?php else: ?>
                                                <select name="emplois[<?php echo e($jour); ?>][<?php echo e($heure->id); ?>]"
                                                        class="form-select form-select-sm <?php echo e($isAffecte ? 'select-affected' : 'select-free'); ?>">
                                                    <option value="">--</option>

                                                    <?php $__currentLoopData = $affectations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $enseignantId = $aff->enseignant->id;
                                                            $key = $jour . '_' . $heure->id;
                                                            $enseignantOccupe = isset($enseignantsOccupes[$key]) && in_array($enseignantId, $enseignantsOccupes[$key]);
                                                            $heuresDejaPlanifiees = \App\Models\EmploiDuTemps::where('affectation_id', $aff->id)->count();
                                                            $heuresRestantes = $aff->heures_attribuees - $heuresDejaPlanifiees;
                                                        ?>

                                                        <option value="<?php echo e($aff->id); ?>"
                                                            <?php echo e($emploi && $emploi->affectation_id == $aff->id ? 'selected' : ''); ?>

                                                            <?php echo e($enseignantOccupe && (!$emploi || $emploi->affectation_id != $aff->id) ? 'disabled' : ''); ?>>
                                                            <?php echo e($aff->matiere->nom); ?> — <?php echo e($aff->enseignant->nom); ?>

                                                            <?php if($enseignantOccupe && (!$emploi || $emploi->affectation_id != $aff->id)): ?>
                                                                🟥 (Occupé)
                                                            <?php else: ?>
                                                                (<?php echo e($heuresRestantes); ?>h / <?php echo e($aff->heures_attribuees); ?>h)
                                                            <?php endif; ?>
                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            <?php endif; ?>
                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    
                    <div class="text-end mt-3">
                        <button type="submit" class="btn btn-primary px-4 rounded-pill shadow-sm">
                            <i class="fas fa-save me-2"></i> Enregistrer l’emploi du temps
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <style>
        .bg-gradient-primary {
            background: linear-gradient(90deg, #007bff, #00aaff);
        }
        .table-bordered td, .table-bordered th {
            vertical-align: middle;
            text-align: center;
        }
        .table thead th {
            white-space: nowrap;
        }
        .form-select-sm {
            min-width: 170px;
            border-radius: 8px;
            transition: all 0.2s ease-in-out;
            font-size: 0.9rem;
        }
        .form-select-sm:focus {
            border-color: #00aaff;
            box-shadow: 0 0 6px rgba(0, 170, 255, 0.4);
        }
        .bg-success-subtle {
            background-color: #e8fbe8 !important;
        }
        .bg-danger-subtle {
            background-color: #fbe8e8 !important;
        }
        .select-affected {
            background-color: #e8fbe8;
            border: 1px solid #a2d5a2;
        }
        .select-free {
            background-color: #fdf7f7;
            border: 1px solid #f0c0c0;
        }
        option[disabled] {
            color: #999;
            background-color: #f8f9fa;
            font-style: italic;
        }
        @media print {
            body * {
                visibility: hidden;
            }
            .card, .card * {
                visibility: visible;
            }
            .card {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
            }
            button, .btn, .form-select {
                display: none !important;
            }
        }
    </style>

    <script>
        // 🔁 Réinitialiser tous les sélecteurs
        document.getElementById('resetAll').addEventListener('click', function() {
            if (confirm('Voulez-vous vraiment réinitialiser tout le tableau ?')) {
                document.querySelectorAll('select.form-select-sm').forEach(select => select.value = '');
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/emplois/create.blade.php ENDPATH**/ ?>