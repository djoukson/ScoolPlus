<footer class="main-footer">
    <strong>&copy; <?php echo e(date('Y')); ?> SchoolPlus.</strong>
    Tous droits réservés.
    <div class="float-right d-none d-sm-inline-block">
        v1.12
    </div>
</footer>
<?php /**PATH C:\wamp64\www\schoolplus\resources\views/layouts/footer.blade.php ENDPATH**/ ?>