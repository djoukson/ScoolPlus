<?php $__env->startSection('content'); ?>
    <div class="container py-4">

        
        <div class="pro-breadcrumb mb-3">
            <div class="breadcrumb-title">
                👤 Détail du Personnel Administratif
            </div>
            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('personnel.index')); ?>">Personnel</a>
                    </li>
                    <li class="breadcrumb-item active">
                        <?php echo e(strtoupper($personnel->nom)); ?> <?php echo e(ucfirst($personnel->prenom)); ?>

                    </li>
                </ol>
            </div>
        </div>

        <div class="row">
            
            <div class="col-md-4">
                <div class="card shadow-sm border-0 rounded-4 text-center">
                    <div class="card-body">
                        <div class="avatar bg-primary text-white rounded-circle mx-auto mb-3"
                             style="width:90px;height:90px;display:flex;align-items:center;justify-content:center;font-size:36px;">
                            <?php echo e(strtoupper(substr($personnel->nom,0,1))); ?>

                        </div>

                        <h5 class="fw-bold mb-1">
                            <?php echo e(strtoupper($personnel->nom)); ?> <?php echo e(ucfirst($personnel->prenom)); ?>

                        </h5>

                        <span class="badge bg-info mb-2">
                        <?php echo e($personnel->poste ?? 'Personnel Administratif'); ?>

                    </span>

                        <p class="text-muted mb-1">
                            📞 <?php echo e($personnel->tel ?? '—'); ?>

                        </p>

                        <p class="text-muted mb-3">
                            📧 <?php echo e($personnel->email ?? '—'); ?>

                        </p>

                        <span class="badge <?php echo e($personnel->statut ? 'bg-success' : 'bg-danger'); ?>">
                        <?php echo e($personnel->statut ? 'Actif' : 'Inactif'); ?>

                    </span>
                    </div>
                </div>
            </div>

            
            <div class="col-md-8">
                <div class="card shadow-sm border-0 rounded-4">
                    <div class="card-header bg-dark text-white rounded-top-4">
                        <h6 class="mb-0">📋 Informations générales</h6>
                    </div>

                    <div class="card-body">
                        <div class="row g-3">

                            <div class="col-md-6">
                                <strong>🧑 Nom :</strong>
                                <div><?php echo e(strtoupper($personnel->nom)); ?></div>
                            </div>

                            <div class="col-md-6">
                                <strong>🧑 Prénom :</strong>
                                <div><?php echo e(ucfirst($personnel->prenom)); ?></div>
                            </div>

                            <div class="col-md-6">
                                <strong>🏢 Poste / Fonction :</strong>
                                <div><?php echo e($personnel->poste ?? '-'); ?></div>
                            </div>

                            <div class="col-md-6">
                                <strong>🚻 Sexe :</strong>
                                <div>
                                    <?php echo e($personnel->sexe == 'M' ? 'Masculin' : ($personnel->sexe == 'F' ? 'Féminin' : '-')); ?>

                                </div>
                            </div>

                            <div class="col-md-6">
                                <strong>🩸 Groupe sanguin :</strong>
                                <div><?php echo e($personnel->groupesanguin ?? '-'); ?></div>
                            </div>

                            <div class="col-md-6">
                                <strong>💰 Salaire mensuel :</strong>
                                <div class="fw-bold text-success">
                                    <?php echo e(number_format($personnel->salaire, 0, ',', ' ')); ?> FCFA
                                </div>
                            </div>

                            <div class="col-md-12">
                                <strong>🏠 Adresse :</strong>
                                <div><?php echo e($personnel->adresse ?? '-'); ?></div>
                            </div>

                        </div>
                    </div>

                    <div class="card-footer text-end bg-light">
                        <a href="<?php echo e(route('personnel.index')); ?>" class="btn btn-secondary btn-sm">
                            ⬅ Retour à la liste
                        </a>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/personnel/show.blade.php ENDPATH**/ ?>