<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Emploi du temps - <?php echo e($classe->nom); ?></title>
    <style>
        @page {
            size: A4 portrait;
            margin: 15mm;
        }

        body {
            font-family: "Segoe UI", sans-serif;
            color: #222;
            margin: 0;
        }

        .header {
            text-align: center;
            margin-bottom: 25px;
        }

        .header h2 {
            margin: 0;
            text-transform: uppercase;
            font-size: 20px;
        }

        .header h4 {
            margin: 4px 0 0;
            font-weight: normal;
            color: #555;
            font-size: 15px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
            margin-top: 10px;
        }

        th, td {
            border: 1px solid #999;
            padding: 6px 5px;
            text-align: center;
            vertical-align: middle;
        }

        th {
            background-color: #f0f4f8;
            text-transform: uppercase;
            font-size: 12px;
        }

        tr:nth-child(even) td {
            background-color: #fafafa;
        }

        td strong {
            color: #000;
            font-size: 13px;
        }

        .footer {
            margin-top: 25px;
            text-align: right;
            font-size: 12px;
            color: #666;
        }

        .print-btn {
            display: block;
            margin: 15px auto;
            padding: 8px 16px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            cursor: pointer;
        }

        @media print {
            .print-btn { display: none; }
        }

        /* Entête officielle optionnelle */
        .official-header {
            text-align: center;
            font-size: 13px;
            line-height: 1.3;
            margin-bottom: 10px;
        }
        .official-header img {
            width: 50px;
            height: 50px;
            margin-bottom: 5px;
        }

    </style>
</head>
<body>

<button class="print-btn" onclick="window.print()">🖨️ Imprimer</button>

<div class="header">
    <h2>EMPLOI DU TEMPS</h2>
    <h1>Classe : <?php echo e($classe->nom); ?></h1>
</div>

<table>
    <thead>
    <tr>
        <th>Jour / Heure</th>
        <?php $__currentLoopData = $heures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th><?php echo e($heure->libelle); ?></th>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($jour); ?></th>
            <?php $__currentLoopData = $heures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $emploi = $emploisExistants->firstWhere(fn($e) =>
                        $e->jour === $jour && $e->heure_cours_id === $heure->id
                    );
                ?>
                <td>
                    <?php if($emploi): ?>
                        <strong><?php echo e($emploi->affectation->matiere->nom ?? '-'); ?></strong><br>
                        <small><?php echo e($emploi->affectation->enseignant->nom ?? ''); ?></small>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<div class="footer">
    <p>Imprimé le <?php echo e(now()->format('d/m/Y à H:i')); ?></p>
</div>

</body>
</html>
<?php /**PATH C:\wamp64\www\schoolplus\resources\views/emplois/print.blade.php ENDPATH**/ ?>