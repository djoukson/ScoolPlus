<?php $__env->startSection('content'); ?>
    <div class="container py-4">

        <div class="pro-breadcrumb">
            <div class="breadcrumb-title">
                Gestion du personnel administratif
            </div>


            <div class="mb-3 d-flex justify-content-between">
                <div class="btn-group">
                    <button type="button" class="btn btn-outline-info dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                        ➕ Ajouter / Voir personnel
                    </button>

                    <ul class="dropdown-menu">

                        <li>
                            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#addPersonnelModal">
                                ➕ Ajouter un membre
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Personnel administratif
                    </li>
                </ol>
            </div>
        </div>


        <div class="modal fade" id="addPersonnelModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content shadow-lg border-0 rounded-3">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title">➕ Ajouter un membre administratif</h5>
                        <button type="button" class="btn-close btn-close-white" data-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="<?php echo e(route('enseignants.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="personnel_type" value="administratif">
                            <div class="row g-3">

                                <div class="col-md-6">
                                    <label class="form-label">Nom *</label>
                                    <input type="text" name="nom" class="form-control" required>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Prénom *</label>
                                    <input type="text" name="prenom" class="form-control" required>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Poste / Fonction *</label>
                                    <input type="text" name="poste" class="form-control" required>
                                </div>

                                <div class="col-md-6">
                                    <label for="tel" class="form-label">📞 Téléphone</label>
                                    <div class="input-group">
                                        <span class="input-group-text">+228</span>
                                        <input type="tel" name="tel" id="tel" class="form-control"
                                               placeholder="90 12 34 56" pattern="[0-9]{8}" maxlength="8">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Email</label>
                                    <input type="email" name="email" class="form-control">
                                </div>

                            </div>

                            <div class="mt-3 text-end">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                <button type="submit" class="btn btn-success">✅ Enregistrer</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <div class="card shadow-sm">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0">Liste du personnel administratif (<?php echo e($personnel->total()); ?>)</h5>
            </div>
            <div class="card-body p-2">
                <div class="table-responsive">
                    <table id="personnelTable" class="table table-hover table-striped align-middle mb-0">
                        <thead class="table-primary">
                        <tr>
                            <th>Matricule</th>
                            <th>Nom & Prénom</th>
                            <th>Poste / Fonction</th>
                            <th>Téléphone</th>
                            <th>Email</th>
                            <th>Statut</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $personnel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td style="text-align: center"><?php echo e($p->id); ?></td>
                                <td><?php echo e(strtoupper($p->nom)); ?> <?php echo e(ucfirst($p->prenom)); ?></td>
                                <td><?php echo e($p->poste ?? '-'); ?></td>
                                <td><?php echo e($p->tel ?? '-'); ?></td>
                                <td><?php echo e($p->email ?? '-'); ?></td>
                                <td class="text-center">
                                    <?php if($p->statut): ?>
                                        <span class="text-success" title="Actif">✅</span>
                                    <?php else: ?>
                                        <span class="text-danger" title="Inactif">🚫</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                            ⚙️ Options
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li>
                                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#editPersonnel<?php echo e($p->id); ?>">
                                                    ✏️ Modifier
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#togglePersonnel<?php echo e($p->id); ?>">
                                                    <?php echo e($p->statut ? '🚫 Désactiver' : '✅ Activer'); ?>

                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item text-danger" href="#" data-toggle="modal" data-target="#deletePersonnel<?php echo e($p->id); ?>">
                                                    🗑️ Supprimer
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>


                            <div class="modal fade" id="editPersonnel<?php echo e($p->id); ?>" tabindex="-1">
                                <div class="modal-dialog modal-lg modal-dialog-centered">
                                    <div class="modal-content shadow-lg border-0 rounded-3">
                                        <div class="modal-header bg-info text-white">
                                            <h5 class="modal-title">✏️ Modifier le membre administratif</h5>
                                            <button type="button" class="btn-close btn-close-white" data-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form method="POST" action="<?php echo e(route('enseignants.update', $p->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <input type="hidden" name="personnel_type" value="administratif">
                                                <div class="row g-3">
                                                    <div class="col-md-6">
                                                        <label class="form-label">Nom *</label>
                                                        <input type="text" name="nom" value="<?php echo e($p->nom); ?>" class="form-control" required>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label class="form-label">Prénom *</label>
                                                        <input type="text" name="prenom" value="<?php echo e($p->prenom); ?>" class="form-control" required>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label class="form-label">Poste / Fonction *</label>
                                                        <input type="text" name="poste" value="<?php echo e($p->poste); ?>" class="form-control" required>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label for="tel" class="form-label">📞 Téléphone</label>
                                                        <div class="input-group">
                                                            <span class="input-group-text">+228</span>
                                                            <input type="tel" name="tel" class="form-control"
                                                                   value="<?php echo e($p->tel); ?>" pattern="[0-9]{8}" maxlength="8">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label class="form-label">Email</label>
                                                        <input type="email" name="email" value="<?php echo e($p->email); ?>" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="mt-3 text-end">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                                    <button type="submit" class="btn btn-info">💾 Mettre à jour</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="modal fade" id="deletePersonnel<?php echo e($p->id); ?>" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content shadow-lg border-0 rounded-3">
                                        <div class="modal-header bg-danger text-white">
                                            <h5 class="modal-title">🗑️ Supprimer le membre</h5>
                                            <button type="button" class="btn-close btn-close-white" data-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            Voulez-vous vraiment supprimer <strong><?php echo e($p->nom); ?> <?php echo e($p->prenom); ?></strong> ?
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                            <form action="<?php echo e(route('enseignants.destroy', $p->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">Oui, Supprimer</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="modal fade" id="togglePersonnel<?php echo e($p->id); ?>" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content shadow-lg border-0 rounded-3">
                                        <div class="modal-header <?php echo e($p->statut ? 'bg-warning' : 'bg-success'); ?> text-white">
                                            <h5 class="modal-title"><?php echo e($p->statut ? 'Désactiver' : 'Activer'); ?> le membre</h5>
                                            <button type="button" class="btn-close btn-close-white" data-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            Voulez-vous vraiment <strong><?php echo e($p->statut ? 'désactiver' : 'activer'); ?></strong> <strong><?php echo e($p->nom); ?> <?php echo e($p->prenom); ?></strong> ?
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                            <form action="<?php echo e(route('enseignants.toggle', $p->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn <?php echo e($p->statut ? 'btn-warning' : 'btn-success'); ?>">
                                                    Oui, <?php echo e($p->statut ? 'Désactiver' : 'Activer'); ?>

                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted">Aucun membre administratif trouvé</td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card-footer">
                <div class="d-flex justify-content-center">
                    <?php echo e($personnel->links('pagination::bootstrap-5')); ?>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $('#personnelTable').DataTable({
            destroy: true,
            responsive: true,
            autoWidth: false,
            pageLength: 50,
            order: [[0, "desc"]],
            deferRender: true,
            language: {
                url: "<?php echo e(asset('assets/datatables/i18n/fr-FR.json')); ?>"
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/enseignants/index.blade.php ENDPATH**/ ?>
