<?php $__env->startSection('content'); ?>
    <div class="container py-5">
        <div class="pro-breadcrumb">
            <div class="breadcrumb-title">
                Mes matières
            </div>

            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">
                        👨‍🏫 <?php echo e($enseignant->nom ?? ''); ?> <?php echo e($enseignant->prenom ?? ''); ?>

                    </li>
                </ol>
            </div>
        </div>

        <div class="card shadow border-0 rounded-4 overflow-hidden">

            <div class="card-body bg-light p-4">
                <?php if($affectations->isEmpty()): ?>
                    <div class="text-center py-5">
                        <i class="bi bi-info-circle text-primary fs-1 mb-3"></i>
                        <h6 class="fw-semibold text-secondary">Aucune matière affectée pour le moment.</h6>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table align-middle text-center table-hover shadow-sm bg-white rounded-3">
                            <thead class="bg-primary text-white">
                            <tr>
                                <th>#</th>
                                <th>Classe</th>
                                <th>Matière</th>
                                <th>Heures attribuées</th>
                                <th>Heures planifiées</th>
                                <th>Écart</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $affectations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $affectation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $attribuees = $affectation->heures_attribuees ?? 0;
                                    $planifiees = $affectation->emplois_du_temps_count ?? 0;
                                    $ecart = $attribuees - $planifiees;
                                ?>
                                <tr class="table-row-hover">
                                    <td><?php echo e($index + 1); ?></td>
                                    <td class="fw-semibold"><?php echo e($affectation->classe->nom ?? '-'); ?></td>
                                    <td><?php echo e($affectation->matiere->nom ?? '-'); ?></td>
                                    <td>
                                        <span class="badge bg-secondary-subtle text-dark px-3 py-2"><?php echo e($attribuees); ?> h</span>
                                    </td>
                                    <td>
                                        <span class="badge bg-info text-white px-3 py-2"><?php echo e($planifiees); ?> h</span>
                                    </td>
                                    <td>
                                        <?php if($ecart == 0): ?>
                                            <span class="badge bg-success text-white">OK</span>
                                        <?php elseif($ecart > 0): ?>
                                            <span class="badge bg-warning text-dark">-<?php echo e($ecart); ?> h à planifier</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger text-white">+<?php echo e(abs($ecart)); ?> h en trop</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                            <tr class="table-light fw-bold">
                                <td colspan="3" class="text-end">Totaux</td>
                                <td>
                                    <span class="badge bg-primary text-white px-3 py-2">
                                        <?php echo e($affectations->sum('heures_attribuees')); ?> h
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-info text-white px-3 py-2">
                                        <?php echo e($affectations->sum('emplois_du_temps_count')); ?> h
                                    </span>
                                </td>
                                <td></td>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <style>
        .bg-gradient-primary { background: linear-gradient(135deg, #007bff, #0056d2); }
        .table-row-hover:hover { background-color: #f8f9fa; transition: 0.3s; }
        .badge.bg-secondary-subtle { background-color: #e9ecef; border-radius: 12px; }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/matieres/mes_matieres.blade.php ENDPATH**/ ?>