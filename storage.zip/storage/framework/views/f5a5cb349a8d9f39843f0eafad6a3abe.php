<?php $__env->startSection('title', 'Paiement par classe'); ?>
<?php $__env->startSection('page-title', 'État des paiements - ' . $classe->nom); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">

        
        <div class="mb-3 d-flex justify-content-between">
            <a href="<?php echo e(route('etatscolaritess')); ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Retour aux classes
            </a>

            <button class="btn btn-primary" onclick="window.print()">
                <i class="fas fa-print"></i> Imprimer
            </button>
        </div>



        
        <div class="text-center mb-4">
            <h5 class="fw-bold">Fiche de scolarité – <?php echo e($classe->nom); ?></h5>
            <p><strong>Année scolaire :</strong> <?php echo e($annee); ?></p>
            <p><strong>Effectif :</strong> <?php echo e($data->count()); ?> élève(s)</p>
        </div>



        
        <form id="form" method="GET" class="mb-4 p-3 rounded border shadow-sm d-flex flex-wrap gap-3">

            
            <div>
                <label class="fw-bold small">Statut</label>
                <select name="statut" class="form-select">
                    <option value="">Tous</option>
                    <option value="impayes" <?php if(request('statut')=='impayes'): echo 'selected'; endif; ?>>
                        Impayés
                    </option>
                    <option value="soldes" <?php if(request('statut')=='soldes'): echo 'selected'; endif; ?>>
                        Soldés
                    </option>
                </select>
            </div>


            
            <div>
                <label class="fw-bold small">Montant payé inférieur à</label>
                <input type="number"
                       name="montant_max"
                       value="<?php echo e(request('montant_max')); ?>"
                       min="0"
                       placeholder="50000"
                       class="form-control">
            </div>


            
            <div class="align-self-end">
                <button class="btn btn-primary">
                    <i class="fas fa-filter"></i>
                    Filtrer
                </button>
            </div>

            
            <div class="align-self-end">
                <a href="<?php echo e(route('etatPaiementClasse', $classe->id)); ?>"
                   class="btn btn-outline-secondary">
                    Réinitialiser
                </a>
            </div>

        </form>




        
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white fw-bold">
                État des paiements – <?php echo e($classe->nom); ?>

            </div>

            <div class="card-body p-0">
                <table class="table table-bordered table-hover align-middle mb-0">

                    <thead class="table-light text-uppercase small">
                    <tr>
                        <th>#</th>
                        <th>Nom & Prénom</th>
                        <th>Bourse</th>
                        <th>Montant total</th>
                        <th>Payé</th>
                        <th>Reste</th>
                    </tr>
                    </thead>

                    <tbody>

                    <?php
                        $total_montant = 0;
                        $total_paye = 0;
                        $total_reste = 0;
                    ?>

                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr>
                            <td><?php echo e($index + 1); ?></td>

                            <td>
                                <?php echo e($item['eleve']->nom); ?>

                                <?php echo e($item['eleve']->prenom); ?>

                            </td>


                            <td>
                                <?php if($item['bourse']): ?>
                                    <span class="badge bg-success">
                                <?php echo e($item['bourse']->nom); ?>


                                        <?php if(count($item['bourse_pourcentages'])): ?>
                                            (<?php echo e(implode('%, ', $item['bourse_pourcentages'])); ?>%)
                                        <?php endif; ?>
                            </span>
                                <?php else: ?>
                                    <span class="text-muted">(aucune)</span>
                                <?php endif; ?>
                            </td>


                            <td>
                                <?php echo e(number_format($item['montant_total'],0,',',' ')); ?>

                                FCFA
                            </td>


                            <td class="text-success fw-bold">
                                <?php echo e(number_format($item['montant_paye'],0,',',' ')); ?>

                                FCFA
                            </td>


                            <td class="fw-bold <?php echo e($item['reste'] > 0 ? 'text-danger' : 'text-success'); ?>">
                                <?php echo e(number_format(abs($item['reste']),0,',',' ')); ?>

                                FCFA
                                <?php if($item['reste'] < 0): ?>
                                    <small>(trop payé)</small>
                                <?php endif; ?>
                            </td>
                        </tr>

                        <?php
                            $total_montant += $item['montant_total'];
                            $total_paye    += $item['montant_paye'];
                            $total_reste   += $item['reste'];
                        ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted">
                                Aucun élève trouvé avec ces critères.
                            </td>
                        </tr>
                    <?php endif; ?>

                    </tbody>



                    
                    <tfoot>
                    <tr class="fw-bold table-light">
                        <td colspan="3" class="text-end">TOTAL :</td>

                        <td>
                            <?php echo e(number_format($total_montant,0,',',' ')); ?> FCFA
                        </td>

                        <td class="text-success">
                            <?php echo e(number_format($total_paye,0,',',' ')); ?> FCFA
                        </td>

                        <td class="<?php echo e($total_reste > 0 ? 'text-danger' : 'text-success'); ?>">
                            <?php echo e(number_format(abs($total_reste),0,',',' ')); ?> FCFA
                        </td>
                    </tr>
                    </tfoot>


                </table>
            </div>
        </div>
    </div>



    
    <style>
        @media print {
            .btn  {
                display:none;
            }
            @media print {
                nav,
                aside,
                header,
                footer,
                .btn,
                button,
                form,
                #form {
                    display: none !important;
                }
            }

        }
    </style>
    <script>
        function printPage(){
            document.getElementById('form').style.display = 'none';
            window.print();
            document.getElementById('form').style.display = 'flex';
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/paiements/etat_paiement_scolarite_par_classe.blade.php ENDPATH**/ ?>