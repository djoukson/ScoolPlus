<?php $__env->startSection('content'); ?>
    <div class="container py-4">

        
        <div class="pro-breadcrumb mb-4">
            <div class="breadcrumb-title">
                Gestion des États & Rapports
            </div>

            
            <form method="GET" class="row g-2 mt-3">
                <div class="col-md-2">
                    <input type="date"
                           name="date_start"
                           class="form-control"
                           value="<?php echo e(request('date_start')); ?>"
                           required>
                </div>
                <div class="col-md-2">
                    <input type="date"
                           name="date_end"
                           class="form-control"
                           value="<?php echo e(request('date_end')); ?>"
                           required>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-primary w-100">
                        Afficher
                    </button>
                </div>
            </form>

            
            <div class="breadcrumb-wrapper mt-2">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/">Dashboard</a></li>
                    <li class="breadcrumb-item active">États & Rapports</li>
                </ol>
            </div>
        </div>

        
        
        
        <?php if(isset($dateDebut) && isset($dateFin)): ?>

            
            <div class="mb-4 d-flex gap-2 flex-wrap">
                <a target="_blank"
                   href="<?php echo e(route('etats.print', request()->all() + ['type' => 'all'])); ?>"
                   class="btn btn-success">
                    🖨️ Tous les états
                </a>

                <a target="_blank"
                   href="<?php echo e(route('etats.print', request()->all() + ['type' => 'scolarite'])); ?>"
                   class="btn btn-outline-success">
                    🧾 Scolarité & inscription
                </a>

                <a target="_blank"
                   href="<?php echo e(route('etats.print', request()->all() + ['type' => 'souscription'])); ?>"
                   class="btn btn-outline-primary">
                    📌 Souscriptions
                </a>

                <a target="_blank"
                   href="<?php echo e(route('etats.print', request()->all() + ['type' => 'depense'])); ?>"
                   class="btn btn-outline-danger">
                    💸 Dépenses
                </a>

                <a target="_blank"
                   href="<?php echo e(route('etats.print', request()->all() + ['type' => 'salaire'])); ?>"
                   class="btn btn-outline-dark">
                    👥 Salaires & rémunérations
                </a>
            </div>

            
            
            

            
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-success text-white">
                    Entrées – Paiements scolarité & inscription
                </div>
                <div class="card-body table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>Élève</th>
                            <th>Frais</th>
                            <th>Montant</th>
                            <th>Date</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $totalPaiements = 0; ?>
                        <?php $__empty_1 = true; $__currentLoopData = $paiements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php $totalPaiements += $p->montant_paye; ?>
                            <tr>
                                <td>
                                    <?php echo e($p->eleve
                                        ? strtoupper($p->eleve->nom).' '.ucfirst($p->eleve->prenom)
                                        : '-'); ?>

                                </td>
                                <td>
                                    <?php echo e($p->frais ? $p->frais->libelle : '-'); ?>

                                </td>
                                <td><?php echo e(number_format($p->montant_paye,0,',',' ')); ?> FCFA</td>
                                <td><?php echo e(\Carbon\Carbon::parse($p->created_at)->format('d/m/Y')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted">
                                    Aucun paiement trouvé
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                        <tfoot>
                        <tr class="fw-bold">
                            <td colspan="2">TOTAL</td>
                            <td colspan="2"><?php echo e(number_format($totalPaiements,0,',',' ')); ?> FCFA</td>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

            
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-primary text-white">
                    Entrées – Souscriptions
                </div>
                <div class="card-body table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>Service</th>
                            <th>Élève</th>
                            <th>Montant</th>
                            <th>Date</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $totalSouscriptions = 0; ?>
                        <?php $__empty_1 = true; $__currentLoopData = $souscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php $totalSouscriptions += $s->montant; ?>
                            <tr>
                                <td>
                                    <?php echo e($s->service ? $s->service->libelle : '-'); ?>

                                </td>
                                <td>
                                    <?php echo e($s->eleve
                                        ? strtoupper($s->eleve->nom).' '.ucfirst($s->eleve->prenom)
                                        : '-'); ?>

                                </td>
                                <td><?php echo e(number_format($s->montant,0,',',' ')); ?> FCFA</td>
                                <td><?php echo e(\Carbon\Carbon::parse($s->created_at)->format('d/m/Y')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted">
                                    Aucune souscription trouvée
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                        <tfoot>
                        <tr class="fw-bold">
                            <td colspan="2">TOTAL</td>
                            <td colspan="2"><?php echo e(number_format($totalSouscriptions,0,',',' ')); ?> FCFA</td>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

            
            
            

            
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-danger text-white">
                    Sorties – Dépenses
                </div>
                <div class="card-body table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>Titre</th>
                            <th>Description</th>
                            <th>Montant</th>
                            <th>Date</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $totalDepenses = 0; ?>
                        <?php $__empty_1 = true; $__currentLoopData = $depenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php $totalDepenses += $d->montant; ?>
                            <tr>
                                <td><?php echo e($d->titre); ?></td>
                                <td><?php echo e($d->description); ?></td>
                                <td><?php echo e(number_format($d->montant,0,',',' ')); ?> FCFA</td>
                                <td><?php echo e($d->date_depense->format('d/m/Y')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted">
                                    Aucune dépense trouvée
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                        <tfoot>
                        <tr class="fw-bold">
                            <td colspan="2">TOTAL</td>
                            <td colspan="2"><?php echo e(number_format($totalDepenses,0,',',' ')); ?> FCFA</td>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

            
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-dark text-white">
                    Sorties – Salaires & rémunérations
                </div>
                <div class="card-body table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>Personnel</th>
                            <th>Montant</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $totalSalaires = 0; ?>
                        <?php $__empty_1 = true; $__currentLoopData = $salaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php $totalSalaires += $s->salaire; ?>
                            <tr>
                                <td><?php echo e($s->nom ?? 'Personnel'); ?></td>
                                <td><?php echo e(number_format($s->salaire,0,',',' ')); ?> FCFA</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="2" class="text-center text-muted">
                                    Aucun salaire trouvé
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                        <tfoot>
                        <tr class="fw-bold">
                            <td>TOTAL</td>
                            <td><?php echo e(number_format($totalSalaires,0,',',' ')); ?> FCFA</td>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

            
            <div class="alert alert-info fw-bold fs-5 text-end">
                TOTAL GLOBAL :
                <?php echo e(number_format(($totalPaiements + $totalSouscriptions) - ($totalDepenses + $totalSalaires),0,',',' ')); ?>

                FCFA
            </div>

        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/etats/index.blade.php ENDPATH**/ ?>