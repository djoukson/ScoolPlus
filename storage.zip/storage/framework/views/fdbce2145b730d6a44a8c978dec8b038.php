<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="pro-breadcrumb">
            <div class="breadcrumb-title">
                Annees scolaires
            </div>
            

            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Les Annees scolaires
                    </li>
                </ol>
            </div>
        </div>
        
        <div class="card shadow-sm mb-4">
            <div class="card-header fw-bold">
                Ajouter une année scolaire
            </div>

            <div class="card-body">
                <form method="POST" action="<?php echo e(route('annees.store')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="row g-3">

                        <div class="col-md-4">
                            <label class="form-label">Nom de l’année</label>
                            <input type="text"
                                   name="nom"
                                   id="nom"
                                   class="form-control <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   placeholder="2025 - 2026"
                                   value="<?php echo e(old('nom')); ?>"
                                   required>
                            <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Date de début</label>
                            <input type="date"
                                   name="date_debut"
                                   class="form-control <?php $__errorArgs = ['date_debut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   value="<?php echo e(old('date_debut')); ?>"
                                   required>
                            <?php $__errorArgs = ['date_debut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Date de fin</label>
                            <input type="date"
                                   name="date_fin"
                                   class="form-control <?php $__errorArgs = ['date_fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   value="<?php echo e(old('date_fin')); ?>"
                                   required>
                            <?php $__errorArgs = ['date_fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>

                    <div class="mt-4 text-end">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-plus me-1"></i>
                            Ajouter
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div class="card shadow-sm mt-3">

            <div class="card-body">

                
                <?php if($anneeActive): ?>
                    <div class="alert alert-info">
                        Année scolaire active :
                        <strong><?php echo e($anneeActive->nom); ?></strong>
                    </div>
                <?php endif; ?>

                
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                        <tr>
                            <th>Nom</th>
                            <th>Date début</th>
                            <th>Date fin</th>
                            <th>Statut</th>
                            <th class="text-end">Actions</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $annees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="fw-semibold"><?php echo e($annee->nom); ?></td>
                                <td><?php echo e($annee->date_debut->format('d/m/Y')); ?></td>
                                <td><?php echo e($annee->date_fin->format('d/m/Y')); ?></td>

                                <td>
                                    <?php if($annee->active): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Inactive</span>
                                    <?php endif; ?>
                                </td>

                                <td class="text-end">

                                    <?php if(!$annee->active): ?>
                                        <button type="button"
                                                class="btn btn-sm btn-success"
                                                data-toggle="modal"
                                                data-target="#activateModal<?php echo e($annee->id); ?>">
                                            Activer
                                        </button>
                                    <?php endif; ?>



                                        <button type="button"
                                                class="btn btn-sm btn-danger"
                                                data-toggle="modal"
                                                data-target="#deleteModal<?php echo e($annee->id); ?>">
                                            Supprimer
                                        </button>


                                </td>
                            </tr>

                            <div class="modal fade" id="activateModal<?php echo e($annee->id); ?>" tabindex="-1" aria-labelledby="activateModalLabel<?php echo e($annee->id); ?>" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">

                                        <div class="modal-header">
                                            <h5 class="modal-title" id="activateModalLabel<?php echo e($annee->id); ?>">Confirmer l’activation</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                                        </div>

                                        <div class="modal-body">
                                            ⚠️ Voulez-vous activer l’année scolaire <strong><?php echo e($annee->nom); ?></strong> ?<br>
                                            L’année actuellement active sera automatiquement désactivée.
                                        </div>

                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                                            <a href="<?php echo e(route('annees.change', $annee->id)); ?>" class="btn btn-success">Confirmer</a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" id="deleteModal<?php echo e($annee->id); ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo e($annee->id); ?>" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">

                                        <div class="modal-header">
                                            <h5 class="modal-title" id="deleteModalLabel<?php echo e($annee->id); ?>">Confirmer la suppression</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                                        </div>

                                        <div class="modal-body">
                                            ⚠️ Voulez-vous vraiment supprimer l’année scolaire <strong><?php echo e($annee->nom); ?></strong> ?<br>
                                            Cette action est irréversible.
                                        </div>

                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>

                                            <form method="POST" action="<?php echo e(route('annees.destroy', $annee)); ?>" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">Confirmer</button>
                                            </form>
                                        </div>

                                    </div>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted">
                                    Aucune année scolaire enregistrée
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
        <script>
            document.querySelector('[name="date_debut"]').addEventListener('change', autoNom);
            document.querySelector('[name="date_fin"]').addEventListener('change', autoNom);

            function autoNom() {
            const d1 = document.querySelector('[name="date_debut"]').value;
            const d2 = document.querySelector('[name="date_fin"]').value;
            if (d1 && d2) {
            document.querySelector('[name="nom"]').value =
            d1.substring(0,4) + ' - ' + d2.substring(0,4);
        }
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/annees_scolaires/index.blade.php ENDPATH**/ ?>