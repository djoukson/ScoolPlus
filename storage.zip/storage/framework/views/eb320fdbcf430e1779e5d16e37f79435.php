<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="pro-breadcrumb">
            <div class="breadcrumb-title">
                📘 Liste des Classes – <span class="text-primary"><?php echo e($anneeActive->nom ?? 'Année scolaire'); ?></span>
            </div>
            
            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Gestion des Classes
                    </li>
                </ol>
            </div>
        </div>

        
        <div class="row g-4">
            <?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-3 col-lg-3">
                    <div class="card shadow-lg border-0 rounded-4 h-100 class-card position-relative">
                        <div class="card-body d-flex flex-column">
                            
                            <h4 class="fw-bold text-dark mb-3">
                                <i class="fas fa-door-open text-primary me-2"></i>
                                <?php echo e($classe->nom); ?>

                            </h4>

                            
                            
                            <?php if($classe->niveau->nom == 'Primaire'): ?>
                                <p class="text-muted mb-3">
                                    <i class="fas fa-chalkboard-teacher text-success me-1"></i>
                                    <span class="fw-semibold">Enseignant :</span>
                                    <?php if($classe->enseignant): ?>
                                            <span class="badge bg-gradient-primary">
                                                <?php echo e($classe->enseignant->nom); ?> <?php echo e($classe->enseignant->prenom); ?>

                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Aucun</span>
                                        <?php endif; ?>
                                    </p>
                                <?php else: ?>
                                    <p class="text-muted mb-3">
                                        <i class="fas fa-book text-success me-1"></i>

                                        <?php if($classe->affectations_count !=0): ?>
                                            <span class="fw-semibold">Matières :</span>
                                            <span class="badge bg-gradient-primary">
                                            <?php echo e($classe->affectations_count); ?>

                                        </span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Aucune matière</span>
                                        <?php endif; ?>

                                </p>
                                
                                <a href="<?php echo e(route('matieres.dansclasse', $classe->id)); ?>"
                                   class="btn btn-outline-info mt-auto w-100">
                                    <i class="fas fa-book-open me-1"></i> Voir les matières
                                </a>

                                
                                <a href="<?php echo e(route('matieres.dansclasse', $classe->id)); ?>"
                                   class="stretched-link"></a>
                            <?php endif; ?>


                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 text-center py-5 text-muted">
                    <i class="fas fa-info-circle fa-2x mb-3"></i>
                    <p>Aucune classe trouvée pour l’année en cours.</p>
                </div>
            <?php endif; ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        /* ✅ Texte en dégradé moderne */
        .text-gradient {
            background: linear-gradient(45deg, #4e73df, #1cc88a);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* ✅ Carte moderne avec hover */
        .class-card {
            transition: all 0.3s ease-in-out;
        }
        .class-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }

        /* ✅ Bouton dégradé */
        .btn-gradient-primary {
            background: linear-gradient(45deg, #4e73df, #1cc88a);
            border: none;
            color: #162e5e;
            font-weight: 500;
        }
        .btn-gradient-primary:hover {
            opacity: 0.9;
            color: #fff;
        }

    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/matieres/matiereparclasse.blade.php ENDPATH**/ ?>