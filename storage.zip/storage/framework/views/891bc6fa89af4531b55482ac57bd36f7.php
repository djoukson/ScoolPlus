<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="pro-breadcrumb">
            <div class="breadcrumb-title">
                Gestion des Classes & Enseignants
            </div>
            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Enseignants/Professeurs : Année <?php echo e($annee_courante?->nom ?? 'Non définie'); ?>

                    </li>
                </ol>
            </div>
        </div>


        
        <div class="row g-4">
            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-lg-3">
                    <div class="card border-0 shadow-lg h-100 rounded-4 hover-zoom">
                        <div class="card-body d-flex flex-column">

                            
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="fw-bold mb-0 text-secondary">
                                    <i class="far fa-building me-2"></i> <?php echo e($classe->nom); ?>

                                </h5>
                                <span class="badge px-3 py-2 <?php echo e($classe->niveau->nom === 'Primaire' ? 'bg-success' : 'bg-info'); ?>">
                            <?php echo e(ucfirst($classe->niveau->nom)); ?>

                        </span>
                            </div>

                            
                            <p class="mb-2 text-muted">
                                <i class="fas fa-users text-primary me-1"></i>
                                <strong><?php echo e($classe->inscriptions_count); ?></strong> élève(s)
                            </p>

                            <?php if($classe->niveau->nom !== 'Primaire'): ?>
                                <p class="mb-2">
                                    <i class="fas fa-user text-success me-1"></i>
                                    <strong>Titulaire :</strong>
                                    <?php if($classe->titulaire): ?>
                                        <?php echo e($classe->titulaire->enseignant->nom); ?> <?php echo e($classe->titulaire->enseignant->prenom); ?>


                                        <!-- Bouton pour ouvrir le modal -->
                                        <button type="button" class="btn btn-link p-0 text-danger ms-2" data-toggle="modal" data-target="#confirmDeleteModal<?php echo e($classe->id); ?>">
                                            <i class="fas fa-user-minus"></i>
                                        </button>

                                        <!-- Modal de confirmation -->
                                <div class="modal fade" id="confirmDeleteModal<?php echo e($classe->id); ?>" tabindex="-1" aria-labelledby="modalLabel<?php echo e($classe->id); ?>" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="modalLabel<?php echo e($classe->id); ?>">Confirmer la suppression</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                                            </div>
                                            <div class="modal-body">
                                                Voulez-vous vraiment retirer le titulaire ?
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                                <form action="<?php echo e(route('titulaires.destroy', $classe->titulaire->id)); ?>" method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger">Oui, retirer</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            <?php else: ?>
                                <span class="text-danger">Non défini</span>
                                <?php endif; ?>
                                </p>
                            <?php endif; ?>


                            
                            <?php if($classe->niveau->nom === 'Primaire'): ?>
                                <p class="mb-2">
                                    <i class="fas fa-user text-success me-1"></i>
                                    <strong>Responsable :</strong>
                                    <?php if($classe->enseignant): ?>
                                        <?php echo e($classe->enseignant->nom); ?> <?php echo e($classe->enseignant->prenom); ?>

                                    <?php else: ?>
                                        <span class="text-danger">Non affecté</span>
                                    <?php endif; ?>
                                </p>
                            <?php else: ?>
                                <p class="mb-2">
                                    <i class="fas fa-chalkboard text-info me-1"></i>
                                    <?php if($classe->affectations->count() > 0): ?>
                                        <strong class="text-success"><?php echo e($classe->affectations->count()); ?> prof(s) affecté(s)</strong>
                                    <?php else: ?>
                                        <span class="text-danger">Aucun professeur affecté</span>
                                    <?php endif; ?>
                                </p>
                            <?php endif; ?>

                            
                            <div class="mt-auto d-flex justify-content-end gap-2">
                                <a href="<?php echo e(route('enseignantclasseaffectation.index', $classe->id)); ?>"
                                   class="btn btn-sm btn-outline-primary rounded-pill shadow-sm">
                                    <i class="fas fa-user-plus me-1"></i> Affectations
                                </a>

                                <?php if($classe->niveau->nom !== 'Primaire'): ?>
                                    <button class="btn btn-sm btn-outline-success rounded-pill shadow-sm"
                                            data-toggle="modal" data-target="#modalTitulaire<?php echo e($classe->id); ?>">
                                        <i class="fas fa-user-tie me-1"></i> +Titulaire
                                    </button>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>
                </div>

                
                <?php if($classe->niveau->nom !== 'Primaire'): ?>
                    <div class="modal fade" id="modalTitulaire<?php echo e($classe->id); ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                            <form method="POST" action="<?php echo e(route('titulaires.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="classe_id" value="<?php echo e($classe->id); ?>">
                                <input type="hidden" name="annee_id" value="<?php echo e($annee_courante->id); ?>">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Choisir le titulaire - <?php echo e($classe->nom); ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <select name="enseignant_id" class="form-select" required>
                                            <option value="">-- Sélectionner un enseignant --</option>
                                            <?php $__currentLoopData = $enseignants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enseignant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $estTitulaire = \App\Models\Titulaire::where('enseignant_id', $enseignant->id)
                                                        ->where('annee_id', $annee_courante->id)
                                                        ->exists();
                                                ?>

                                                <?php if($enseignant->niveau && $enseignant->niveau->nom !== 'Primaire'): ?>
                                                    <option value="<?php echo e($enseignant->id); ?>"
                                                        <?php echo e($estTitulaire ? 'disabled style=color:#ccc' : ''); ?>>
                                                        <?php echo e($enseignant->nom); ?> <?php echo e($enseignant->prenom); ?>

                                                        <?php echo e($estTitulaire ? '(Déjà titulaire)' : ''); ?>

                                                    </option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                        <button type="submit" class="btn btn-success">Enregistrer</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .hover-zoom {
            transition: transform .25s ease, box-shadow .25s ease;
        }
        .hover-zoom:hover {
            transform: translateY(-6px) scale(1.02);
            box-shadow: 0 12px 25px rgba(0,0,0,0.12) !important;
        }
        .btn-gradient-primary {
            background: linear-gradient(45deg, #4e73df, #1cc88a);
            color: #fff;
            border: none;
        }
        .btn-gradient-primary:hover {
            opacity: 0.9;
            color: #fff;
        }
        .bg-gradient-primary {
            background: linear-gradient(45deg, #36b9cc, #4e73df);
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/enseignants/enseignantclasse.blade.php ENDPATH**/ ?>