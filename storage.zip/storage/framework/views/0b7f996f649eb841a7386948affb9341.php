<?php $__env->startSection('content'); ?>
    <div class="container py-4">

        <div class="pro-breadcrumb">
            <div class="breadcrumb-title">
                Gestion des enseignants/professeurs
            </div>
            
            <div class="mb-3 d-flex justify-content-between">
                <div class="btn-group">
                    <button type="button" class="btn btn-outline-info dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                        ➕ Ajouter / Voir enseignants
                    </button>

                    <ul class="dropdown-menu">
                        
                        <li>
                            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#addEnseignantModal">
                                ➕ Ajouter un enseignant
                            </a>
                        </li>

                        <li><hr class="dropdown-divider"></li>

                        
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('enseignants.liste.niveau', ['niveau' => 'primaire'])); ?>">
                                🏫 Enseignants Primaire
                            </a>
                        </li>

                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('enseignants.liste.niveau', ['niveau' => 'college'])); ?>">
                                🏫 Enseignants Collège
                            </a>
                        </li>

                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('enseignants.liste.niveau', ['niveau' => 'lycee'])); ?>">
                                🏫 Enseignants Lycée
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Enseignants/Professeurs
                    </li>
                </ol>
            </div>
        </div>




        <div class="modal fade" id="addEnseignantModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content shadow-lg border-0 rounded-3">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title">➕ Ajouter un enseignant</h5>
                        <button type="button" class="btn-close btn-close-white" data-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="<?php echo e(route('enseignants.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Nom *</label>
                                    <input type="text" name="nom" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Prénom *</label>
                                    <input type="text" name="prenom" class="form-control" required>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">🚻 Sexe</label>
                                    <select name="sexe" class="form-select">
                                        <option value="">-- Sélectionner --</option>
                                        <option value="M">Masculin</option>
                                        <option value="F">Féminin</option>
                                    </select>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label">🏠 Adresse</label>
                                    <input type="text" name="adresse" class="form-control"
                                           placeholder="Quartier, ville">
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label">🩸 Groupe sanguin</label>
                                    <select name="groupesanguin" class="form-select">
                                        <option value="">-- Sélectionner --</option>
                                        <option value="A+">A+</option>
                                        <option value="A-">A-</option>
                                        <option value="B+">B+</option>
                                        <option value="B-">B-</option>
                                        <option value="AB+">AB+</option>
                                        <option value="AB-">AB-</option>
                                        <option value="O+">O+</option>
                                        <option value="O-">O-</option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="niveau_id" class="form-label">Niveau</label>
                                    <select name="niveau_id" id="niveau_add" class="form-select" required>
                                        <option value="">-- Sélectionner un niveau --</option>
                                        <?php $__currentLoopData = App\Models\Niveau::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $niveau): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($niveau->id); ?>" <?php echo e(old('niveau_id') == $niveau->id ? 'selected' : ''); ?>>
                                                <?php echo e($niveau->nom); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                
                                <div class="col-md-12" id="salaire_add" style="display:none;">
                                    <label class="form-label">💵 Salaire mensuel (Primaire)</label>
                                    <input type="number" name="salaire_mensuel" class="form-control">
                                </div>


                                <div class="col-md-6">
                                    <label for="type" class="form-label">Type d’enseignant </label>
                                    <select name="type" class="form-select" >
                                        <option value="">-- Sélectionner --</option>
                                        <option value="titulaire" <?php echo e(old('type') == 'titulaire' ? 'selected' : ''); ?>>Titulaire</option>
                                        <option value="vacataire" <?php echo e(old('type') == 'vacataire' ? 'selected' : ''); ?>>Vacataire</option>
                                        <option value="autre" <?php echo e(old('type') == 'autre' ? 'selected' : ''); ?>>Autre</option>
                                    </select>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Spécialité</label>
                                    <input type="text" name="specialite" class="form-control">
                                </div>
                                <div class="col-md-6">
                                    <label for="tuteur_tel" class="form-label">📞 Téléphone du Tuteur</label>
                                    <div class="input-group">
                                        <span class="input-group-text">+228</span>
                                        <input type="tel" name="tel" id="tuteur_tel" class="form-control"
                                               placeholder="90 12 34 56"
                                               pattern="[0-9]{8}" maxlength="8">
                                    </div>
                                    <small class="text-muted">Format : 8 chiffres (ex: 90123456)</small>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Email</label>
                                    <input type="email" name="email" class="form-control">
                                </div>
                            </div>
                            <div class="mt-3 text-end">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                <button type="submit" class="btn btn-success">✅ Enregistrer</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="card shadow-sm">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0">Liste des enseignants (<?php echo e($enseignants->total()); ?>)</h5>
            </div>
            <div class="card-body p-2">
                <div class="table-responsive">
                    <table id="notesListeTable" class="table table-hover table-striped align-middle mb-0">
                        <thead class="table-primary">
                        <tr>
                            <th>Matricule</th>
                            <th>Nom & Prénom</th>
                            <th>Niveau</th> <!-- Nouvelle colonne -->
                            <th>Téléphone</th>
                            <th>Email</th>
                            <th>Statut</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $enseignants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td style="text-align: center"><?php echo e($ens->id); ?></td>
                                <td><?php echo e(strtoupper($ens->nom)); ?> <?php echo e(ucfirst($ens->prenom)); ?></td>
                                <td><?php echo e($ens->niveau ? $ens->niveau->nom : '-'); ?></td> <!-- Affichage du niveau -->
                                <td><?php echo e($ens->tel ?? '-'); ?></td>
                                <td><?php echo e($ens->email ?? '-'); ?></td>
                                <td class="text-center">
                                    <?php if($ens->statut): ?>
                                        <span class="text-success" title="Actif">✅</span>
                                    <?php else: ?>
                                        <span class="text-danger" title="Inactif">🚫</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                            ⚙️ Options
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li>
                                                <a href="<?php echo e(route('enseignants.show', $ens->id)); ?>" class="dropdown-item">
                                                    👁️ Voir détails
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#editEnseignant<?php echo e($ens->id); ?>">
                                                    ✏️ Modifier
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#toggleEnseignant<?php echo e($ens->id); ?>">
                                                    <?php echo e($ens->statut ? '🚫 Désactiver' : '✅ Activer'); ?>

                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item text-danger" href="#" data-toggle="modal" data-target="#deleteEnseignant<?php echo e($ens->id); ?>">
                                                    🗑️ Supprimer
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>

                            </tr>

                            
                            <div class="modal fade" id="editEnseignant<?php echo e($ens->id); ?>" tabindex="-1">
                                <div class="modal-dialog modal-lg modal-dialog-centered">
                                    <div class="modal-content shadow-lg border-0 rounded-3">
                                        <div class="modal-header bg-info text-white">
                                            <h5 class="modal-title">✏️ Modifier l’enseignant</h5>
                                            <button type="button" class="btn-close btn-close-white" data-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form method="POST" action="<?php echo e(route('enseignants.update', $ens->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <div class="row g-3">
                                                    <div class="col-md-6">
                                                        <label class="form-label">Nom *</label>
                                                        <input type="text" name="nom" value="<?php echo e($ens->nom); ?>" class="form-control" required>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label class="form-label">Prénom *</label>
                                                        <input type="text" name="prenom" value="<?php echo e($ens->prenom); ?>" class="form-control" required>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label class="form-label">🚻 Sexe</label>
                                                        <select name="sexe" class="form-select">
                                                            <option value="">-- Sélectionner --</option>
                                                            <option value="M" <?php echo e($ens->sexe === 'M' ? 'selected' : ''); ?>>
                                                                Masculin
                                                            </option>
                                                            <option value="F" <?php echo e($ens->sexe === 'F' ? 'selected' : ''); ?>>
                                                                Féminin
                                                            </option>
                                                        </select>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <label class="form-label">🏠 Adresse</label>
                                                        <input type="text"
                                                               name="adresse"
                                                               class="form-control"
                                                               value="<?php echo e(old('adresse', $ens->adresse)); ?>"
                                                               placeholder="Quartier, ville">
                                                    </div>

                                                    <div class="col-md-4">
                                                        <label class="form-label">🩸 Groupe sanguin</label>
                                                        <select name="groupesanguin" class="form-select">
                                                            <option value="">-- Sélectionner --</option>

                                                            <?php $__currentLoopData = ['A+','A-','B+','B-','AB+','AB-','O+','O-']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($groupe); ?>"
                                                                    <?php echo e(old('groupesanguin', $ens->groupesanguin) === $groupe ? 'selected' : ''); ?>>
                                                                    <?php echo e($groupe); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>


                                                    <div class="mb-3">
                                                        <label for="niveau_id" class="form-label">Niveau</label>
                                                        <select name="niveau_id"
                                                                class="form-select niveau-edit"
                                                                data-salaire="salaire_edit_<?php echo e($ens->id); ?>">
                                                            <option value="">-- Sélectionner un niveau --</option>
                                                            <?php $__currentLoopData = App\Models\Niveau::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $niveau): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($niveau->id); ?>"
                                                                    <?php echo e($ens->niveau_id == $niveau->id ? 'selected' : ''); ?>>
                                                                    <?php echo e($niveau->nom); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-12 salaire-edit"
                                                         id="salaire_edit_<?php echo e($ens->id); ?>"
                                                         style="display:none;">
                                                        <label class="form-label">💵 Salaire mensuel (Primaire)</label>
                                                        <input type="number"
                                                               name="salaire_mensuel"
                                                               value="<?php echo e($ens->salaire_mensuel); ?>"
                                                               class="form-control">
                                                    </div>


                                                    <div class="col-md-6">
                                                        <label for="type" class="form-label">Type d’enseignant *</label>
                                                        <select name="type" class="form-select">
                                                            <option value="">-- Sélectionner --</option>
                                                            <option value="titulaire" <?php echo e($ens->type == 'titulaire' ? 'selected' : ''); ?>>Titulaire</option>
                                                            <option value="vacataire" <?php echo e($ens->type == 'vacataire' ? 'selected' : ''); ?>>Vacataire</option>
                                                            <option value="autre" <?php echo e($ens->type == 'autre' ? 'selected' : ''); ?>>Autre</option>
                                                        </select>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <label class="form-label">Spécialité</label>
                                                        <input type="text" name="specialite" value="<?php echo e($ens->specialite); ?>" class="form-control">
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label for="tuteur_tel" class="form-label">📞 Téléphone du Tuteur</label>
                                                        <div class="input-group">
                                                            <span class="input-group-text">+228</span>
                                                            <input type="tel" name="tel" id="tuteur_tel" class="form-control"
                                                                   placeholder="90 12 34 56"
                                                                   pattern="[0-9]{8}" maxlength="8">
                                                        </div>
                                                        <small class="text-muted">Format : 8 chiffres (ex: 90123456)</small>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label class="form-label">Email</label>
                                                        <input type="email" name="email" value="<?php echo e($ens->email); ?>" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="mt-3 text-end">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                                    <button type="submit" class="btn btn-info">💾 Mettre à jour</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="modal fade" id="deleteEnseignant<?php echo e($ens->id); ?>" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content shadow-lg border-0 rounded-3">
                                        <div class="modal-header bg-danger text-white">
                                            <h5 class="modal-title">🗑️ Supprimer l’enseignant</h5>
                                            <button type="button" class="btn-close btn-close-white" data-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            Voulez-vous vraiment supprimer <strong><?php echo e($ens->nom); ?> <?php echo e($ens->prenom); ?></strong> ?
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                            <form action="<?php echo e(route('enseignants.destroy', $ens->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">Oui, Supprimer</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="modal fade" id="toggleEnseignant<?php echo e($ens->id); ?>" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content shadow-lg border-0 rounded-3">
                                        <div class="modal-header <?php echo e($ens->statut ? 'bg-warning' : 'bg-success'); ?> text-white">
                                            <h5 class="modal-title"><?php echo e($ens->statut ? 'Désactiver' : 'Activer'); ?> l’enseignant</h5>
                                            <button type="button" class="btn-close btn-close-white" data-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            Voulez-vous vraiment <strong><?php echo e($ens->statut ? 'désactiver' : 'activer'); ?></strong> <strong><?php echo e($ens->nom); ?> <?php echo e($ens->prenom); ?></strong> ?
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                            <form action="<?php echo e(route('enseignants.toggle', $ens->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn <?php echo e($ens->statut ? 'btn-warning' : 'btn-success'); ?>">
                                                    Oui, <?php echo e($ens->statut ? 'Désactiver' : 'Activer'); ?>

                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted">Aucun enseignant trouvé</td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card-footer">
                <div class="d-flex justify-content-center">
                    <?php echo e($enseignants->links('pagination::bootstrap-5')); ?>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {

            function toggleSalaire(select, salaireBlock) {
                if (!select || !salaireBlock) return;

                const text = select.options[select.selectedIndex]?.text.toLowerCase() || '';

                if (text.includes('primaire')) {
                    salaireBlock.style.display = 'block';
                } else {
                    salaireBlock.style.display = 'none';
                    const input = salaireBlock.querySelector('input');
                    if (input) input.value = '';
                }
            }

            /* ========= AJOUT ========= */
            const niveauAdd = document.getElementById('niveau_add');
            const salaireAdd = document.getElementById('salaire_add');

            if (niveauAdd && salaireAdd) {
                niveauAdd.addEventListener('change', () => toggleSalaire(niveauAdd, salaireAdd));
                toggleSalaire(niveauAdd, salaireAdd);
            }

            /* ========= EDIT (MULTI MODALS) ========= */
            document.querySelectorAll('.niveau-edit').forEach(select => {
                const salaireId = select.dataset.salaire;
                const salaireBlock = document.getElementById(salaireId);

                select.addEventListener('change', () => toggleSalaire(select, salaireBlock));
                toggleSalaire(select, salaireBlock);
            });

            /* ========= DATATABLE ========= */
            $('#notesListeTable').DataTable({
                destroy: true,
                responsive: true,
                pageLength: 50,
                order: [[0, "desc"]],
                language: {
                    url: "<?php echo e(asset('assets/datatables/i18n/fr-FR.json')); ?>"
                }
            });

        });
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/enseignants/index.blade.php ENDPATH**/ ?>