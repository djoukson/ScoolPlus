<?php $__env->startSection('title', 'Session expirée'); ?>

<?php $__env->startSection('content'); ?>
    <div class="error-code">419</div>
    <div class="error-icon mb-3">
        <i class="fas fa-clock"></i>
    </div>
    <h4>Session expirée</h4>
    <p class="text-muted">
        Votre session a expiré pour des raisons de sécurité.
        Veuillez vous reconnecter.
    </p>

    <a href="<?php echo e(route('login')); ?>" class="btn btn-danger mt-3">
        <i class="fas fa-sign-in-alt me-1"></i> Se reconnecter
    </a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/errors/419.blade.php ENDPATH**/ ?>