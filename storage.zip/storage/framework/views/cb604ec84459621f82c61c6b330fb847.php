<?php $__env->startSection('title', 'Gestion des sauvegardes'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">

        <div class="pro-breadcrumb">
            <div class="breadcrumb-title">
                Les sauvegardes
            </div>
            <form action="<?php echo e(route('backup.create')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button  style="margin-bottom: 10px" type="submit" class="btn btn-info mb-3">
                    <i class="fas fa-database me-2"></i> Créer une nouvelle sauvegarde
                </button>
            </form>
            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Creation des sauvegardes
                    </li>
                </ol>
            </div>
        </div>

        <table class="table table-striped table-bordered">
            <thead>
            <tr>
                <th>#</th>
                <th>Nom du fichier</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $backups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $backup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($backup->filename); ?></td>
                    <td><?php echo e($backup->created_at->format('d/m/Y H:i')); ?></td>
                    <td>
                        <a href="<?php echo e(route('backup.download', $backup->id)); ?>" class="btn btn-sm btn-primary">
                            <i class="fas fa-download"></i> Télécharger
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/backups/index.blade.php ENDPATH**/ ?>