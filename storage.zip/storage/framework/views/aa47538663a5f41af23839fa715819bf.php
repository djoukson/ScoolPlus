<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'SchoolPlus'); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('dist/img/logo.png')); ?>" type="image/x-icon">

    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('dist/css/font-awesome.min.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('fonts/fonts.css')); ?>">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome-free/css/all.min.css')); ?>">

    <!-- AdminLTE -->
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/adminlte.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/select2.min.css')); ?>">


    <link rel="stylesheet" href="<?php echo e(asset('dist/css/dataTables.bootstrap5.min.css')); ?>">

    <!-- Google Fonts (via CDN et non fichier local) -->

</head>
<body class="hold-transition sidebar-mini layout-fixed">
<style>
    /* ===== CONTAINER ===== */
    .pro-breadcrumb {
        background: linear-gradient(135deg, #0b1f33, #102c44);
        border-radius: 16px;
        padding: 22px 26px 18px;
        box-shadow: 0 14px 32px rgba(11, 31, 51, 0.35);
        margin-bottom: 32px;
        color: #fff;
    }

    /* ===== TITRE ===== */
    .pro-breadcrumb .breadcrumb-title {
        font-size: 1.4rem;
        font-weight: 800;
        letter-spacing: 0.4px;
        margin-bottom: 14px;
        color: #ffffff;
    }

    /* ===== ZONE NIVEAUX ===== */
    .pro-breadcrumb .breadcrumb-wrapper {
        background: linear-gradient(135deg, #1c3f5e, #295f7d);
        border-radius: 12px;
        padding: 10px 16px;
        backdrop-filter: blur(6px);
    }

    /* ===== BREADCRUMB ===== */
    .pro-breadcrumb .breadcrumb {
        margin: 0;
        padding: 0;
        background: transparent;
        font-size: 0.9rem;
    }

    .pro-breadcrumb .breadcrumb-item + .breadcrumb-item::before {
        content: "❯";
        color: rgba(255,255,255,0.65);
        padding: 0 12px;
        font-size: 0.75rem;
    }


    /* ===== ACTIF ===== */
    .pro-breadcrumb .breadcrumb-item.active {
        color: #e9f2f8;
        font-weight: 600;
    }
    /* === HOVER PRO LINKS === */
    .pro-breadcrumb .breadcrumb-item a {
        position: relative;
        color: rgba(255,255,255,0.88);
        text-decoration: none;
        font-weight: 500;
        padding-bottom: 2px;
        transition: color 0.25s ease;
    }

    /* underline animé */
    .pro-breadcrumb .breadcrumb-item a::after {
        content: "";
        position: absolute;
        left: 0;
        bottom: -2px;
        width: 0;
        height: 2px;
        background: linear-gradient(90deg, #6dd5fa, #ffffff);
        border-radius: 2px;
        transition: width 0.3s ease;
    }

    /* hover */
    .pro-breadcrumb .breadcrumb-item a:hover {
        color: #ffffff;
        text-shadow: 0 0 8px rgba(109, 213, 250, 0.6);
    }

    .pro-breadcrumb .breadcrumb-item a:hover::after {
        width: 100%;
    }



</style>


<div class="wrapper">
    <?php if(session('success') || session('error')): ?>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    showCloseButton: true,
                    timer: 4000,
                    timerProgressBar: true,
                    background: '#fff',
                    customClass: {
                        popup: 'shadow-lg rounded-4 colorful-toast',
                        title: 'fw-semibold text-dark',
                    },
                    didOpen: (toast) => {
                        // Décale le toast vers le bas
                        toast.parentElement.style.top = '30px';

                        // Permet au timer de s’arrêter quand on survole
                        toast.addEventListener('mouseenter', Swal.stopTimer);
                        toast.addEventListener('mouseleave', Swal.resumeTimer);

                        // ✅ Ferme bien le toast quand on clique sur la croix
                        const closeBtn = toast.querySelector('.swal2-close');
                        if (closeBtn) {
                            closeBtn.addEventListener('click', () => {
                                Swal.close();
                            });
                        }
                    },
                    willClose: () => {
                        // ✅ Forcer la fermeture propre après timer ou clic
                        document.querySelectorAll('.swal2-container').forEach(el => el.remove());
                    }
                });

                <?php if(session('success')): ?>
                Toast.fire({
                    icon: 'success',
                    title: <?php echo json_encode(session('success'), 15, 512) ?>,
                });
                <?php endif; ?>

                <?php if(session('error')): ?>
                Toast.fire({
                    icon: 'error',
                    title: <?php echo json_encode(session('error'), 15, 512) ?>,
                });
                <?php endif; ?>
            });
        </script>

        <style>
            /* 🎨 Style général du toast */
            .swal2-container.swal2-top-end > .swal2-popup.colorful-toast {
                margin-top: 30px !important;
                animation: slideDown 0.4s ease-out;
                border-left: 5px solid transparent;
                transition: all 0.3s ease-in-out;
            }

            /* ✅ Couleur dynamique selon le type */
            .swal2-popup.swal2-toast.swal2-icon-success.colorful-toast {
                border-left-color: #28a745; /* Vert */
                background: linear-gradient(145deg, #e9fbee, #ffffff);
            }

            .swal2-popup.swal2-toast.swal2-icon-error.colorful-toast {
                border-left-color: #dc3545; /* Rouge */
                background: linear-gradient(145deg, #fdeaea, #ffffff);
            }

            /* ✨ Animation fluide */
            @keyframes slideDown {
                from {
                    opacity: 0;
                    transform: translateY(-20px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
        </style>
    <?php endif; ?>




    <!-- Navbar -->
    <?php echo $__env->make('layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Sidebar -->
    <?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Content Wrapper -->
    <div class="content-wrapper" style="margin-top: 10px">
        <section class="content-header">
            
        </section>

        <section class="content">
            <?php echo $__env->yieldContent('content'); ?>
        </section>
    </div>

    <!-- Footer -->
    <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div>

<!-- jQuery (toujours en premier) -->
<script src="<?php echo e(asset('dist/js/jquery-3.6.0.min.js')); ?>"></script>

<!-- Bootstrap (bundle inclut Popper.js automatiquement) -->
<script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- AdminLTE -->
<script src="<?php echo e(asset('dist/js/adminlte.min.js')); ?>"></script>

<!-- DataTables (⚠️ ordre corrigé) -->
<script src="<?php echo e(asset('dist/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/dataTables.bootstrap5.min.js')); ?>"></script>

<!-- SweetAlert2 -->
<script src="<?php echo e(asset('dist/js/sweetalert2@11.js')); ?>"></script>

<!-- Select2 -->
<script src="<?php echo e(asset('dist/js/select2.min.js')); ?>"></script>

<!-- Scripts spécifiques aux pages -->
<?php echo $__env->yieldPushContent('scripts'); ?>



</body>
</html>
<?php /**PATH C:\wamp64\www\schoolplus\resources\views/layouts/app.blade.php ENDPATH**/ ?>