<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des Enseignants <?php echo e($niveau ? ' - '.$niveau : ''); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 14px;
        }
        .header-title {
            text-align: center;
            margin-bottom: 20px;
        }
        .header-title h2 {
            font-weight: bold;
            margin: 0;
        }
        .header-title p {
            margin: 0;
            font-size: 13px;
            color: #555;
        }
        .table th {
            background-color: #f8f9fa;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: rgba(0,0,0,.02);
        }

        @media print {
            @page {
                size: A4 landscape;
                margin: 10mm;
            }
            .container {
                width: 100% !important;
                max-width: 100% !important;
            }
            table {
                margin-left: auto !important;
                margin-right: auto !important;
            }
            .table {
                width: auto !important;
                max-width: 100% !important;
            }
            body {
                zoom: 85%;
            }
            .no-print {
                display: none !important;
            }
        }
    </style>
</head>
<body>

<div class="container mt-4">

    <!-- En-tête -->
    <div class="header-title">
        <h2>Liste des Enseignants</h2>

        <?php if($niveau): ?>
            <p>Niveau sélectionné : <strong><?php echo e(ucfirst($niveau)); ?></strong></p>
        <?php else: ?>
            <p><strong>Tous les niveaux confondus</strong></p>
        <?php endif; ?>

        <p>Date d’impression : <?php echo e(\Carbon\Carbon::now()->format('d/m/Y')); ?></p>
    </div>

    <!-- Bouton impression -->
    <div class="text-end mb-3 no-print">
        <button onclick="window.print()" class="btn btn-primary">🖨️ Imprimer</button>
    </div>

    <!-- Tableau enseignants -->
    <table class="table table-bordered table-striped">
        <thead>
        <tr>
            <th>#</th>
            <th>Matricule</th>
            <th>Nom & Prénom</th>
            <th>Niveau</th>
            <th>Type</th>
            <th>Spécialité</th>

            <?php if(strtolower($niveau) === 'primaire'): ?>
                <th>Salaire Mensuel</th>
            <?php endif; ?>

            <th>Téléphone</th>
            <th>Email</th>
            <th>Statut</th>
            <th>Date Enregistrement</th>
            <th>Observation</th>
        </tr>
        </thead>

        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $enseignants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td style="text-align: center"><?php echo e($ens->id); ?></td>
                <td><?php echo e(strtoupper($ens->nom)); ?> <?php echo e(ucfirst($ens->prenom)); ?></td>
                <td><?php echo e($ens->niveau ? $ens->niveau->nom : '-'); ?></td>
                <td><?php echo e($ens->type ?? '-'); ?></td>
                <td><?php echo e($ens->specialite ?? '-'); ?></td>

                <?php if(strtolower($niveau) === 'primaire'): ?>
                    <td style="text-align:right">
                        <?php echo e($ens->salaire_mensuel
                            ? number_format($ens->salaire_mensuel, 0, ',', ' ') . ' FCFA'
                            : '-'); ?>

                    </td>
                <?php endif; ?>

                <td><?php echo e($ens->tel ?? '-'); ?></td>
                <td><?php echo e($ens->email ?? '-'); ?></td>

                <td>
                    <?php echo $ens->statut
                        ? '<span style="color:green">✔️ Actif</span>'
                        : '<span style="color:red">❌ Désactivé</span>'; ?>

                </td>

                <td><?php echo e(\Carbon\Carbon::parse($ens->created_at)->format('d/m/Y')); ?></td>
                <td></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="<?php echo e(strtolower($niveau) === 'primaire' ? 12 : 11); ?>"
                    class="text-center text-muted">
                    Aucun enseignant trouvé pour ce niveau.
                </td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>
<?php /**PATH C:\wamp64\www\schoolplus\resources\views/enseignants/print.blade.php ENDPATH**/ ?>