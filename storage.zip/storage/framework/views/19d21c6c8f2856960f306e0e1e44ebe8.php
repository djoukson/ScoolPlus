<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste du Personnel Administratif</title>

    <style>
        @page {
            size: A4 landscape;
            margin: 20px 30px;
        }

        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 11px;
            color: #000;
        }

        .header-table {
            width: 100%;
            margin-bottom: 10px;
        }

        .logo {
            width: 80px;
        }

        .school-name {
            font-size: 16px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .school-info {
            font-size: 11px;
            line-height: 1.4;
        }

        .title {
            text-align: center;
            font-size: 15px;
            font-weight: bold;
            margin-top: 8px;
        }

        .line {
            border-bottom: 2px solid #000;
            margin: 8px 0 15px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #000;
            padding: 6px;
        }

        th {
            background-color: #f0f0f0;
            text-align: center;
        }

        td {
            vertical-align: middle;
        }

        .text-center {
            text-align: center;
        }

        .text-right {
            text-align: right;
        }

        .footer {
            margin-top: 40px;
            width: 100%;
        }

        .signature {
            width: 40%;
            float: right;
            text-align: center;
        }
    </style>
</head>
<body>


<table class="header-table">
    <tr>
        <td width="20%">
            <?php if($ecole && $ecole->logo): ?>
                <img src="<?php echo e(public_path('storage/'.$ecole->logo)); ?>" class="logo">
            <?php endif; ?>
        </td>

        <td width="60%" class="text-center">
            <div class="school-name">
                <?php echo e($ecole->nom ?? 'NOM DE L’ÉTABLISSEMENT'); ?>

            </div>
            <div class="school-info">
                Adresse : <?php echo e($ecole->adresse ?? '-'); ?> <br>
                Tél : <?php echo e($ecole->telephone ?? '-'); ?> |
                Email : <?php echo e($ecole->email ?? '-'); ?> <br>
                <?php if($ecole->site_web): ?>
                    Site web : <?php echo e($ecole->site_web); ?>

                <?php endif; ?>
            </div>
        </td>

        <td width="20%"></td>
    </tr>
</table>

<div class="title">
    LISTE DU PERSONNEL ADMINISTRATIF
</div>

<?php if($ecole && $ecole->annee): ?>
    <div class="text-center" style="font-size:11px;">
        Année scolaire : <?php echo e($ecole->annee->libelle); ?>

    </div>
<?php endif; ?>

<div class="line"></div>


<table>
    <thead>
    <tr>
        <th>Matricule</th>
        <th>Nom & Prénom</th>
        <th>Poste / Fonction</th>
        <th>Téléphone</th>
        <th>Email</th>
        <th>Salaire (FCFA)</th>
        <th>Statut</th>
    </tr>
    </thead>
    <tbody>
    <?php $totalSalaire = 0; ?>

    <?php $__currentLoopData = $personnel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $totalSalaire += $p->salaire ?? 0; ?>
        <tr>
            <td class="text-center"><?php echo e($p->id); ?></td>
            <td><?php echo e(strtoupper($p->nom)); ?> <?php echo e(ucfirst($p->prenom)); ?></td>
            <td><?php echo e($p->poste ?? '-'); ?></td>
            <td><?php echo e($p->tel ?? '-'); ?></td>
            <td><?php echo e($p->email ?? '-'); ?></td>
            <td class="text-right">
                <?php echo e(number_format($p->salaire, 0, ',', ' ')); ?>

            </td>
            <td class="text-center">
                <?php echo e($p->statut ? 'Actif' : 'Inactif'); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

    <tfoot>
    <tr>
        <th colspan="5" class="text-right">TOTAL SALAIRES</th>
        <th class="text-right">
            <?php echo e(number_format($totalSalaire, 0, ',', ' ')); ?> FCFA
        </th>
        <th></th>
    </tr>
    </tfoot>
</table>


<div class="footer">
    <div class="signature">
        <p>
            Fait le <?php echo e(now()->format('d/m/Y')); ?> <br><br>
            <strong>Le Directeur</strong><br><br><br>
            <?php echo e($ecole->directeur ?? '_________________'); ?>

        </p>
    </div>
</div>

</body>
</html>
<?php /**PATH C:\wamp64\www\schoolplus\resources\views/personnel/pdf.blade.php ENDPATH**/ ?>