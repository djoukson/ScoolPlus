<?php $__env->startSection('title', 'Gestion des paiements'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="pro-breadcrumb">
            <div class="breadcrumb-title">
                Gestion des Paiements
            </div>
            
            <div class="mb-3">
                <a href="<?php echo e(route('paiements.create')); ?>"   class="btn btn-outline-info">
                    ➕  Nouveau paiement
                </a>
            </div>
            <div class="breadcrumb-wrapper">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="/">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Gestion des Paiements
                    </li>
                </ol>
            </div>
        </div>

        
        <form method="GET" class="mb-3 d-flex gap-2">
            <input type="text" name="search" class="form-control" placeholder="Rechercher par élève ou classe"
                   value="<?php echo e(request('search')); ?>">
            <button type="submit" class="btn btn-secondary">Rechercher</button>
        </form>

        
        <div class="card shadow-sm">
            <div class="card-body p-0">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>
                            <a href="?sort=nom&direction=<?php echo e(request('direction') === 'asc' ? 'desc' : 'asc'); ?>" class="text-white">
                                Élève
                                <?php if(request('sort') === 'nom'): ?>
                                    <i class="fas fa-sort-<?php echo e(request('direction') === 'asc' ? 'up' : 'down'); ?>"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort"></i>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>
                            <a href="?sort=classe&direction=<?php echo e(request('direction') === 'asc' ? 'desc' : 'asc'); ?>" class="text-white">
                                Classe
                                <?php if(request('sort') === 'classe'): ?>
                                    <i class="fas fa-sort-<?php echo e(request('direction') === 'asc' ? 'up' : 'down'); ?>"></i>
                                <?php else: ?>
                                    <i class="fas fa-sort"></i>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>Année</th>
                        <th>Bourse</th>
                        <th>Total payé</th>
                        <th>Restant</th>
                        <th class="text-center">Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item['eleve']->nom); ?> <?php echo e($item['eleve']->prenom); ?></td>
                            <td><?php echo e($item['classe']->nom); ?></td>
                            <td><?php echo e($item['annee']->nom); ?></td>

                            
                            <td>
                                <?php if($item['bourse']): ?>
                                    <span class="badge bg-info text-dark">
                                        <?php echo e($item['bourse']->nom); ?> (<?php echo e(implode('%, ', $item['bourse']->frais->pluck('pivot.pourcentage')->toArray())); ?>%)
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>

                            
                            <td>
                                <span class="badge bg-success">
                                    <?php echo e(number_format($item['total_paye'], 0, ',', ' ')); ?> FCFA
                                </span>
                            </td>

                            
                            <td>
                                <?php if($item['reste_total'] < 0): ?>
                                    <span class="badge bg-danger">
                                        <?php echo e(number_format(abs($item['reste_total']), 0, ',', ' ')); ?> FCFA (Trop payé)
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-warning">
                                        <?php echo e(number_format($item['reste_total'], 0, ',', ' ')); ?> FCFA
                                    </span>
                                <?php endif; ?>
                            </td>

                            
                            <td class="text-center">
                                <a href="<?php echo e(route('paiements.listeeleve', $item['eleve']->id)); ?>" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i> Voir
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center py-4 text-muted">
                                Aucun paiement enregistré.
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            <div class="d-flex justify-content-center mt-3">
                
            </div>
        </div>
    </div>

    
    <style>
        @media print {
            .btn { display: none; }
            .card { box-shadow: none; border: 1px solid #000; }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\schoolplus\resources\views/paiements/index.blade.php ENDPATH**/ ?>